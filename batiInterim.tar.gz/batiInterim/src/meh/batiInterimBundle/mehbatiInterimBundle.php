<?php

namespace meh\batiInterimBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class mehbatiInterimBundle extends Bundle
{
}
