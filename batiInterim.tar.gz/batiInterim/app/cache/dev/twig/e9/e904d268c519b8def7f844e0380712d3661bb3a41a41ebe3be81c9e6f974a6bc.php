<?php

/* mehbatiInterimBundle:Gestionnaire:VueInsererChefChantier.html.twig */
class __TwigTemplate_75b274023cfb61d6f070ed8cf1db7e483026d9f5a90a7b0f7220393f70cbe31f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("mehbatiInterimBundle::base.html.twig", "mehbatiInterimBundle:Gestionnaire:VueInsererChefChantier.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'titrePage' => array($this, 'block_titrePage'),
            'contenu' => array($this, 'block_contenu'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "mehbatiInterimBundle::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8df85b701a99aa315b6e9ae5a5009d729e9a0d521cda22a98b9913014bb59946 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8df85b701a99aa315b6e9ae5a5009d729e9a0d521cda22a98b9913014bb59946->enter($__internal_8df85b701a99aa315b6e9ae5a5009d729e9a0d521cda22a98b9913014bb59946_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "mehbatiInterimBundle:Gestionnaire:VueInsererChefChantier.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_8df85b701a99aa315b6e9ae5a5009d729e9a0d521cda22a98b9913014bb59946->leave($__internal_8df85b701a99aa315b6e9ae5a5009d729e9a0d521cda22a98b9913014bb59946_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_e958dc98fa74641b388e9e47044e8f509418d051a2490e4e5d19298b0e69b1db = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e958dc98fa74641b388e9e47044e8f509418d051a2490e4e5d19298b0e69b1db->enter($__internal_e958dc98fa74641b388e9e47044e8f509418d051a2490e4e5d19298b0e69b1db_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Inserer chef chantier";
        
        $__internal_e958dc98fa74641b388e9e47044e8f509418d051a2490e4e5d19298b0e69b1db->leave($__internal_e958dc98fa74641b388e9e47044e8f509418d051a2490e4e5d19298b0e69b1db_prof);

    }

    // line 4
    public function block_titrePage($context, array $blocks = array())
    {
        $__internal_277b0f1b8cef7f6132c911a4de7b7268979e41b6e06deca42da036ce8f8d1a8d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_277b0f1b8cef7f6132c911a4de7b7268979e41b6e06deca42da036ce8f8d1a8d->enter($__internal_277b0f1b8cef7f6132c911a4de7b7268979e41b6e06deca42da036ce8f8d1a8d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "titrePage"));

        echo "Nouveau chef de chantier pour la société ";
        echo twig_escape_filter($this->env, (isset($context["nomSociete"]) ? $context["nomSociete"] : $this->getContext($context, "nomSociete")), "html", null, true);
        
        $__internal_277b0f1b8cef7f6132c911a4de7b7268979e41b6e06deca42da036ce8f8d1a8d->leave($__internal_277b0f1b8cef7f6132c911a4de7b7268979e41b6e06deca42da036ce8f8d1a8d_prof);

    }

    // line 5
    public function block_contenu($context, array $blocks = array())
    {
        $__internal_07837cc0e2464d230ccf6a4ff54e1aae1db459678a5d1d10e33725bae8a429ab = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_07837cc0e2464d230ccf6a4ff54e1aae1db459678a5d1d10e33725bae8a429ab->enter($__internal_07837cc0e2464d230ccf6a4ff54e1aae1db459678a5d1d10e33725bae8a429ab_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "contenu"));

        // line 6
        echo "    
    <div class=\"col-lg-2\"></div>
    <div class=\"col-lg-8\">
        <h4><center>Nouveau chef de chantier</center></h4>
        <div class=\"hline\"></div><br>
        ";
        // line 11
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form');
        echo "
        <a class=\"btn btn-theme\" href=\"";
        // line 12
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("page_gestion_entrepreneur");
        echo "\">Finir l'inscription (retour page gestion entrepreneur)</a>
    </div>
    
    
";
        
        $__internal_07837cc0e2464d230ccf6a4ff54e1aae1db459678a5d1d10e33725bae8a429ab->leave($__internal_07837cc0e2464d230ccf6a4ff54e1aae1db459678a5d1d10e33725bae8a429ab_prof);

    }

    public function getTemplateName()
    {
        return "mehbatiInterimBundle:Gestionnaire:VueInsererChefChantier.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  78 => 12,  74 => 11,  67 => 6,  61 => 5,  48 => 4,  36 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'mehbatiInterimBundle::base.html.twig' %}

{% block title %}Inserer chef chantier{% endblock %}
{% block titrePage %}Nouveau chef de chantier pour la société {{nomSociete}}{% endblock %}
{% block contenu %}
    
    <div class=\"col-lg-2\"></div>
    <div class=\"col-lg-8\">
        <h4><center>Nouveau chef de chantier</center></h4>
        <div class=\"hline\"></div><br>
        {{form(form)}}
        <a class=\"btn btn-theme\" href=\"{{path('page_gestion_entrepreneur')}}\">Finir l'inscription (retour page gestion entrepreneur)</a>
    </div>
    
    
{% endblock%}

", "mehbatiInterimBundle:Gestionnaire:VueInsererChefChantier.html.twig", "/var/www/batiInterim/src/meh/batiInterimBundle/Resources/views/Gestionnaire/VueInsererChefChantier.html.twig");
    }
}
