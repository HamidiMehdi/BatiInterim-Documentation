<?php

/* mehbatiInterimBundle:Gestionnaire:VueGestionArtisan.html.twig */
class __TwigTemplate_dd784962c3787fdef0629856c49a545aeaef7b1953f86ffc1900680f190bde07 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("mehbatiInterimBundle::base.html.twig", "mehbatiInterimBundle:Gestionnaire:VueGestionArtisan.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'titrePage' => array($this, 'block_titrePage'),
            'contenu' => array($this, 'block_contenu'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "mehbatiInterimBundle::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1ab1f45ab752d927c0781a53e0d7c72b7fe301cadec376196e88fd8b193d3a0a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1ab1f45ab752d927c0781a53e0d7c72b7fe301cadec376196e88fd8b193d3a0a->enter($__internal_1ab1f45ab752d927c0781a53e0d7c72b7fe301cadec376196e88fd8b193d3a0a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "mehbatiInterimBundle:Gestionnaire:VueGestionArtisan.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_1ab1f45ab752d927c0781a53e0d7c72b7fe301cadec376196e88fd8b193d3a0a->leave($__internal_1ab1f45ab752d927c0781a53e0d7c72b7fe301cadec376196e88fd8b193d3a0a_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_ce991940b62806d4b97e067d9b9897b31db8d638e8843f04958e721c31042138 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ce991940b62806d4b97e067d9b9897b31db8d638e8843f04958e721c31042138->enter($__internal_ce991940b62806d4b97e067d9b9897b31db8d638e8843f04958e721c31042138_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Gestion Artisan";
        
        $__internal_ce991940b62806d4b97e067d9b9897b31db8d638e8843f04958e721c31042138->leave($__internal_ce991940b62806d4b97e067d9b9897b31db8d638e8843f04958e721c31042138_prof);

    }

    // line 4
    public function block_titrePage($context, array $blocks = array())
    {
        $__internal_059d29fea48bb223d8c23fa871ec5f9b5fe22ff3cae22af99229ddcc5c566969 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_059d29fea48bb223d8c23fa871ec5f9b5fe22ff3cae22af99229ddcc5c566969->enter($__internal_059d29fea48bb223d8c23fa871ec5f9b5fe22ff3cae22af99229ddcc5c566969_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "titrePage"));

        echo "Gestion Artisan";
        
        $__internal_059d29fea48bb223d8c23fa871ec5f9b5fe22ff3cae22af99229ddcc5c566969->leave($__internal_059d29fea48bb223d8c23fa871ec5f9b5fe22ff3cae22af99229ddcc5c566969_prof);

    }

    // line 5
    public function block_contenu($context, array $blocks = array())
    {
        $__internal_aa15db9d6fcf93202c3e4240c7a56a15f59ec74b68285069ffd21cb013dd2a15 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_aa15db9d6fcf93202c3e4240c7a56a15f59ec74b68285069ffd21cb013dd2a15->enter($__internal_aa15db9d6fcf93202c3e4240c7a56a15f59ec74b68285069ffd21cb013dd2a15_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "contenu"));

        // line 6
        echo "    
    <div class=\"col-lg-1\"></div>
    <div class=\"col-lg-10\">
        <h4><center>Les artisans</center></h4>
        <div class=\"hline\"></div><br>
        ";
        // line 11
        if (((isset($context["artisans"]) ? $context["artisans"] : $this->getContext($context, "artisans")) != null)) {
            // line 12
            echo "        <table class=\"table table-hover\">
            <thead>
                <tr>
                    <th>Nom</th>
                    <th>Prenom</th>
                    <th>Date de naissance</th>
                </tr>
            </thead>
            <tbody>
                
            ";
            // line 22
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["artisans"]) ? $context["artisans"] : $this->getContext($context, "artisans")));
            foreach ($context['_seq'] as $context["_key"] => $context["unArtisan"]) {
                // line 23
                echo "                <tr>
                        <td>";
                // line 24
                echo twig_escape_filter($this->env, $this->getAttribute($context["unArtisan"], "nom", array()), "html", null, true);
                echo "</td>
                        <td>";
                // line 25
                echo twig_escape_filter($this->env, $this->getAttribute($context["unArtisan"], "prenom", array()), "html", null, true);
                echo "</td>
                        <td>";
                // line 26
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["unArtisan"], "dateNaissance", array()), "d/m/Y"), "html", null, true);
                echo "</td>
                        <td><a class=\"btn btn-theme\" href=\"";
                // line 27
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("page_gestion_maj_artisan", array("id" => $this->getAttribute($context["unArtisan"], "idArtisan", array()))), "html", null, true);
                echo "\">Mettre à jour</a></td>
                        <td><a class=\"btn btn-danger\" href=\"";
                // line 28
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("page_gestion_delete_artisan", array("id" => $this->getAttribute($context["unArtisan"], "idArtisan", array()))), "html", null, true);
                echo "\" >Supprimer</a></td>
                    </tr>
            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['unArtisan'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 30
            echo "  
            </tbody>
        </table>
        ";
        } else {
            // line 34
            echo "            Il y a aucun artisan d'inscrit
        ";
        }
        // line 36
        echo "    </div>
    
";
        
        $__internal_aa15db9d6fcf93202c3e4240c7a56a15f59ec74b68285069ffd21cb013dd2a15->leave($__internal_aa15db9d6fcf93202c3e4240c7a56a15f59ec74b68285069ffd21cb013dd2a15_prof);

    }

    public function getTemplateName()
    {
        return "mehbatiInterimBundle:Gestionnaire:VueGestionArtisan.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  129 => 36,  125 => 34,  119 => 30,  110 => 28,  106 => 27,  102 => 26,  98 => 25,  94 => 24,  91 => 23,  87 => 22,  75 => 12,  73 => 11,  66 => 6,  60 => 5,  48 => 4,  36 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'mehbatiInterimBundle::base.html.twig' %}

{% block title %}Gestion Artisan{% endblock %}
{% block titrePage %}Gestion Artisan{% endblock %}
{% block contenu %}
    
    <div class=\"col-lg-1\"></div>
    <div class=\"col-lg-10\">
        <h4><center>Les artisans</center></h4>
        <div class=\"hline\"></div><br>
        {% if artisans != null %}
        <table class=\"table table-hover\">
            <thead>
                <tr>
                    <th>Nom</th>
                    <th>Prenom</th>
                    <th>Date de naissance</th>
                </tr>
            </thead>
            <tbody>
                
            {% for unArtisan in artisans %}
                <tr>
                        <td>{{unArtisan.nom}}</td>
                        <td>{{unArtisan.prenom}}</td>
                        <td>{{unArtisan.dateNaissance|date('d/m/Y')}}</td>
                        <td><a class=\"btn btn-theme\" href=\"{{path('page_gestion_maj_artisan', {'id': unArtisan.idArtisan })}}\">Mettre à jour</a></td>
                        <td><a class=\"btn btn-danger\" href=\"{{path('page_gestion_delete_artisan', {'id': unArtisan.idArtisan })}}\" >Supprimer</a></td>
                    </tr>
            {% endfor %}  
            </tbody>
        </table>
        {% else %}
            Il y a aucun artisan d'inscrit
        {% endif %}
    </div>
    
{% endblock%}
", "mehbatiInterimBundle:Gestionnaire:VueGestionArtisan.html.twig", "/var/www/batiInterim/src/meh/batiInterimBundle/Resources/views/Gestionnaire/VueGestionArtisan.html.twig");
    }
}
