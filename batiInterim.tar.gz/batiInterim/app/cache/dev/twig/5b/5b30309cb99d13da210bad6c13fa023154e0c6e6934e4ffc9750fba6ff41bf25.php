<?php

/* mehbatiInterimBundle:Entrepreneur_ChefChantier:VueCongeDunArtisan.html.twig */
class __TwigTemplate_a0b558bb927ace2790e0642ec200d8a473fef580ed7f85cc2ea296b3d1517e3f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("mehbatiInterimBundle::base.html.twig", "mehbatiInterimBundle:Entrepreneur_ChefChantier:VueCongeDunArtisan.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'titrePage' => array($this, 'block_titrePage'),
            'contenu' => array($this, 'block_contenu'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "mehbatiInterimBundle::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_42931a3c7311d4a441f9ebd3b9cc162add95e026be804dea21c862f55ed63ed0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_42931a3c7311d4a441f9ebd3b9cc162add95e026be804dea21c862f55ed63ed0->enter($__internal_42931a3c7311d4a441f9ebd3b9cc162add95e026be804dea21c862f55ed63ed0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "mehbatiInterimBundle:Entrepreneur_ChefChantier:VueCongeDunArtisan.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_42931a3c7311d4a441f9ebd3b9cc162add95e026be804dea21c862f55ed63ed0->leave($__internal_42931a3c7311d4a441f9ebd3b9cc162add95e026be804dea21c862f55ed63ed0_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_ca73daae6148d1065c5c056090c9b72ed03d57cb064b4b2fb3e37c40905539f4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ca73daae6148d1065c5c056090c9b72ed03d57cb064b4b2fb3e37c40905539f4->enter($__internal_ca73daae6148d1065c5c056090c9b72ed03d57cb064b4b2fb3e37c40905539f4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Conges d'un artisan";
        
        $__internal_ca73daae6148d1065c5c056090c9b72ed03d57cb064b4b2fb3e37c40905539f4->leave($__internal_ca73daae6148d1065c5c056090c9b72ed03d57cb064b4b2fb3e37c40905539f4_prof);

    }

    // line 4
    public function block_titrePage($context, array $blocks = array())
    {
        $__internal_66e2a5487b4bc6cc69fb5f19bb42208e1246dceda98b7f7696ece6928900f5b5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_66e2a5487b4bc6cc69fb5f19bb42208e1246dceda98b7f7696ece6928900f5b5->enter($__internal_66e2a5487b4bc6cc69fb5f19bb42208e1246dceda98b7f7696ece6928900f5b5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "titrePage"));

        echo "Conges d'un artisan";
        
        $__internal_66e2a5487b4bc6cc69fb5f19bb42208e1246dceda98b7f7696ece6928900f5b5->leave($__internal_66e2a5487b4bc6cc69fb5f19bb42208e1246dceda98b7f7696ece6928900f5b5_prof);

    }

    // line 5
    public function block_contenu($context, array $blocks = array())
    {
        $__internal_256d2b46ac3a0107ee92df44ea35cf369af6b4e0148165352348f64bcd46c3af = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_256d2b46ac3a0107ee92df44ea35cf369af6b4e0148165352348f64bcd46c3af->enter($__internal_256d2b46ac3a0107ee92df44ea35cf369af6b4e0148165352348f64bcd46c3af_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "contenu"));

        // line 6
        echo "    
    <div class=\"col-lg-1\"></div>
    <div class=\"col-lg-10\">
        <h4><center>Choisir l'artisan</center></h4>
        <div class=\"hline\"></div><br>
        ";
        // line 11
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form');
        echo "
        ";
        // line 12
        if ( !twig_test_empty((isset($context["conges"]) ? $context["conges"] : $this->getContext($context, "conges")))) {
            // line 13
            echo "            <div class=\"hline\"></div><br>
            
            <table class=\"table table-hover\">
                <thead>
                    <tr>
                        <th>Artisan</th>
                        <th>Date de début</th>
                        <th>Date de fin</th>
                        <th>Etat</th>
                    </tr>
                </thead>
                <tbody>

                ";
            // line 26
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["conges"]) ? $context["conges"] : $this->getContext($context, "conges")));
            foreach ($context['_seq'] as $context["_key"] => $context["unConge"]) {
                // line 27
                echo "                    ";
                if (($this->getAttribute($context["unConge"], "valider", array()) != "Refuser")) {
                    // line 28
                    echo "                    <tr>
                        <td>";
                    // line 29
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["unConge"], "idartisan", array()), "nom", array()), "html", null, true);
                    echo " ";
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["unConge"], "idartisan", array()), "prenom", array()), "html", null, true);
                    echo "</td>
                        <td>";
                    // line 30
                    echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["unConge"], "dateDebut", array()), "d/m/Y"), "html", null, true);
                    echo "</td>
                        <td>";
                    // line 31
                    echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["unConge"], "dateFin", array()), "d/m/Y"), "html", null, true);
                    echo "</td>
                        <td>";
                    // line 32
                    echo twig_escape_filter($this->env, $this->getAttribute($context["unConge"], "valider", array()), "html", null, true);
                    echo "</td>
                    </tr>
                    ";
                }
                // line 35
                echo "                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['unConge'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 36
            echo "                </tbody>
            </table> 
        ";
        }
        // line 38
        echo "   
    </div>
        
";
        
        $__internal_256d2b46ac3a0107ee92df44ea35cf369af6b4e0148165352348f64bcd46c3af->leave($__internal_256d2b46ac3a0107ee92df44ea35cf369af6b4e0148165352348f64bcd46c3af_prof);

    }

    public function getTemplateName()
    {
        return "mehbatiInterimBundle:Entrepreneur_ChefChantier:VueCongeDunArtisan.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  135 => 38,  130 => 36,  124 => 35,  118 => 32,  114 => 31,  110 => 30,  104 => 29,  101 => 28,  98 => 27,  94 => 26,  79 => 13,  77 => 12,  73 => 11,  66 => 6,  60 => 5,  48 => 4,  36 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'mehbatiInterimBundle::base.html.twig' %}

{% block title %}Conges d'un artisan{% endblock %}
{% block titrePage %}Conges d'un artisan{% endblock %}
{% block contenu %}
    
    <div class=\"col-lg-1\"></div>
    <div class=\"col-lg-10\">
        <h4><center>Choisir l'artisan</center></h4>
        <div class=\"hline\"></div><br>
        {{form(form)}}
        {% if conges is not empty %}
            <div class=\"hline\"></div><br>
            
            <table class=\"table table-hover\">
                <thead>
                    <tr>
                        <th>Artisan</th>
                        <th>Date de début</th>
                        <th>Date de fin</th>
                        <th>Etat</th>
                    </tr>
                </thead>
                <tbody>

                {% for unConge in conges %}
                    {% if unConge.valider != \"Refuser\" %}
                    <tr>
                        <td>{{unConge.idartisan.nom}} {{unConge.idartisan.prenom}}</td>
                        <td>{{unConge.dateDebut|date('d/m/Y')}}</td>
                        <td>{{unConge.dateFin|date('d/m/Y')}}</td>
                        <td>{{unConge.valider}}</td>
                    </tr>
                    {% endif %}
                {% endfor %}
                </tbody>
            </table> 
        {% endif %}   
    </div>
        
{% endblock%}

", "mehbatiInterimBundle:Entrepreneur_ChefChantier:VueCongeDunArtisan.html.twig", "/var/www/batiInterim/src/meh/batiInterimBundle/Resources/views/Entrepreneur_ChefChantier/VueCongeDunArtisan.html.twig");
    }
}
