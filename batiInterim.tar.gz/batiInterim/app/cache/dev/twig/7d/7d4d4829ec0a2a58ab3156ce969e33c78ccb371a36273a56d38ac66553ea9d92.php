<?php

/* mehbatiInterimBundle:Entrepreneur_ChefChantier:VueAffecterMissionChantier.html.twig */
class __TwigTemplate_3acf8948fe10a4c07f0d7c7dee9967db314e57b9e136258207c0310019058e67 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("mehbatiInterimBundle::base.html.twig", "mehbatiInterimBundle:Entrepreneur_ChefChantier:VueAffecterMissionChantier.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'titrePage' => array($this, 'block_titrePage'),
            'contenu' => array($this, 'block_contenu'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "mehbatiInterimBundle::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_09f11e72005051b6bcf42b96bf14dd1a9138e429e2bf0525f9705f48ca7d1e94 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_09f11e72005051b6bcf42b96bf14dd1a9138e429e2bf0525f9705f48ca7d1e94->enter($__internal_09f11e72005051b6bcf42b96bf14dd1a9138e429e2bf0525f9705f48ca7d1e94_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "mehbatiInterimBundle:Entrepreneur_ChefChantier:VueAffecterMissionChantier.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_09f11e72005051b6bcf42b96bf14dd1a9138e429e2bf0525f9705f48ca7d1e94->leave($__internal_09f11e72005051b6bcf42b96bf14dd1a9138e429e2bf0525f9705f48ca7d1e94_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_8fc9ab4a823092a8e63beee11dd87ea259deb0e4c4a2006e159d97f23bc2fe3c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8fc9ab4a823092a8e63beee11dd87ea259deb0e4c4a2006e159d97f23bc2fe3c->enter($__internal_8fc9ab4a823092a8e63beee11dd87ea259deb0e4c4a2006e159d97f23bc2fe3c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Affecter mission chantier";
        
        $__internal_8fc9ab4a823092a8e63beee11dd87ea259deb0e4c4a2006e159d97f23bc2fe3c->leave($__internal_8fc9ab4a823092a8e63beee11dd87ea259deb0e4c4a2006e159d97f23bc2fe3c_prof);

    }

    // line 4
    public function block_titrePage($context, array $blocks = array())
    {
        $__internal_aa159eca403ee2e1be28f722622cb82b175681eda079e265a81890d9b5c39012 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_aa159eca403ee2e1be28f722622cb82b175681eda079e265a81890d9b5c39012->enter($__internal_aa159eca403ee2e1be28f722622cb82b175681eda079e265a81890d9b5c39012_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "titrePage"));

        echo "Affecter mission à un chantier";
        
        $__internal_aa159eca403ee2e1be28f722622cb82b175681eda079e265a81890d9b5c39012->leave($__internal_aa159eca403ee2e1be28f722622cb82b175681eda079e265a81890d9b5c39012_prof);

    }

    // line 5
    public function block_contenu($context, array $blocks = array())
    {
        $__internal_b8372a17825e1881500764a426320b475e68ce48cd3d23e559fc1f1fbc95b145 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b8372a17825e1881500764a426320b475e68ce48cd3d23e559fc1f1fbc95b145->enter($__internal_b8372a17825e1881500764a426320b475e68ce48cd3d23e559fc1f1fbc95b145_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "contenu"));

        // line 6
        echo "    
    <div class=\"col-lg-1\"></div>
    <div class=\"col-lg-10\">
        <h4><center>Selectionné le chantier </center></h4>
        <div class=\"hline\"></div><br>
        ";
        // line 11
        if ((twig_length_filter($this->env, (isset($context["chantiers"]) ? $context["chantiers"] : $this->getContext($context, "chantiers"))) >= 1)) {
            // line 12
            echo "            <table class=\"table table-hover\">
                <thead>
                    <tr>
                        <th>Chantier numéro</th>
                        <th>Nom</th>
                        <th>Chef du chantier</th>
                        <th>Entrepreneur</th>
                    </tr>
                </thead>
                <tbody>

                ";
            // line 23
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["chantiers"]) ? $context["chantiers"] : $this->getContext($context, "chantiers")));
            foreach ($context['_seq'] as $context["_key"] => $context["unChantier"]) {
                // line 24
                echo "                    <tr>
                        <td>";
                // line 25
                echo twig_escape_filter($this->env, $this->getAttribute($context["unChantier"], "idchantier", array()), "html", null, true);
                echo "</td>
                        <td>";
                // line 26
                echo twig_escape_filter($this->env, $this->getAttribute($context["unChantier"], "nom", array()), "html", null, true);
                echo "</td>
                        <td>";
                // line 27
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["unChantier"], "idchefchantier", array()), "nom", array()), "html", null, true);
                echo " ";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["unChantier"], "idchefchantier", array()), "prenom", array()), "html", null, true);
                echo "</td>
                        <td>";
                // line 28
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["unChantier"], "identrepreneur", array()), "nomsociete", array()), "html", null, true);
                echo "</td>
                        <td><a class=\"btn btn-theme\" href=\"";
                // line 29
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("page_affecter_artisan_mission", array("id" => $this->getAttribute($context["unChantier"], "idchantier", array()))), "html", null, true);
                echo "\">Selectionné</a></td>
                    </tr>
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['unChantier'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 32
            echo "                </tbody>
            </table> 
        ";
        } else {
            // line 34
            echo "    
            Vous n'avez pas de chantier.
        ";
        }
        // line 36
        echo "   
    </div>
        
";
        
        $__internal_b8372a17825e1881500764a426320b475e68ce48cd3d23e559fc1f1fbc95b145->leave($__internal_b8372a17825e1881500764a426320b475e68ce48cd3d23e559fc1f1fbc95b145_prof);

    }

    public function getTemplateName()
    {
        return "mehbatiInterimBundle:Entrepreneur_ChefChantier:VueAffecterMissionChantier.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  132 => 36,  127 => 34,  122 => 32,  113 => 29,  109 => 28,  103 => 27,  99 => 26,  95 => 25,  92 => 24,  88 => 23,  75 => 12,  73 => 11,  66 => 6,  60 => 5,  48 => 4,  36 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'mehbatiInterimBundle::base.html.twig' %}

{% block title %}Affecter mission chantier{% endblock %}
{% block titrePage %}Affecter mission à un chantier{% endblock %}
{% block contenu %}
    
    <div class=\"col-lg-1\"></div>
    <div class=\"col-lg-10\">
        <h4><center>Selectionné le chantier </center></h4>
        <div class=\"hline\"></div><br>
        {% if chantiers|length >=1 %}
            <table class=\"table table-hover\">
                <thead>
                    <tr>
                        <th>Chantier numéro</th>
                        <th>Nom</th>
                        <th>Chef du chantier</th>
                        <th>Entrepreneur</th>
                    </tr>
                </thead>
                <tbody>

                {% for unChantier in chantiers %}
                    <tr>
                        <td>{{unChantier.idchantier}}</td>
                        <td>{{unChantier.nom}}</td>
                        <td>{{unChantier.idchefchantier.nom}} {{unChantier.idchefchantier.prenom}}</td>
                        <td>{{unChantier.identrepreneur.nomsociete}}</td>
                        <td><a class=\"btn btn-theme\" href=\"{{path('page_affecter_artisan_mission', {'id': unChantier.idchantier })}}\">Selectionné</a></td>
                    </tr>
                {% endfor %}
                </tbody>
            </table> 
        {% else %}    
            Vous n'avez pas de chantier.
        {% endif %}   
    </div>
        
{% endblock%}

", "mehbatiInterimBundle:Entrepreneur_ChefChantier:VueAffecterMissionChantier.html.twig", "/var/www/batiInterim/src/meh/batiInterimBundle/Resources/views/Entrepreneur_ChefChantier/VueAffecterMissionChantier.html.twig");
    }
}
