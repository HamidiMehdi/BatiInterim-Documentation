<?php

/* mehbatiInterimBundle:Entrepreneur_ChefChantier:VueAffecterArtisan.html.twig */
class __TwigTemplate_722863f2e9dfb35179831fcc5f6ecf285cb9d3c8ebb2860b5c3610a252eec3c6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("mehbatiInterimBundle::base.html.twig", "mehbatiInterimBundle:Entrepreneur_ChefChantier:VueAffecterArtisan.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'titrePage' => array($this, 'block_titrePage'),
            'contenu' => array($this, 'block_contenu'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "mehbatiInterimBundle::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_bc72c8c695076ec6427b1011fa30cfe7a538f01526b3044603a25f3bcf1941ea = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bc72c8c695076ec6427b1011fa30cfe7a538f01526b3044603a25f3bcf1941ea->enter($__internal_bc72c8c695076ec6427b1011fa30cfe7a538f01526b3044603a25f3bcf1941ea_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "mehbatiInterimBundle:Entrepreneur_ChefChantier:VueAffecterArtisan.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_bc72c8c695076ec6427b1011fa30cfe7a538f01526b3044603a25f3bcf1941ea->leave($__internal_bc72c8c695076ec6427b1011fa30cfe7a538f01526b3044603a25f3bcf1941ea_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_d9b8aeda1b383628139bc0408f5441dc9c3cd2cde1589e973e712d53a9f97ef0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d9b8aeda1b383628139bc0408f5441dc9c3cd2cde1589e973e712d53a9f97ef0->enter($__internal_d9b8aeda1b383628139bc0408f5441dc9c3cd2cde1589e973e712d53a9f97ef0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Affecter artisan";
        
        $__internal_d9b8aeda1b383628139bc0408f5441dc9c3cd2cde1589e973e712d53a9f97ef0->leave($__internal_d9b8aeda1b383628139bc0408f5441dc9c3cd2cde1589e973e712d53a9f97ef0_prof);

    }

    // line 4
    public function block_titrePage($context, array $blocks = array())
    {
        $__internal_4d3275a06853266a976e5b52abbfc660282f3c4674989da48ffabbd6020be2ff = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4d3275a06853266a976e5b52abbfc660282f3c4674989da48ffabbd6020be2ff->enter($__internal_4d3275a06853266a976e5b52abbfc660282f3c4674989da48ffabbd6020be2ff_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "titrePage"));

        echo "Affecter artisan à la mission selectionnée";
        
        $__internal_4d3275a06853266a976e5b52abbfc660282f3c4674989da48ffabbd6020be2ff->leave($__internal_4d3275a06853266a976e5b52abbfc660282f3c4674989da48ffabbd6020be2ff_prof);

    }

    // line 5
    public function block_contenu($context, array $blocks = array())
    {
        $__internal_3d60b880ebc43d11345111189cba2ceea5b3a8f9dfb2ec4ef79ddf2de45de5b7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3d60b880ebc43d11345111189cba2ceea5b3a8f9dfb2ec4ef79ddf2de45de5b7->enter($__internal_3d60b880ebc43d11345111189cba2ceea5b3a8f9dfb2ec4ef79ddf2de45de5b7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "contenu"));

        // line 6
        echo "    
    <div class=\"col-lg-1\"></div>
    <div class=\"col-lg-10\">
        <h4><center>Choisir les artisans a affecter</center></h4>
        <div class=\"hline\"></div><br>
        ";
        // line 11
        if ( !twig_test_empty((isset($context["artisans"]) ? $context["artisans"] : $this->getContext($context, "artisans")))) {
            // line 12
            echo "            <table class=\"table table-hover\">
                <thead>
                    <tr>
                        <th>Nom</th>
                        <th>Prenom</th>
                        <th>Date de naissance</th>
                        <th>Lieu de naissance</th>
                        <th>Numero de telephone</th>
                        <th>Adresse</th>
                    </tr>
                </thead>
                <tbody>

                ";
            // line 25
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["artisans"]) ? $context["artisans"] : $this->getContext($context, "artisans")));
            foreach ($context['_seq'] as $context["_key"] => $context["unArtisan"]) {
                // line 26
                echo "                    <tr>
                        <td>";
                // line 27
                echo twig_escape_filter($this->env, $this->getAttribute($context["unArtisan"], "nom", array()), "html", null, true);
                echo "</td>
                        <td>";
                // line 28
                echo twig_escape_filter($this->env, $this->getAttribute($context["unArtisan"], "prenom", array()), "html", null, true);
                echo "</td>
                        <td>";
                // line 29
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["unArtisan"], "dateNaissance", array()), "d/m/Y"), "html", null, true);
                echo "</td>
                        <td>";
                // line 30
                echo twig_escape_filter($this->env, $this->getAttribute($context["unArtisan"], "lieuNaissance", array()), "html", null, true);
                echo "</td>
                        <td>";
                // line 31
                echo twig_escape_filter($this->env, $this->getAttribute($context["unArtisan"], "numTel", array()), "html", null, true);
                echo "</td>
                        <td>";
                // line 32
                echo twig_escape_filter($this->env, $this->getAttribute($context["unArtisan"], "adresse", array()), "html", null, true);
                echo ", ";
                echo twig_escape_filter($this->env, $this->getAttribute($context["unArtisan"], "cp", array()), "html", null, true);
                echo "</td>
                        <td><a class=\"btn btn-theme\" href=\"";
                // line 33
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("affecter_artisan_mission", array("idMission" => $this->getAttribute((isset($context["mission"]) ? $context["mission"] : $this->getContext($context, "mission")), "idmission", array()), "idArtisan" => $this->getAttribute($context["unArtisan"], "idartisan", array()))), "html", null, true);
                echo "\">Affecter</a></td>
                    </tr>
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['unArtisan'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 36
            echo "                </tbody>
            </table> 
        ";
        } else {
            // line 38
            echo " 
            Il n'y a aucun artisan pour ce corps de métier ou aucun artisan n'est disponible.
        ";
        }
        // line 40
        echo "   
        
        
    </div>
        
";
        
        $__internal_3d60b880ebc43d11345111189cba2ceea5b3a8f9dfb2ec4ef79ddf2de45de5b7->leave($__internal_3d60b880ebc43d11345111189cba2ceea5b3a8f9dfb2ec4ef79ddf2de45de5b7_prof);

    }

    public function getTemplateName()
    {
        return "mehbatiInterimBundle:Entrepreneur_ChefChantier:VueAffecterArtisan.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  142 => 40,  137 => 38,  132 => 36,  123 => 33,  117 => 32,  113 => 31,  109 => 30,  105 => 29,  101 => 28,  97 => 27,  94 => 26,  90 => 25,  75 => 12,  73 => 11,  66 => 6,  60 => 5,  48 => 4,  36 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'mehbatiInterimBundle::base.html.twig' %}

{% block title %}Affecter artisan{% endblock %}
{% block titrePage %}Affecter artisan à la mission selectionnée{% endblock %}
{% block contenu %}
    
    <div class=\"col-lg-1\"></div>
    <div class=\"col-lg-10\">
        <h4><center>Choisir les artisans a affecter</center></h4>
        <div class=\"hline\"></div><br>
        {% if artisans is not empty %}
            <table class=\"table table-hover\">
                <thead>
                    <tr>
                        <th>Nom</th>
                        <th>Prenom</th>
                        <th>Date de naissance</th>
                        <th>Lieu de naissance</th>
                        <th>Numero de telephone</th>
                        <th>Adresse</th>
                    </tr>
                </thead>
                <tbody>

                {% for unArtisan in artisans %}
                    <tr>
                        <td>{{unArtisan.nom}}</td>
                        <td>{{unArtisan.prenom}}</td>
                        <td>{{unArtisan.dateNaissance|date('d/m/Y')}}</td>
                        <td>{{unArtisan.lieuNaissance}}</td>
                        <td>{{unArtisan.numTel}}</td>
                        <td>{{unArtisan.adresse}}, {{unArtisan.cp}}</td>
                        <td><a class=\"btn btn-theme\" href=\"{{path('affecter_artisan_mission', {'idMission': mission.idmission, 'idArtisan': unArtisan.idartisan })}}\">Affecter</a></td>
                    </tr>
                {% endfor %}
                </tbody>
            </table> 
        {% else %} 
            Il n'y a aucun artisan pour ce corps de métier ou aucun artisan n'est disponible.
        {% endif %}   
        
        
    </div>
        
{% endblock%}

", "mehbatiInterimBundle:Entrepreneur_ChefChantier:VueAffecterArtisan.html.twig", "/var/www/batiInterim/src/meh/batiInterimBundle/Resources/views/Entrepreneur_ChefChantier/VueAffecterArtisan.html.twig");
    }
}
