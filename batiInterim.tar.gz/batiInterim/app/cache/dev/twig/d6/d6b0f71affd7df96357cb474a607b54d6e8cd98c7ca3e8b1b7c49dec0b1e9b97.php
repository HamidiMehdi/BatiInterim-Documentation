<?php

/* mehbatiInterimBundle:Entrepreneur_ChefChantier:VueGestionAffecter.html.twig */
class __TwigTemplate_bd8207040ef8a75edb314cd36873431887a52370e8560ea035beeba6f48124b7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("mehbatiInterimBundle::base.html.twig", "mehbatiInterimBundle:Entrepreneur_ChefChantier:VueGestionAffecter.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'titrePage' => array($this, 'block_titrePage'),
            'contenu' => array($this, 'block_contenu'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "mehbatiInterimBundle::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_483dbde6e80db9980d9efbdb5f03431d06af89ccc8b2e7b199a929c5562dd8e9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_483dbde6e80db9980d9efbdb5f03431d06af89ccc8b2e7b199a929c5562dd8e9->enter($__internal_483dbde6e80db9980d9efbdb5f03431d06af89ccc8b2e7b199a929c5562dd8e9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "mehbatiInterimBundle:Entrepreneur_ChefChantier:VueGestionAffecter.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_483dbde6e80db9980d9efbdb5f03431d06af89ccc8b2e7b199a929c5562dd8e9->leave($__internal_483dbde6e80db9980d9efbdb5f03431d06af89ccc8b2e7b199a929c5562dd8e9_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_7529b6ff6058ec888c5db6397c6020df0e1b078004c37e4485b5f8a96ebbd0bb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7529b6ff6058ec888c5db6397c6020df0e1b078004c37e4485b5f8a96ebbd0bb->enter($__internal_7529b6ff6058ec888c5db6397c6020df0e1b078004c37e4485b5f8a96ebbd0bb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Liste affectations";
        
        $__internal_7529b6ff6058ec888c5db6397c6020df0e1b078004c37e4485b5f8a96ebbd0bb->leave($__internal_7529b6ff6058ec888c5db6397c6020df0e1b078004c37e4485b5f8a96ebbd0bb_prof);

    }

    // line 4
    public function block_titrePage($context, array $blocks = array())
    {
        $__internal_f3b2b0da38a645a47b079761407dc38c8f1c3b299a9d9fe61cae0e9fdf805c61 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f3b2b0da38a645a47b079761407dc38c8f1c3b299a9d9fe61cae0e9fdf805c61->enter($__internal_f3b2b0da38a645a47b079761407dc38c8f1c3b299a9d9fe61cae0e9fdf805c61_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "titrePage"));

        echo "Liste affectations";
        
        $__internal_f3b2b0da38a645a47b079761407dc38c8f1c3b299a9d9fe61cae0e9fdf805c61->leave($__internal_f3b2b0da38a645a47b079761407dc38c8f1c3b299a9d9fe61cae0e9fdf805c61_prof);

    }

    // line 5
    public function block_contenu($context, array $blocks = array())
    {
        $__internal_60de4aed8c6b8951f93dd265a09608e49960735e17905a2c111ccf4f965e6f3a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_60de4aed8c6b8951f93dd265a09608e49960735e17905a2c111ccf4f965e6f3a->enter($__internal_60de4aed8c6b8951f93dd265a09608e49960735e17905a2c111ccf4f965e6f3a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "contenu"));

        // line 6
        echo "    
    <div class=\"col-lg-1\"></div>
    <div class=\"col-lg-10\">
        <h4><center>Liste des affectations a un mission </center></h4>
        <div class=\"hline\"></div><br>
        ";
        // line 11
        if ((twig_length_filter($this->env, (isset($context["lesAffecter"]) ? $context["lesAffecter"] : $this->getContext($context, "lesAffecter"))) >= 1)) {
            // line 12
            echo "            <table class=\"table table-hover\">
                <thead>
                    <tr>
                        <th>Mission</th>
                        <th>Date mission</th>
                        <th>Artisan</th>
                        <th>Etat</th>
                    </tr>
                </thead>
                <tbody>

                ";
            // line 23
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["lesAffecter"]) ? $context["lesAffecter"] : $this->getContext($context, "lesAffecter")));
            foreach ($context['_seq'] as $context["_key"] => $context["unAffecter"]) {
                // line 24
                echo "                    <tr>
                        <td>";
                // line 25
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["unAffecter"], "idmission", array()), "intitule", array()), "html", null, true);
                echo "</td>
                        <td>";
                // line 26
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($this->getAttribute($context["unAffecter"], "idmission", array()), "datedebut", array()), "d/m/Y"), "html", null, true);
                echo " au ";
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($this->getAttribute($context["unAffecter"], "idmission", array()), "datefin", array()), "d/m/Y"), "html", null, true);
                echo "</td>
                        <td>";
                // line 27
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["unAffecter"], "idartisan", array()), "nom", array()), "html", null, true);
                echo " ";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["unAffecter"], "idartisan", array()), "prenom", array()), "html", null, true);
                echo "</td>
                        <td>";
                // line 28
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["unAffecter"], "idetat", array()), "alias", array()), "html", null, true);
                echo " (";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["unAffecter"], "idetat", array()), "libelle", array()), "html", null, true);
                echo ")</td>
                        <td><a class=\"btn btn-danger\" href=\"";
                // line 29
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("delete_une_affectation", array("idMission" => $this->getAttribute($this->getAttribute($context["unAffecter"], "idmission", array()), "idmission", array()), "idArtisan" => $this->getAttribute($this->getAttribute($context["unAffecter"], "idartisan", array()), "idartisan", array()))), "html", null, true);
                echo "\">Supprimer</a></td>
                    </tr>
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['unAffecter'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 32
            echo "                </tbody>
            </table> 
        ";
        } else {
            // line 34
            echo "    
            Il y a aucun artisan affecté a une mission.
        ";
        }
        // line 36
        echo "   
    </div>
        
";
        
        $__internal_60de4aed8c6b8951f93dd265a09608e49960735e17905a2c111ccf4f965e6f3a->leave($__internal_60de4aed8c6b8951f93dd265a09608e49960735e17905a2c111ccf4f965e6f3a_prof);

    }

    public function getTemplateName()
    {
        return "mehbatiInterimBundle:Entrepreneur_ChefChantier:VueGestionAffecter.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  136 => 36,  131 => 34,  126 => 32,  117 => 29,  111 => 28,  105 => 27,  99 => 26,  95 => 25,  92 => 24,  88 => 23,  75 => 12,  73 => 11,  66 => 6,  60 => 5,  48 => 4,  36 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'mehbatiInterimBundle::base.html.twig' %}

{% block title %}Liste affectations{% endblock %}
{% block titrePage %}Liste affectations{% endblock %}
{% block contenu %}
    
    <div class=\"col-lg-1\"></div>
    <div class=\"col-lg-10\">
        <h4><center>Liste des affectations a un mission </center></h4>
        <div class=\"hline\"></div><br>
        {% if lesAffecter|length >=1 %}
            <table class=\"table table-hover\">
                <thead>
                    <tr>
                        <th>Mission</th>
                        <th>Date mission</th>
                        <th>Artisan</th>
                        <th>Etat</th>
                    </tr>
                </thead>
                <tbody>

                {% for unAffecter in lesAffecter %}
                    <tr>
                        <td>{{unAffecter.idmission.intitule}}</td>
                        <td>{{unAffecter.idmission.datedebut|date('d/m/Y')}} au {{unAffecter.idmission.datefin|date('d/m/Y')}}</td>
                        <td>{{unAffecter.idartisan.nom}} {{unAffecter.idartisan.prenom}}</td>
                        <td>{{unAffecter.idetat.alias}} ({{unAffecter.idetat.libelle}})</td>
                        <td><a class=\"btn btn-danger\" href=\"{{path('delete_une_affectation', {'idMission': unAffecter.idmission.idmission, 'idArtisan': unAffecter.idartisan.idartisan })}}\">Supprimer</a></td>
                    </tr>
                {% endfor %}
                </tbody>
            </table> 
        {% else %}    
            Il y a aucun artisan affecté a une mission.
        {% endif %}   
    </div>
        
{% endblock%}


", "mehbatiInterimBundle:Entrepreneur_ChefChantier:VueGestionAffecter.html.twig", "/var/www/batiInterim/src/meh/batiInterimBundle/Resources/views/Entrepreneur_ChefChantier/VueGestionAffecter.html.twig");
    }
}
