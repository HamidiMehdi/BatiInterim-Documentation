<?php

/* mehbatiInterimBundle:Artisan:VueMajCoordonnee.html.twig */
class __TwigTemplate_dcc5842bea3bc7af6d008af51bb5bcbe0dafd9dffead41d07a17e91197deb193 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("mehbatiInterimBundle::base.html.twig", "mehbatiInterimBundle:Artisan:VueMajCoordonnee.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'titrePage' => array($this, 'block_titrePage'),
            'contenu' => array($this, 'block_contenu'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "mehbatiInterimBundle::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_cc8fccce8ce014e2ee6580c84cb6d8ee4be048265d669c83e783bc841d7e894a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cc8fccce8ce014e2ee6580c84cb6d8ee4be048265d669c83e783bc841d7e894a->enter($__internal_cc8fccce8ce014e2ee6580c84cb6d8ee4be048265d669c83e783bc841d7e894a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "mehbatiInterimBundle:Artisan:VueMajCoordonnee.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_cc8fccce8ce014e2ee6580c84cb6d8ee4be048265d669c83e783bc841d7e894a->leave($__internal_cc8fccce8ce014e2ee6580c84cb6d8ee4be048265d669c83e783bc841d7e894a_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_bf9f4555e26b0d27657c3a017d86d987dae9ffdbbc0480b0e29080f024666202 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bf9f4555e26b0d27657c3a017d86d987dae9ffdbbc0480b0e29080f024666202->enter($__internal_bf9f4555e26b0d27657c3a017d86d987dae9ffdbbc0480b0e29080f024666202_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Mise a jour Artisan";
        
        $__internal_bf9f4555e26b0d27657c3a017d86d987dae9ffdbbc0480b0e29080f024666202->leave($__internal_bf9f4555e26b0d27657c3a017d86d987dae9ffdbbc0480b0e29080f024666202_prof);

    }

    // line 4
    public function block_titrePage($context, array $blocks = array())
    {
        $__internal_70b71d6aa1eac1c561f0e5d10d5f6b2be9c0b53cf3979cdab4af67a91c1b1106 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_70b71d6aa1eac1c561f0e5d10d5f6b2be9c0b53cf3979cdab4af67a91c1b1106->enter($__internal_70b71d6aa1eac1c561f0e5d10d5f6b2be9c0b53cf3979cdab4af67a91c1b1106_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "titrePage"));

        echo "Mise à jour des coordonnées";
        
        $__internal_70b71d6aa1eac1c561f0e5d10d5f6b2be9c0b53cf3979cdab4af67a91c1b1106->leave($__internal_70b71d6aa1eac1c561f0e5d10d5f6b2be9c0b53cf3979cdab4af67a91c1b1106_prof);

    }

    // line 5
    public function block_contenu($context, array $blocks = array())
    {
        $__internal_09258a1ccc5e3dca0a817ebc18ba2d4e1308eefdb096b592834bac74334a636e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_09258a1ccc5e3dca0a817ebc18ba2d4e1308eefdb096b592834bac74334a636e->enter($__internal_09258a1ccc5e3dca0a817ebc18ba2d4e1308eefdb096b592834bac74334a636e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "contenu"));

        // line 6
        echo "    <div class=\"col-lg-1\"></div>
    <div class=\"col-lg-12\">
        <h4><center>Données de l'artisan</center></h4>
        <div class=\"hline\"></div><br>
    </div><br>
    
    <div class=\"col-lg-5\">
        <h3>Données actuel</h3>
        
        ";
        // line 15
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["artisanDisabled"]) ? $context["artisanDisabled"] : $this->getContext($context, "artisanDisabled")), 'form');
        echo "
    </div>
    <div class=\"col-lg-1\"></div>
    <div class=\"col-lg-5\">
        <h3>Données à modifier</h3>
        
        ";
        // line 21
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["artisan"]) ? $context["artisan"] : $this->getContext($context, "artisan")), 'form_start');
        echo "
            ";
        // line 22
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["artisan"]) ? $context["artisan"] : $this->getContext($context, "artisan")), "nom", array()), 'label');
        echo "
            ";
        // line 23
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["artisan"]) ? $context["artisan"] : $this->getContext($context, "artisan")), "nom", array()), 'widget');
        echo "
                            
            ";
        // line 25
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["artisan"]) ? $context["artisan"] : $this->getContext($context, "artisan")), "prenom", array()), 'label');
        echo "
            ";
        // line 26
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["artisan"]) ? $context["artisan"] : $this->getContext($context, "artisan")), "prenom", array()), 'widget');
        echo "
            
            ";
        // line 28
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["artisan"]) ? $context["artisan"] : $this->getContext($context, "artisan")), "dateNaissance", array()), 'label');
        echo "
            ";
        // line 29
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["artisan"]) ? $context["artisan"] : $this->getContext($context, "artisan")), "dateNaissance", array()), 'widget');
        echo "
            
            ";
        // line 31
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["artisan"]) ? $context["artisan"] : $this->getContext($context, "artisan")), "lieuNaissance", array()), 'label');
        echo "
            ";
        // line 32
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["artisan"]) ? $context["artisan"] : $this->getContext($context, "artisan")), "lieuNaissance", array()), 'widget');
        echo "
            
            ";
        // line 34
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["artisan"]) ? $context["artisan"] : $this->getContext($context, "artisan")), "numTel", array()), 'label');
        echo "
            ";
        // line 35
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["artisan"]) ? $context["artisan"] : $this->getContext($context, "artisan")), "numTel", array()), 'widget');
        echo "
            
            ";
        // line 37
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["artisan"]) ? $context["artisan"] : $this->getContext($context, "artisan")), "adresse", array()), 'label');
        echo "
            ";
        // line 38
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["artisan"]) ? $context["artisan"] : $this->getContext($context, "artisan")), "adresse", array()), 'widget');
        echo "
            
            ";
        // line 40
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["artisan"]) ? $context["artisan"] : $this->getContext($context, "artisan")), "cp", array()), 'label');
        echo "
            ";
        // line 41
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["artisan"]) ? $context["artisan"] : $this->getContext($context, "artisan")), "cp", array()), 'widget');
        echo "
            
            ";
        // line 43
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["artisan"]) ? $context["artisan"] : $this->getContext($context, "artisan")), "corspMetier", array()), 'label');
        echo "
            ";
        // line 44
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["artisan"]) ? $context["artisan"] : $this->getContext($context, "artisan")), "corspMetier", array()), 'widget');
        echo "
            
            ";
        // line 46
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["artisan"]) ? $context["artisan"] : $this->getContext($context, "artisan")), "maj", array()), 'widget');
        echo " <a class=\"btn btn-theme\" href=\"";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("page_gestion_artisan");
        echo "\">Retour</a>
               
        ";
        // line 48
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["artisan"]) ? $context["artisan"] : $this->getContext($context, "artisan")), 'form_end');
        echo "
               
    </div>
    
";
        
        $__internal_09258a1ccc5e3dca0a817ebc18ba2d4e1308eefdb096b592834bac74334a636e->leave($__internal_09258a1ccc5e3dca0a817ebc18ba2d4e1308eefdb096b592834bac74334a636e_prof);

    }

    public function getTemplateName()
    {
        return "mehbatiInterimBundle:Artisan:VueMajCoordonnee.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  169 => 48,  162 => 46,  157 => 44,  153 => 43,  148 => 41,  144 => 40,  139 => 38,  135 => 37,  130 => 35,  126 => 34,  121 => 32,  117 => 31,  112 => 29,  108 => 28,  103 => 26,  99 => 25,  94 => 23,  90 => 22,  86 => 21,  77 => 15,  66 => 6,  60 => 5,  48 => 4,  36 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'mehbatiInterimBundle::base.html.twig' %}

{% block title %}Mise a jour Artisan{% endblock %}
{% block titrePage %}Mise à jour des coordonnées{% endblock %}
{% block contenu %}
    <div class=\"col-lg-1\"></div>
    <div class=\"col-lg-12\">
        <h4><center>Données de l'artisan</center></h4>
        <div class=\"hline\"></div><br>
    </div><br>
    
    <div class=\"col-lg-5\">
        <h3>Données actuel</h3>
        
        {{ form(artisanDisabled) }}
    </div>
    <div class=\"col-lg-1\"></div>
    <div class=\"col-lg-5\">
        <h3>Données à modifier</h3>
        
        {{ form_start(artisan) }}
            {{ form_label(artisan.nom) }}
            {{ form_widget(artisan.nom) }}
                            
            {{ form_label(artisan.prenom) }}
            {{ form_widget(artisan.prenom) }}
            
            {{ form_label(artisan.dateNaissance) }}
            {{ form_widget(artisan.dateNaissance) }}
            
            {{ form_label(artisan.lieuNaissance) }}
            {{ form_widget(artisan.lieuNaissance) }}
            
            {{ form_label(artisan.numTel) }}
            {{ form_widget(artisan.numTel) }}
            
            {{ form_label(artisan.adresse) }}
            {{ form_widget(artisan.adresse) }}
            
            {{ form_label(artisan.cp) }}
            {{ form_widget(artisan.cp) }}
            
            {{ form_label(artisan.corspMetier) }}
            {{ form_widget(artisan.corspMetier) }}
            
            {{ form_widget(artisan.maj) }} <a class=\"btn btn-theme\" href=\"{{path('page_gestion_artisan')}}\">Retour</a>
               
        {{ form_end(artisan) }}
               
    </div>
    
{% endblock%}

", "mehbatiInterimBundle:Artisan:VueMajCoordonnee.html.twig", "/var/www/batiInterim/src/meh/batiInterimBundle/Resources/views/Artisan/VueMajCoordonnee.html.twig");
    }
}
