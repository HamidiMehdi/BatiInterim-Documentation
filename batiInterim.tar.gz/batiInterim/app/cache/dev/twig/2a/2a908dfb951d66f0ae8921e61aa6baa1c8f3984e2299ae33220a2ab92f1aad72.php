<?php

/* mehbatiInterimBundle:Entrepreneur_ChefChantier:VueArtisanAbsPresent.html.twig */
class __TwigTemplate_d69a99e0ff374b61aee5335cce48c110b577eeca4d0ffc8c5da6480ab3b5a1c8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("mehbatiInterimBundle::base.html.twig", "mehbatiInterimBundle:Entrepreneur_ChefChantier:VueArtisanAbsPresent.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'titrePage' => array($this, 'block_titrePage'),
            'contenu' => array($this, 'block_contenu'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "mehbatiInterimBundle::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_eca1b31e4ef7318af92c142c9979e485f1eefbf5537202e009bbd1911248bd42 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_eca1b31e4ef7318af92c142c9979e485f1eefbf5537202e009bbd1911248bd42->enter($__internal_eca1b31e4ef7318af92c142c9979e485f1eefbf5537202e009bbd1911248bd42_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "mehbatiInterimBundle:Entrepreneur_ChefChantier:VueArtisanAbsPresent.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_eca1b31e4ef7318af92c142c9979e485f1eefbf5537202e009bbd1911248bd42->leave($__internal_eca1b31e4ef7318af92c142c9979e485f1eefbf5537202e009bbd1911248bd42_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_90ffdf7648fbaceb4da8b2283f645f738772804dad6cbc4f035140fd13e0ea3b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_90ffdf7648fbaceb4da8b2283f645f738772804dad6cbc4f035140fd13e0ea3b->enter($__internal_90ffdf7648fbaceb4da8b2283f645f738772804dad6cbc4f035140fd13e0ea3b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Artisan absent";
        
        $__internal_90ffdf7648fbaceb4da8b2283f645f738772804dad6cbc4f035140fd13e0ea3b->leave($__internal_90ffdf7648fbaceb4da8b2283f645f738772804dad6cbc4f035140fd13e0ea3b_prof);

    }

    // line 4
    public function block_titrePage($context, array $blocks = array())
    {
        $__internal_ce3ba87a476b88460aa23a479ade653bb3242ed9c0f3bcb3972212acaa15a3e6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ce3ba87a476b88460aa23a479ade653bb3242ed9c0f3bcb3972212acaa15a3e6->enter($__internal_ce3ba87a476b88460aa23a479ade653bb3242ed9c0f3bcb3972212acaa15a3e6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "titrePage"));

        echo "Artisan Absent pour une date";
        
        $__internal_ce3ba87a476b88460aa23a479ade653bb3242ed9c0f3bcb3972212acaa15a3e6->leave($__internal_ce3ba87a476b88460aa23a479ade653bb3242ed9c0f3bcb3972212acaa15a3e6_prof);

    }

    // line 5
    public function block_contenu($context, array $blocks = array())
    {
        $__internal_a2d20a0e339a79a1fd024c44c5fa4c3a9b2d046c8cb41473a358ef024c30724f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a2d20a0e339a79a1fd024c44c5fa4c3a9b2d046c8cb41473a358ef024c30724f->enter($__internal_a2d20a0e339a79a1fd024c44c5fa4c3a9b2d046c8cb41473a358ef024c30724f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "contenu"));

        // line 6
        echo "    
    <div class=\"col-lg-1\"></div>
    <div class=\"col-lg-10\">
        <h4><center>Choisir la date et le corps de metier</center></h4>
        <div class=\"hline\"></div><br>
        ";
        // line 11
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form');
        echo "
        ";
        // line 12
        if ( !twig_test_empty((isset($context["artisanAbs"]) ? $context["artisanAbs"] : $this->getContext($context, "artisanAbs")))) {
            // line 13
            echo "            <div class=\"hline\"></div><br>
            
            <table class=\"table table-hover\">
                <thead>
                    <tr>
                        <th>Nom</th>
                        <th>Prenom</th>
                        <th>Date de naissance</th>
                        <th>Lieu de naissance</th>
                        <th>Numero de telephone</th>
                        <th>Adresse</th>
                    </tr>
                </thead>
                <tbody>

                ";
            // line 28
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["artisanAbs"]) ? $context["artisanAbs"] : $this->getContext($context, "artisanAbs")));
            foreach ($context['_seq'] as $context["_key"] => $context["unArtisan"]) {
                // line 29
                echo "                    <tr>
                        <td>";
                // line 30
                echo twig_escape_filter($this->env, $this->getAttribute($context["unArtisan"], "nom", array()), "html", null, true);
                echo "</td>
                        <td>";
                // line 31
                echo twig_escape_filter($this->env, $this->getAttribute($context["unArtisan"], "prenom", array()), "html", null, true);
                echo "</td>
                        <td>";
                // line 32
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["unArtisan"], "dateNaissance", array()), "d/m/Y"), "html", null, true);
                echo "</td>
                        <td>";
                // line 33
                echo twig_escape_filter($this->env, $this->getAttribute($context["unArtisan"], "lieuNaissance", array()), "html", null, true);
                echo "</td>
                        <td>";
                // line 34
                echo twig_escape_filter($this->env, $this->getAttribute($context["unArtisan"], "numTel", array()), "html", null, true);
                echo "</td>
                        <td>";
                // line 35
                echo twig_escape_filter($this->env, $this->getAttribute($context["unArtisan"], "adresse", array()), "html", null, true);
                echo ", ";
                echo twig_escape_filter($this->env, $this->getAttribute($context["unArtisan"], "cp", array()), "html", null, true);
                echo "</td>
                    </tr>
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['unArtisan'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 38
            echo "                </tbody>
            </table> 
        ";
        }
        // line 40
        echo "   
        
        
    </div>
        
";
        
        $__internal_a2d20a0e339a79a1fd024c44c5fa4c3a9b2d046c8cb41473a358ef024c30724f->leave($__internal_a2d20a0e339a79a1fd024c44c5fa4c3a9b2d046c8cb41473a358ef024c30724f_prof);

    }

    public function getTemplateName()
    {
        return "mehbatiInterimBundle:Entrepreneur_ChefChantier:VueArtisanAbsPresent.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  139 => 40,  134 => 38,  123 => 35,  119 => 34,  115 => 33,  111 => 32,  107 => 31,  103 => 30,  100 => 29,  96 => 28,  79 => 13,  77 => 12,  73 => 11,  66 => 6,  60 => 5,  48 => 4,  36 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'mehbatiInterimBundle::base.html.twig' %}

{% block title %}Artisan absent{% endblock %}
{% block titrePage %}Artisan Absent pour une date{% endblock %}
{% block contenu %}
    
    <div class=\"col-lg-1\"></div>
    <div class=\"col-lg-10\">
        <h4><center>Choisir la date et le corps de metier</center></h4>
        <div class=\"hline\"></div><br>
        {{form(form)}}
        {% if artisanAbs is not empty %}
            <div class=\"hline\"></div><br>
            
            <table class=\"table table-hover\">
                <thead>
                    <tr>
                        <th>Nom</th>
                        <th>Prenom</th>
                        <th>Date de naissance</th>
                        <th>Lieu de naissance</th>
                        <th>Numero de telephone</th>
                        <th>Adresse</th>
                    </tr>
                </thead>
                <tbody>

                {% for unArtisan in artisanAbs %}
                    <tr>
                        <td>{{unArtisan.nom}}</td>
                        <td>{{unArtisan.prenom}}</td>
                        <td>{{unArtisan.dateNaissance|date('d/m/Y')}}</td>
                        <td>{{unArtisan.lieuNaissance}}</td>
                        <td>{{unArtisan.numTel}}</td>
                        <td>{{unArtisan.adresse}}, {{unArtisan.cp}}</td>
                    </tr>
                {% endfor %}
                </tbody>
            </table> 
        {% endif %}   
        
        
    </div>
        
{% endblock%}

", "mehbatiInterimBundle:Entrepreneur_ChefChantier:VueArtisanAbsPresent.html.twig", "/var/www/batiInterim/src/meh/batiInterimBundle/Resources/views/Entrepreneur_ChefChantier/VueArtisanAbsPresent.html.twig");
    }
}
