<?php

/* mehbatiInterimBundle::base.html.twig */
class __TwigTemplate_7944fa2a5ffb0ec375bad1c2be6867ad34891e0ffe253c7eed0582476adcdafe extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'titrePage' => array($this, 'block_titrePage'),
            'contenu' => array($this, 'block_contenu'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f9a6d5bce1b3db1f6789c3a5f4e224f431b5383a08eddb9c4611430568d1da30 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f9a6d5bce1b3db1f6789c3a5f4e224f431b5383a08eddb9c4611430568d1da30->enter($__internal_f9a6d5bce1b3db1f6789c3a5f4e224f431b5383a08eddb9c4611430568d1da30_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "mehbatiInterimBundle::base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html lang=\"fr\">
    <head>
        <meta charset=\"utf-8\">
        <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
        <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
        <meta name=\"description\" content=\"\">
        <meta name=\"author\" content=\"\">

        <title>BatiInterim - ";
        // line 10
        $this->displayBlock('title', $context, $blocks);
        echo "</title>

        ";
        // line 12
        if (isset($context['assetic']['debug']) && $context['assetic']['debug']) {
            // asset "d110ff7_0"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_d110ff7_0") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/css/d110ff7_bootstrap_1.css");
            // line 13
            echo "            <link href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" rel=\"stylesheet\" type=\"text/css\" />
        ";
        } else {
            // asset "d110ff7"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_d110ff7") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/css/d110ff7.css");
            echo "            <link href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" rel=\"stylesheet\" type=\"text/css\" />
        ";
        }
        unset($context["asset_url"]);
        // line 15
        echo "        ";
        if (isset($context['assetic']['debug']) && $context['assetic']['debug']) {
            // asset "637d219_0"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_637d219_0") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/css/637d219_style_1.css");
            // line 16
            echo "            <link href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" rel=\"stylesheet\" type=\"text/css\" />
        ";
        } else {
            // asset "637d219"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_637d219") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/css/637d219.css");
            echo "            <link href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" rel=\"stylesheet\" type=\"text/css\" />
        ";
        }
        unset($context["asset_url"]);
        // line 18
        echo "        ";
        if (isset($context['assetic']['debug']) && $context['assetic']['debug']) {
            // asset "2269066_0"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_2269066_0") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/css/2269066_font-awesome.min_1.css");
            // line 19
            echo "            <link href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" rel=\"stylesheet\" type=\"text/css\" />
        ";
        } else {
            // asset "2269066"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_2269066") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/css/2269066.css");
            echo "            <link href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" rel=\"stylesheet\" type=\"text/css\" />
        ";
        }
        unset($context["asset_url"]);
        // line 21
        echo "        
    </head>
    <body>
        
        <div class=\"navbar navbar-default navbar-fixed-top\" role=\"navigation\">
            <div class=\"container\">
                <div class=\"navbar-header\">
                    <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\".navbar-collapse\">
                        <span class=\"sr-only\">Toggle navigation</span>
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                    </button>
                    <a class=\"navbar-brand\" href=\"";
        // line 34
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("page_accueil");
        echo "\">BATI | INTERIM</a>
                </div>
                <div class=\"navbar-collapse collapse navbar-right\">
                    ";
        // line 37
        if (($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "get", array(0 => "menu"), "method") == 1)) {
            // line 38
            echo "                    <ul class=\"nav navbar-nav\">
                        <li class=\"active\"><a href=\"";
            // line 39
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("page_accueil");
            echo "\">ACCUEIL</a></li>
                        ";
            // line 40
            if (($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "get", array(0 => "profil"), "method") == "gestionnaire")) {
                // line 41
                echo "                        <li class=\"dropdown\">
                            <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\">ARTISAN <b class=\"caret\"></b></a>
                            <ul class=\"dropdown-menu\">
                                <li><a href=\"";
                // line 44
                echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("page_nouveau_artisan");
                echo "\">NOUVEAU ARTISAN</a></li>
                                <li><a href=\"";
                // line 45
                echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("page_gestion_artisan");
                echo "\">GESTION ARTISAN</a></li>
                                <li><a href=\"";
                // line 46
                echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("page_conges_gestionnaire");
                echo "\">CONGES ARTISAN</a></li>
                            </ul>
                        </li>
                        <li class=\"dropdown\">
                            <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\">ENTREPRENEUR <b class=\"caret\"></b></a>
                            <ul class=\"dropdown-menu\">
                                <li><a href=\"";
                // line 52
                echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("page_nouveau_entrepreneur");
                echo "\">NOUVEAU ENTREPRENEUR</a></li>
                                <li><a href=\"";
                // line 53
                echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("page_gestion_entrepreneur");
                echo "\">GESTION ENTREPRENEUR</a></li>
                            </ul>
                        </li>
                        ";
            }
            // line 57
            echo "                        ";
            if (($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "get", array(0 => "profil"), "method") == "artisan")) {
                // line 58
                echo "                        <li class=\"dropdown\">
                            <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\">CONGES <b class=\"caret\"></b></a>
                            <ul class=\"dropdown-menu\">
                                <li><a href=\"";
                // line 61
                echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("page_nouveau_conge");
                echo "\">NOUVEAU CONGE</a></li>
                                <li><a href=\"";
                // line 62
                echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("page_gestion_conge");
                echo "\">GESTION CONGES</a></li>
                            </ul>
                        </li>
                        <li><a href=\"";
                // line 65
                echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("page_mission_artisan");
                echo "\">MISSIONS</a></li>
                        <li><a href=\"";
                // line 66
                echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("page_maj_coordonnées_artisan");
                echo "\">MES COORDONNEES</a></li>
                        ";
            }
            // line 68
            echo "                        ";
            if ((($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "get", array(0 => "profil"), "method") == "entrepreneur") || ($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "get", array(0 => "profil"), "method") == "chef de chantier"))) {
                // line 69
                echo "                        <li class=\"dropdown\">
                            <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\">ARTISAN <b class=\"caret\"></b></a>
                            <ul class=\"dropdown-menu\">
                                <li><a href=\"";
                // line 72
                echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("page__artisan_par_corps_metier");
                echo "\">LISTES ARTISANS</a></li>
                                <li><a href=\"";
                // line 73
                echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("page__conges_dun_artisan");
                echo "\">CONGE D'UN ARTISAN</a></li>
                                <li><a href=\"";
                // line 74
                echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("page__artisan_abs_present");
                echo "\">ARTISANS PRESENTS/ABSENTS</a></li>
                            </ul>
                        </li>
                        <li class=\"dropdown\">
                            <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\">CHANTIER <b class=\"caret\"></b></a>
                            <ul class=\"dropdown-menu\">
                                <li><a href=\"";
                // line 80
                echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("page_new_chantier");
                echo "\">CREER UN CHANTIER</a></li>
                                <li><a href=\"";
                // line 81
                echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("page_new_mission");
                echo "\">CREER MISSION</a></li>
                                <li><a href=\"";
                // line 82
                echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("page_gestion_chantier");
                echo "\">GESTION CHANTIER</a></li>
                            </ul>
                        </li>
                        <li class=\"dropdown\">
                            <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\">AFFECTATION <b class=\"caret\"></b></a>
                            <ul class=\"dropdown-menu\">
                                <li><a href=\"";
                // line 88
                echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("page_affecter_mission_chantier");
                echo "\">AFFECTER MISSION</a></li>
                                <li><a href=\"";
                // line 89
                echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("page_gestion_affecter");
                echo "\">LISTE DES AFFECTATONS</a></li>
                            </ul>
                        </li>
                        ";
            }
            // line 93
            echo "                        <li class=\"dropdown\">
                            <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\">OPTIONS <b class=\"caret\"></b></a>
                            <ul class=\"dropdown-menu\">
                                <li><a href=\"";
            // line 96
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("page_changer_mdp");
            echo "\">CHANGER MDP</a></li>
                                <li><a href=\"";
            // line 97
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("déconnexion");
            echo "\">DECONNEXION</a></li>
                            </ul>
                        </li>
                    </ul>
                    ";
        }
        // line 102
        echo "                </div>
            </div>
        </div>
        
        <div id=\"blue\">
\t    <div class=\"container\">
\t\t<div class=\"row\">
                    <h3><center>";
        // line 109
        $this->displayBlock('titrePage', $context, $blocks);
        echo "</center></h3>
\t\t</div>
\t    </div> 
\t</div>
        
        <div class=\"container mtb\">
            <div class=\"row\">
                ";
        // line 116
        $this->displayBlock('contenu', $context, $blocks);
        // line 117
        echo "            </div>
\t </div>
            
        <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js\"></script>
        ";
        // line 121
        if (isset($context['assetic']['debug']) && $context['assetic']['debug']) {
            // asset "9e7a6dd_0"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_9e7a6dd_0") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/js/9e7a6dd_bootstrap.min_1.js");
            // line 122
            echo "            <script src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" ></script>
        ";
        } else {
            // asset "9e7a6dd"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_9e7a6dd") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/js/9e7a6dd.js");
            echo "            <script src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" ></script>
        ";
        }
        unset($context["asset_url"]);
        // line 124
        echo "        ";
        if (isset($context['assetic']['debug']) && $context['assetic']['debug']) {
            // asset "aa6c98c_0"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_aa6c98c_0") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/js/aa6c98c_retina-1.1.0_1.js");
            // line 125
            echo "            <script src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" ></script>
        ";
        } else {
            // asset "aa6c98c"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_aa6c98c") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/js/aa6c98c.js");
            echo "            <script src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" ></script>
        ";
        }
        unset($context["asset_url"]);
        // line 127
        echo "        ";
        if (isset($context['assetic']['debug']) && $context['assetic']['debug']) {
            // asset "55fed6f_0"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_55fed6f_0") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/js/55fed6f_jquery.hoverdir_1.js");
            // line 128
            echo "            <script src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" ></script>
        ";
        } else {
            // asset "55fed6f"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_55fed6f") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/js/55fed6f.js");
            echo "            <script src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" ></script>
        ";
        }
        unset($context["asset_url"]);
        // line 130
        echo "        ";
        if (isset($context['assetic']['debug']) && $context['assetic']['debug']) {
            // asset "4e4daf1_0"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_4e4daf1_0") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/js/4e4daf1_jquery.hoverex.min_1.js");
            // line 131
            echo "            <script src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" ></script>
        ";
        } else {
            // asset "4e4daf1"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_4e4daf1") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/js/4e4daf1.js");
            echo "            <script src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" ></script>
        ";
        }
        unset($context["asset_url"]);
        // line 133
        echo "        ";
        if (isset($context['assetic']['debug']) && $context['assetic']['debug']) {
            // asset "6326506_0"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_6326506_0") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/js/6326506_jquery.prettyPhoto_1.js");
            // line 134
            echo "            <script src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" ></script>
        ";
        } else {
            // asset "6326506"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_6326506") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/js/6326506.js");
            echo "            <script src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" ></script>
        ";
        }
        unset($context["asset_url"]);
        // line 136
        echo "        ";
        if (isset($context['assetic']['debug']) && $context['assetic']['debug']) {
            // asset "0de8a66_0"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_0de8a66_0") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/js/0de8a66_jquery.isotope.min_1.js");
            // line 137
            echo "            <script src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" ></script>
        ";
        } else {
            // asset "0de8a66"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_0de8a66") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/js/0de8a66.js");
            echo "            <script src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" ></script>
        ";
        }
        unset($context["asset_url"]);
        // line 139
        echo "        ";
        if (isset($context['assetic']['debug']) && $context['assetic']['debug']) {
            // asset "af3c089_0"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_af3c089_0") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/js/af3c089_custom_1.js");
            // line 140
            echo "            <script src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" ></script>
        ";
        } else {
            // asset "af3c089"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_af3c089") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/js/af3c089.js");
            echo "            <script src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" ></script>
        ";
        }
        unset($context["asset_url"]);
        // line 142
        echo "        
        
    </body>
</html>";
        
        $__internal_f9a6d5bce1b3db1f6789c3a5f4e224f431b5383a08eddb9c4611430568d1da30->leave($__internal_f9a6d5bce1b3db1f6789c3a5f4e224f431b5383a08eddb9c4611430568d1da30_prof);

    }

    // line 10
    public function block_title($context, array $blocks = array())
    {
        $__internal_c4f739df681e10d6b7f5f997645cfeb21428a89f5e90a4ce8b3231c997e07c87 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c4f739df681e10d6b7f5f997645cfeb21428a89f5e90a4ce8b3231c997e07c87->enter($__internal_c4f739df681e10d6b7f5f997645cfeb21428a89f5e90a4ce8b3231c997e07c87_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        
        $__internal_c4f739df681e10d6b7f5f997645cfeb21428a89f5e90a4ce8b3231c997e07c87->leave($__internal_c4f739df681e10d6b7f5f997645cfeb21428a89f5e90a4ce8b3231c997e07c87_prof);

    }

    // line 109
    public function block_titrePage($context, array $blocks = array())
    {
        $__internal_7e952dea76f282e922c5f427b50cea9225017847a17f9580fdf1a6a41345ae43 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7e952dea76f282e922c5f427b50cea9225017847a17f9580fdf1a6a41345ae43->enter($__internal_7e952dea76f282e922c5f427b50cea9225017847a17f9580fdf1a6a41345ae43_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "titrePage"));

        
        $__internal_7e952dea76f282e922c5f427b50cea9225017847a17f9580fdf1a6a41345ae43->leave($__internal_7e952dea76f282e922c5f427b50cea9225017847a17f9580fdf1a6a41345ae43_prof);

    }

    // line 116
    public function block_contenu($context, array $blocks = array())
    {
        $__internal_fe6ce4be301a536bd364c0e433a20c20529d891672a0b69c3f83350f85bf87bb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fe6ce4be301a536bd364c0e433a20c20529d891672a0b69c3f83350f85bf87bb->enter($__internal_fe6ce4be301a536bd364c0e433a20c20529d891672a0b69c3f83350f85bf87bb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "contenu"));

        
        $__internal_fe6ce4be301a536bd364c0e433a20c20529d891672a0b69c3f83350f85bf87bb->leave($__internal_fe6ce4be301a536bd364c0e433a20c20529d891672a0b69c3f83350f85bf87bb_prof);

    }

    public function getTemplateName()
    {
        return "mehbatiInterimBundle::base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  450 => 116,  439 => 109,  428 => 10,  418 => 142,  404 => 140,  399 => 139,  385 => 137,  380 => 136,  366 => 134,  361 => 133,  347 => 131,  342 => 130,  328 => 128,  323 => 127,  309 => 125,  304 => 124,  290 => 122,  286 => 121,  280 => 117,  278 => 116,  268 => 109,  259 => 102,  251 => 97,  247 => 96,  242 => 93,  235 => 89,  231 => 88,  222 => 82,  218 => 81,  214 => 80,  205 => 74,  201 => 73,  197 => 72,  192 => 69,  189 => 68,  184 => 66,  180 => 65,  174 => 62,  170 => 61,  165 => 58,  162 => 57,  155 => 53,  151 => 52,  142 => 46,  138 => 45,  134 => 44,  129 => 41,  127 => 40,  123 => 39,  120 => 38,  118 => 37,  112 => 34,  97 => 21,  83 => 19,  78 => 18,  64 => 16,  59 => 15,  45 => 13,  41 => 12,  36 => 10,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html lang=\"fr\">
    <head>
        <meta charset=\"utf-8\">
        <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
        <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
        <meta name=\"description\" content=\"\">
        <meta name=\"author\" content=\"\">

        <title>BatiInterim - {% block title %}{% endblock %}</title>

        {% stylesheets '@mehbatiInterimBundle/Resources/public/css/bootstrap.css' %}
            <link href=\"{{ asset_url }}\" rel=\"stylesheet\" type=\"text/css\" />
        {% endstylesheets %}
        {% stylesheets '@mehbatiInterimBundle/Resources/public/css/style.css' %}
            <link href=\"{{ asset_url }}\" rel=\"stylesheet\" type=\"text/css\" />
        {% endstylesheets %}
        {% stylesheets '@mehbatiInterimBundle/Resources/public/css/font-awesome.min.css' %}
            <link href=\"{{ asset_url }}\" rel=\"stylesheet\" type=\"text/css\" />
        {% endstylesheets %}
        
    </head>
    <body>
        
        <div class=\"navbar navbar-default navbar-fixed-top\" role=\"navigation\">
            <div class=\"container\">
                <div class=\"navbar-header\">
                    <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\".navbar-collapse\">
                        <span class=\"sr-only\">Toggle navigation</span>
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                    </button>
                    <a class=\"navbar-brand\" href=\"{{path('page_accueil')}}\">BATI | INTERIM</a>
                </div>
                <div class=\"navbar-collapse collapse navbar-right\">
                    {% if app.session.get('menu') == 1 %}
                    <ul class=\"nav navbar-nav\">
                        <li class=\"active\"><a href=\"{{path('page_accueil')}}\">ACCUEIL</a></li>
                        {% if app.session.get('profil') == 'gestionnaire'%}
                        <li class=\"dropdown\">
                            <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\">ARTISAN <b class=\"caret\"></b></a>
                            <ul class=\"dropdown-menu\">
                                <li><a href=\"{{path('page_nouveau_artisan')}}\">NOUVEAU ARTISAN</a></li>
                                <li><a href=\"{{path('page_gestion_artisan')}}\">GESTION ARTISAN</a></li>
                                <li><a href=\"{{path('page_conges_gestionnaire')}}\">CONGES ARTISAN</a></li>
                            </ul>
                        </li>
                        <li class=\"dropdown\">
                            <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\">ENTREPRENEUR <b class=\"caret\"></b></a>
                            <ul class=\"dropdown-menu\">
                                <li><a href=\"{{path('page_nouveau_entrepreneur')}}\">NOUVEAU ENTREPRENEUR</a></li>
                                <li><a href=\"{{path('page_gestion_entrepreneur')}}\">GESTION ENTREPRENEUR</a></li>
                            </ul>
                        </li>
                        {% endif %}
                        {% if app.session.get('profil') == 'artisan'%}
                        <li class=\"dropdown\">
                            <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\">CONGES <b class=\"caret\"></b></a>
                            <ul class=\"dropdown-menu\">
                                <li><a href=\"{{path('page_nouveau_conge')}}\">NOUVEAU CONGE</a></li>
                                <li><a href=\"{{path('page_gestion_conge')}}\">GESTION CONGES</a></li>
                            </ul>
                        </li>
                        <li><a href=\"{{path('page_mission_artisan')}}\">MISSIONS</a></li>
                        <li><a href=\"{{path('page_maj_coordonnées_artisan')}}\">MES COORDONNEES</a></li>
                        {% endif %}
                        {% if app.session.get('profil') == 'entrepreneur' or app.session.get('profil') == 'chef de chantier' %}
                        <li class=\"dropdown\">
                            <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\">ARTISAN <b class=\"caret\"></b></a>
                            <ul class=\"dropdown-menu\">
                                <li><a href=\"{{path('page__artisan_par_corps_metier')}}\">LISTES ARTISANS</a></li>
                                <li><a href=\"{{path('page__conges_dun_artisan')}}\">CONGE D'UN ARTISAN</a></li>
                                <li><a href=\"{{path('page__artisan_abs_present')}}\">ARTISANS PRESENTS/ABSENTS</a></li>
                            </ul>
                        </li>
                        <li class=\"dropdown\">
                            <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\">CHANTIER <b class=\"caret\"></b></a>
                            <ul class=\"dropdown-menu\">
                                <li><a href=\"{{path('page_new_chantier')}}\">CREER UN CHANTIER</a></li>
                                <li><a href=\"{{path('page_new_mission')}}\">CREER MISSION</a></li>
                                <li><a href=\"{{path('page_gestion_chantier')}}\">GESTION CHANTIER</a></li>
                            </ul>
                        </li>
                        <li class=\"dropdown\">
                            <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\">AFFECTATION <b class=\"caret\"></b></a>
                            <ul class=\"dropdown-menu\">
                                <li><a href=\"{{path('page_affecter_mission_chantier')}}\">AFFECTER MISSION</a></li>
                                <li><a href=\"{{path('page_gestion_affecter')}}\">LISTE DES AFFECTATONS</a></li>
                            </ul>
                        </li>
                        {% endif %}
                        <li class=\"dropdown\">
                            <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\">OPTIONS <b class=\"caret\"></b></a>
                            <ul class=\"dropdown-menu\">
                                <li><a href=\"{{path('page_changer_mdp')}}\">CHANGER MDP</a></li>
                                <li><a href=\"{{path('déconnexion')}}\">DECONNEXION</a></li>
                            </ul>
                        </li>
                    </ul>
                    {% endif %}
                </div>
            </div>
        </div>
        
        <div id=\"blue\">
\t    <div class=\"container\">
\t\t<div class=\"row\">
                    <h3><center>{% block titrePage %}{% endblock %}</center></h3>
\t\t</div>
\t    </div> 
\t</div>
        
        <div class=\"container mtb\">
            <div class=\"row\">
                {% block contenu %}{% endblock %}
            </div>
\t </div>
            
        <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js\"></script>
        {% javascripts '@mehbatiInterimBundle/Resources/public/js/bootstrap.min.js' %}
            <script src=\"{{ asset_url }}\" ></script>
        {% endjavascripts %}
        {% javascripts '@mehbatiInterimBundle/Resources/public/js/retina-1.1.0.js' %}
            <script src=\"{{ asset_url }}\" ></script>
        {% endjavascripts %}
        {% javascripts '@mehbatiInterimBundle/Resources/public/js/jquery.hoverdir.js' %}
            <script src=\"{{ asset_url }}\" ></script>
        {% endjavascripts %}
        {% javascripts '@mehbatiInterimBundle/Resources/public/js/jquery.hoverex.min.js' %}
            <script src=\"{{ asset_url }}\" ></script>
        {% endjavascripts %}
        {% javascripts '@mehbatiInterimBundle/Resources/public/js/jquery.prettyPhoto.js' %}
            <script src=\"{{ asset_url }}\" ></script>
        {% endjavascripts %}
        {% javascripts '@mehbatiInterimBundle/Resources/public/js/jquery.isotope.min.js' %}
            <script src=\"{{ asset_url }}\" ></script>
        {% endjavascripts %}
        {% javascripts '@mehbatiInterimBundle/Resources/public/js/custom.js' %}
            <script src=\"{{ asset_url }}\" ></script>
        {% endjavascripts %}
        
        
    </body>
</html>", "mehbatiInterimBundle::base.html.twig", "/var/www/batiInterim/src/meh/batiInterimBundle/Resources/views/base.html.twig");
    }
}
