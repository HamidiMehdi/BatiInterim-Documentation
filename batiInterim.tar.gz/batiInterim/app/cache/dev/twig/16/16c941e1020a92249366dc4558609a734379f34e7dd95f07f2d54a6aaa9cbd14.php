<?php

/* mehbatiInterimBundle:Gestionnaire:VueConge.html.twig */
class __TwigTemplate_806b02772fd6c3440303a2cc25b6162e37e3c71c86789eb41878e5d4d0b85143 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 2
        $this->parent = $this->loadTemplate("mehbatiInterimBundle::base.html.twig", "mehbatiInterimBundle:Gestionnaire:VueConge.html.twig", 2);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'titrePage' => array($this, 'block_titrePage'),
            'contenu' => array($this, 'block_contenu'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "mehbatiInterimBundle::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7dd2db52164ebdac15055b83f46e22334e08d06cf849c9522a1c7f5b7d98de60 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7dd2db52164ebdac15055b83f46e22334e08d06cf849c9522a1c7f5b7d98de60->enter($__internal_7dd2db52164ebdac15055b83f46e22334e08d06cf849c9522a1c7f5b7d98de60_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "mehbatiInterimBundle:Gestionnaire:VueConge.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_7dd2db52164ebdac15055b83f46e22334e08d06cf849c9522a1c7f5b7d98de60->leave($__internal_7dd2db52164ebdac15055b83f46e22334e08d06cf849c9522a1c7f5b7d98de60_prof);

    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        $__internal_f05743d8004bb4fa07775cbe3a17acc93b091c56ec0b78087004ff261fed3e16 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f05743d8004bb4fa07775cbe3a17acc93b091c56ec0b78087004ff261fed3e16->enter($__internal_f05743d8004bb4fa07775cbe3a17acc93b091c56ec0b78087004ff261fed3e16_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Congés artisan";
        
        $__internal_f05743d8004bb4fa07775cbe3a17acc93b091c56ec0b78087004ff261fed3e16->leave($__internal_f05743d8004bb4fa07775cbe3a17acc93b091c56ec0b78087004ff261fed3e16_prof);

    }

    // line 5
    public function block_titrePage($context, array $blocks = array())
    {
        $__internal_2041ed963f97ec51f3112513f60b4cc85a9a93cc9b44a301225e281e642be9d9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2041ed963f97ec51f3112513f60b4cc85a9a93cc9b44a301225e281e642be9d9->enter($__internal_2041ed963f97ec51f3112513f60b4cc85a9a93cc9b44a301225e281e642be9d9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "titrePage"));

        echo "Congés artisan ";
        
        $__internal_2041ed963f97ec51f3112513f60b4cc85a9a93cc9b44a301225e281e642be9d9->leave($__internal_2041ed963f97ec51f3112513f60b4cc85a9a93cc9b44a301225e281e642be9d9_prof);

    }

    // line 6
    public function block_contenu($context, array $blocks = array())
    {
        $__internal_79d4724f66c9890e93c1ac320ed6080a50dc2ddf521d239ab9b4d08625c0bc00 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_79d4724f66c9890e93c1ac320ed6080a50dc2ddf521d239ab9b4d08625c0bc00->enter($__internal_79d4724f66c9890e93c1ac320ed6080a50dc2ddf521d239ab9b4d08625c0bc00_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "contenu"));

        // line 7
        echo "    
    <div class=\"col-lg-1\"></div>
    <div class=\"col-lg-10\">
        <h4><center>Congés des artisans</center></h4>
        <div class=\"hline\"></div><br>
        ";
        // line 12
        if ((twig_length_filter($this->env, (isset($context["conges"]) ? $context["conges"] : $this->getContext($context, "conges"))) >= 1)) {
            // line 13
            echo "        <table class=\"table table-hover\">
            <thead>
                <tr>
                    <th>Congé numero</th>
                    <th>Date de debut</th>
                    <th>Date de fin</th>
                    <th>Etat</th>
                    <th>Artisan</th>
                </tr>
            </thead>
            <tbody>
                
            ";
            // line 25
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["conges"]) ? $context["conges"] : $this->getContext($context, "conges")));
            foreach ($context['_seq'] as $context["_key"] => $context["unConger"]) {
                // line 26
                echo "                <tr>
                        <td>";
                // line 27
                echo twig_escape_filter($this->env, $this->getAttribute($context["unConger"], "idconger", array()), "html", null, true);
                echo "</td>
                        <td>";
                // line 28
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["unConger"], "datedebut", array()), "d/m/Y"), "html", null, true);
                echo "</td>
                        <td>";
                // line 29
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["unConger"], "datefin", array()), "d/m/Y"), "html", null, true);
                echo "</td>
                        <td>";
                // line 30
                echo twig_escape_filter($this->env, $this->getAttribute($context["unConger"], "valider", array()), "html", null, true);
                echo "</td>
                        <td>";
                // line 31
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["unConger"], "idartisan", array()), "nom", array()), "html", null, true);
                echo " ";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["unConger"], "idartisan", array()), "prenom", array()), "html", null, true);
                echo "</td>
                        
                        <td><a class=\"btn btn-success\" href=\"";
                // line 33
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("page_conges_update_etat", array("id" => $this->getAttribute($context["unConger"], "idconger", array()), "btn" => 1)), "html", null, true);
                echo "\">Accepter</a></td>
                        <td><a class=\"btn btn-danger\" href=\"";
                // line 34
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("page_conges_update_etat", array("id" => $this->getAttribute($context["unConger"], "idconger", array()), "btn" => 2)), "html", null, true);
                echo "\">Refuser</a></td>              
                </tr>
            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['unConger'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 36
            echo "  
            </tbody>
        </table>
        ";
        } else {
            // line 40
            echo "            Il n'y a aucun congé.
        ";
        }
        // line 42
        echo "    </div>
    
    
";
        
        $__internal_79d4724f66c9890e93c1ac320ed6080a50dc2ddf521d239ab9b4d08625c0bc00->leave($__internal_79d4724f66c9890e93c1ac320ed6080a50dc2ddf521d239ab9b4d08625c0bc00_prof);

    }

    public function getTemplateName()
    {
        return "mehbatiInterimBundle:Gestionnaire:VueConge.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  142 => 42,  138 => 40,  132 => 36,  123 => 34,  119 => 33,  112 => 31,  108 => 30,  104 => 29,  100 => 28,  96 => 27,  93 => 26,  89 => 25,  75 => 13,  73 => 12,  66 => 7,  60 => 6,  48 => 5,  36 => 4,  11 => 2,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("
{% extends 'mehbatiInterimBundle::base.html.twig' %}

{% block title %}Congés artisan{% endblock %}
{% block titrePage %}Congés artisan {% endblock %}
{% block contenu %}
    
    <div class=\"col-lg-1\"></div>
    <div class=\"col-lg-10\">
        <h4><center>Congés des artisans</center></h4>
        <div class=\"hline\"></div><br>
        {% if conges|length >= 1%}
        <table class=\"table table-hover\">
            <thead>
                <tr>
                    <th>Congé numero</th>
                    <th>Date de debut</th>
                    <th>Date de fin</th>
                    <th>Etat</th>
                    <th>Artisan</th>
                </tr>
            </thead>
            <tbody>
                
            {% for unConger in conges %}
                <tr>
                        <td>{{unConger.idconger}}</td>
                        <td>{{unConger.datedebut|date('d/m/Y')}}</td>
                        <td>{{unConger.datefin|date('d/m/Y')}}</td>
                        <td>{{unConger.valider }}</td>
                        <td>{{unConger.idartisan.nom}} {{unConger.idartisan.prenom}}</td>
                        
                        <td><a class=\"btn btn-success\" href=\"{{path('page_conges_update_etat', {'id': unConger.idconger, 'btn':1 })}}\">Accepter</a></td>
                        <td><a class=\"btn btn-danger\" href=\"{{path('page_conges_update_etat', {'id': unConger.idconger, 'btn':2 })}}\">Refuser</a></td>              
                </tr>
            {% endfor %}  
            </tbody>
        </table>
        {% else%}
            Il n'y a aucun congé.
        {% endif%}
    </div>
    
    
{% endblock%}
", "mehbatiInterimBundle:Gestionnaire:VueConge.html.twig", "/var/www/batiInterim/src/meh/batiInterimBundle/Resources/views/Gestionnaire/VueConge.html.twig");
    }
}
