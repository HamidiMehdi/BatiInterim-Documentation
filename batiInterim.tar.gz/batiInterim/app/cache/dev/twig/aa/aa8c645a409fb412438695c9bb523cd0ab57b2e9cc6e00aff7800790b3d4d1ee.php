<?php

/* mehbatiInterimBundle:Artisan:VueMajConge.html.twig */
class __TwigTemplate_26c7f45cbae7661b94a91a66ca1c79dc9740018fe287272a02bc75841c8b269f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("mehbatiInterimBundle::base.html.twig", "mehbatiInterimBundle:Artisan:VueMajConge.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'titrePage' => array($this, 'block_titrePage'),
            'contenu' => array($this, 'block_contenu'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "mehbatiInterimBundle::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2c97799a32c25d522bad870af2297baf1b8c14f88868b14c13b38ddb02730f14 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2c97799a32c25d522bad870af2297baf1b8c14f88868b14c13b38ddb02730f14->enter($__internal_2c97799a32c25d522bad870af2297baf1b8c14f88868b14c13b38ddb02730f14_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "mehbatiInterimBundle:Artisan:VueMajConge.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_2c97799a32c25d522bad870af2297baf1b8c14f88868b14c13b38ddb02730f14->leave($__internal_2c97799a32c25d522bad870af2297baf1b8c14f88868b14c13b38ddb02730f14_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_54c769f0d0d45200889e6a653cce7896c56a4fb33d5b927030e04f9f2dd4e6ed = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_54c769f0d0d45200889e6a653cce7896c56a4fb33d5b927030e04f9f2dd4e6ed->enter($__internal_54c769f0d0d45200889e6a653cce7896c56a4fb33d5b927030e04f9f2dd4e6ed_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Modifier congé";
        
        $__internal_54c769f0d0d45200889e6a653cce7896c56a4fb33d5b927030e04f9f2dd4e6ed->leave($__internal_54c769f0d0d45200889e6a653cce7896c56a4fb33d5b927030e04f9f2dd4e6ed_prof);

    }

    // line 4
    public function block_titrePage($context, array $blocks = array())
    {
        $__internal_1e88253b48d2b71824c674a030d28ab5686cecfa983e04239617b4ebd5a6d4a8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1e88253b48d2b71824c674a030d28ab5686cecfa983e04239617b4ebd5a6d4a8->enter($__internal_1e88253b48d2b71824c674a030d28ab5686cecfa983e04239617b4ebd5a6d4a8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "titrePage"));

        echo "Modifier congé";
        
        $__internal_1e88253b48d2b71824c674a030d28ab5686cecfa983e04239617b4ebd5a6d4a8->leave($__internal_1e88253b48d2b71824c674a030d28ab5686cecfa983e04239617b4ebd5a6d4a8_prof);

    }

    // line 5
    public function block_contenu($context, array $blocks = array())
    {
        $__internal_1b45a8461d9fd131b98a18a9de7ab109b088859b228daa130beeeabc08ec9dd8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1b45a8461d9fd131b98a18a9de7ab109b088859b228daa130beeeabc08ec9dd8->enter($__internal_1b45a8461d9fd131b98a18a9de7ab109b088859b228daa130beeeabc08ec9dd8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "contenu"));

        // line 6
        echo "    <div class=\"col-lg-1\"></div>
    <div class=\"col-lg-12\">
        <h4><center>Données de l'artisan</center></h4>
        <div class=\"hline\"></div><br>
    </div><br>
    
    <div class=\"col-lg-5\">
        <h3>Données actuel</h3>
        
        ";
        // line 15
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["congeDisabled"]) ? $context["congeDisabled"] : $this->getContext($context, "congeDisabled")), 'form');
        echo "
    </div>
    <div class=\"col-lg-1\"></div>
    <div class=\"col-lg-5\">
        <h3>Données à modifier</h3>
        
        ";
        // line 21
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["conge"]) ? $context["conge"] : $this->getContext($context, "conge")), 'form_start');
        echo "
            ";
        // line 22
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["conge"]) ? $context["conge"] : $this->getContext($context, "conge")), "dateDebut", array()), 'label');
        echo "
            ";
        // line 23
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["conge"]) ? $context["conge"] : $this->getContext($context, "conge")), "dateDebut", array()), 'widget');
        echo "
            
            ";
        // line 25
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["conge"]) ? $context["conge"] : $this->getContext($context, "conge")), "dateFin", array()), 'label');
        echo "
            ";
        // line 26
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["conge"]) ? $context["conge"] : $this->getContext($context, "conge")), "dateFin", array()), 'widget');
        echo "
            
            ";
        // line 28
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["conge"]) ? $context["conge"] : $this->getContext($context, "conge")), "maj", array()), 'widget');
        echo " <a class=\"btn btn-theme\" href=\"";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("page_gestion_conge");
        echo "\">Retour</a>
               
        ";
        // line 30
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["conge"]) ? $context["conge"] : $this->getContext($context, "conge")), 'form_end');
        echo "
               
    </div>
    
";
        
        $__internal_1b45a8461d9fd131b98a18a9de7ab109b088859b228daa130beeeabc08ec9dd8->leave($__internal_1b45a8461d9fd131b98a18a9de7ab109b088859b228daa130beeeabc08ec9dd8_prof);

    }

    public function getTemplateName()
    {
        return "mehbatiInterimBundle:Artisan:VueMajConge.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  115 => 30,  108 => 28,  103 => 26,  99 => 25,  94 => 23,  90 => 22,  86 => 21,  77 => 15,  66 => 6,  60 => 5,  48 => 4,  36 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'mehbatiInterimBundle::base.html.twig' %}

{% block title %}Modifier congé{% endblock %}
{% block titrePage %}Modifier congé{% endblock %}
{% block contenu %}
    <div class=\"col-lg-1\"></div>
    <div class=\"col-lg-12\">
        <h4><center>Données de l'artisan</center></h4>
        <div class=\"hline\"></div><br>
    </div><br>
    
    <div class=\"col-lg-5\">
        <h3>Données actuel</h3>
        
        {{ form(congeDisabled) }}
    </div>
    <div class=\"col-lg-1\"></div>
    <div class=\"col-lg-5\">
        <h3>Données à modifier</h3>
        
        {{ form_start(conge) }}
            {{ form_label(conge.dateDebut) }}
            {{ form_widget(conge.dateDebut) }}
            
            {{ form_label(conge.dateFin) }}
            {{ form_widget(conge.dateFin) }}
            
            {{ form_widget(conge.maj) }} <a class=\"btn btn-theme\" href=\"{{path('page_gestion_conge')}}\">Retour</a>
               
        {{ form_end(conge) }}
               
    </div>
    
{% endblock%}

", "mehbatiInterimBundle:Artisan:VueMajConge.html.twig", "/var/www/batiInterim/src/meh/batiInterimBundle/Resources/views/Artisan/VueMajConge.html.twig");
    }
}
