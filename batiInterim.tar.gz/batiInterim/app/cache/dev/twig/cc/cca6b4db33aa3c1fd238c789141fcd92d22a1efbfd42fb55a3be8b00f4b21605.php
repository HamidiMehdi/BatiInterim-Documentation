<?php

/* WebProfilerBundle:Profiler:toolbar_redirect.html.twig */
class __TwigTemplate_c1ec513623266f0b2ed7a63bf52258224283ed66165cb0ef8541b1d97c564d38 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("TwigBundle::layout.html.twig", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "TwigBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_843ded9004de2a9eb59007d7859b61d9dde5a133f0c2834900af3a6f6ea3f4e6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_843ded9004de2a9eb59007d7859b61d9dde5a133f0c2834900af3a6f6ea3f4e6->enter($__internal_843ded9004de2a9eb59007d7859b61d9dde5a133f0c2834900af3a6f6ea3f4e6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_843ded9004de2a9eb59007d7859b61d9dde5a133f0c2834900af3a6f6ea3f4e6->leave($__internal_843ded9004de2a9eb59007d7859b61d9dde5a133f0c2834900af3a6f6ea3f4e6_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_cb7f487731c699a8214653fea853202904fcda4440dd0ecb7ef774874a01dffc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cb7f487731c699a8214653fea853202904fcda4440dd0ecb7ef774874a01dffc->enter($__internal_cb7f487731c699a8214653fea853202904fcda4440dd0ecb7ef774874a01dffc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Redirection Intercepted";
        
        $__internal_cb7f487731c699a8214653fea853202904fcda4440dd0ecb7ef774874a01dffc->leave($__internal_cb7f487731c699a8214653fea853202904fcda4440dd0ecb7ef774874a01dffc_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_cb671fff5d8ebef02f6f4ef49a9c3112df677cbfc7ada9c8c867e0c30d807b18 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cb671fff5d8ebef02f6f4ef49a9c3112df677cbfc7ada9c8c867e0c30d807b18->enter($__internal_cb671fff5d8ebef02f6f4ef49a9c3112df677cbfc7ada9c8c867e0c30d807b18_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"";
        // line 8
        echo twig_escape_filter($this->env, (isset($context["location"]) ? $context["location"] : $this->getContext($context, "location")), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, (isset($context["location"]) ? $context["location"] : $this->getContext($context, "location")), "html", null, true);
        echo "</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
";
        
        $__internal_cb671fff5d8ebef02f6f4ef49a9c3112df677cbfc7ada9c8c867e0c30d807b18->leave($__internal_cb671fff5d8ebef02f6f4ef49a9c3112df677cbfc7ada9c8c867e0c30d807b18_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:toolbar_redirect.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  57 => 8,  53 => 6,  47 => 5,  35 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'TwigBundle::layout.html.twig' %}

{% block title 'Redirection Intercepted' %}

{% block body %}
    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"{{ location }}\">{{ location }}</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
{% endblock %}
", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig", "/var/www/batiInterim/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Profiler/toolbar_redirect.html.twig");
    }
}
