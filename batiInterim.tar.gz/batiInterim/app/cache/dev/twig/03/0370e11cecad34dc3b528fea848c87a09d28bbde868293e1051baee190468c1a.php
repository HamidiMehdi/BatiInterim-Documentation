<?php

/* SensioDistributionBundle::Configurator/layout.html.twig */
class __TwigTemplate_091d34ef53b6021a3dde931175891d8d1f4375ee64d772721fa1457c7ffa9d27 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("TwigBundle::layout.html.twig", "SensioDistributionBundle::Configurator/layout.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "TwigBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_22d93d13771499eb96d11fe5099515939992b2640eef7f7ff6ee5430462d8f3d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_22d93d13771499eb96d11fe5099515939992b2640eef7f7ff6ee5430462d8f3d->enter($__internal_22d93d13771499eb96d11fe5099515939992b2640eef7f7ff6ee5430462d8f3d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SensioDistributionBundle::Configurator/layout.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_22d93d13771499eb96d11fe5099515939992b2640eef7f7ff6ee5430462d8f3d->leave($__internal_22d93d13771499eb96d11fe5099515939992b2640eef7f7ff6ee5430462d8f3d_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_ab0f88e2add741848f213fbe1c80182c05999041a7e496d1a2e2f21605ae21b6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ab0f88e2add741848f213fbe1c80182c05999041a7e496d1a2e2f21605ae21b6->enter($__internal_ab0f88e2add741848f213fbe1c80182c05999041a7e496d1a2e2f21605ae21b6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/sensiodistribution/webconfigurator/css/configurator.css"), "html", null, true);
        echo "\" />
";
        
        $__internal_ab0f88e2add741848f213fbe1c80182c05999041a7e496d1a2e2f21605ae21b6->leave($__internal_ab0f88e2add741848f213fbe1c80182c05999041a7e496d1a2e2f21605ae21b6_prof);

    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
        $__internal_6c28de1101d864d1c674666705105028a6208928a01f604f630f71c3c3ef92b1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6c28de1101d864d1c674666705105028a6208928a01f604f630f71c3c3ef92b1->enter($__internal_6c28de1101d864d1c674666705105028a6208928a01f604f630f71c3c3ef92b1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Web Configurator Bundle";
        
        $__internal_6c28de1101d864d1c674666705105028a6208928a01f604f630f71c3c3ef92b1->leave($__internal_6c28de1101d864d1c674666705105028a6208928a01f604f630f71c3c3ef92b1_prof);

    }

    // line 9
    public function block_body($context, array $blocks = array())
    {
        $__internal_35b3a13e9653eb9e24be904e391976cd763cc809529b80530593c4bfd2484882 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_35b3a13e9653eb9e24be904e391976cd763cc809529b80530593c4bfd2484882->enter($__internal_35b3a13e9653eb9e24be904e391976cd763cc809529b80530593c4bfd2484882_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 10
        echo "    <div class=\"block\">
        ";
        // line 11
        $this->displayBlock('content', $context, $blocks);
        // line 12
        echo "    </div>
    <div class=\"version\">Symfony Standard Edition v.";
        // line 13
        echo twig_escape_filter($this->env, (isset($context["version"]) ? $context["version"] : $this->getContext($context, "version")), "html", null, true);
        echo "</div>
";
        
        $__internal_35b3a13e9653eb9e24be904e391976cd763cc809529b80530593c4bfd2484882->leave($__internal_35b3a13e9653eb9e24be904e391976cd763cc809529b80530593c4bfd2484882_prof);

    }

    // line 11
    public function block_content($context, array $blocks = array())
    {
        $__internal_a0b14e7c27802cd36a106819d4e9dd3de6e29d3a793f675738aa544cf7f85227 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a0b14e7c27802cd36a106819d4e9dd3de6e29d3a793f675738aa544cf7f85227->enter($__internal_a0b14e7c27802cd36a106819d4e9dd3de6e29d3a793f675738aa544cf7f85227_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        
        $__internal_a0b14e7c27802cd36a106819d4e9dd3de6e29d3a793f675738aa544cf7f85227->leave($__internal_a0b14e7c27802cd36a106819d4e9dd3de6e29d3a793f675738aa544cf7f85227_prof);

    }

    public function getTemplateName()
    {
        return "SensioDistributionBundle::Configurator/layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  88 => 11,  79 => 13,  76 => 12,  74 => 11,  71 => 10,  65 => 9,  53 => 7,  43 => 4,  37 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"TwigBundle::layout.html.twig\" %}

{% block head %}
    <link rel=\"stylesheet\" href=\"{{ asset('bundles/sensiodistribution/webconfigurator/css/configurator.css') }}\" />
{% endblock %}

{% block title 'Web Configurator Bundle' %}

{% block body %}
    <div class=\"block\">
        {% block content %}{% endblock %}
    </div>
    <div class=\"version\">Symfony Standard Edition v.{{ version }}</div>
{% endblock %}
", "SensioDistributionBundle::Configurator/layout.html.twig", "/var/www/batiInterim/vendor/sensio/distribution-bundle/Sensio/Bundle/DistributionBundle/Resources/views/Configurator/layout.html.twig");
    }
}
