<?php

/* mehbatiInterimBundle:Gestionnaire:VueMajArtisan.html.twig */
class __TwigTemplate_576a5dd829f587d92f7c5893a271bb169daec703d1f223643014eebb8552fa73 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("mehbatiInterimBundle::base.html.twig", "mehbatiInterimBundle:Gestionnaire:VueMajArtisan.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'titrePage' => array($this, 'block_titrePage'),
            'contenu' => array($this, 'block_contenu'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "mehbatiInterimBundle::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6b6ce6febafc20f56a7599fd8c61778c03808da744ddd3a13bdc4149dc928c18 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6b6ce6febafc20f56a7599fd8c61778c03808da744ddd3a13bdc4149dc928c18->enter($__internal_6b6ce6febafc20f56a7599fd8c61778c03808da744ddd3a13bdc4149dc928c18_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "mehbatiInterimBundle:Gestionnaire:VueMajArtisan.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_6b6ce6febafc20f56a7599fd8c61778c03808da744ddd3a13bdc4149dc928c18->leave($__internal_6b6ce6febafc20f56a7599fd8c61778c03808da744ddd3a13bdc4149dc928c18_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_5822fa19223724d4bf4f150da3a3c82193b6e257f5bd7fb4922a82011f3b57c8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5822fa19223724d4bf4f150da3a3c82193b6e257f5bd7fb4922a82011f3b57c8->enter($__internal_5822fa19223724d4bf4f150da3a3c82193b6e257f5bd7fb4922a82011f3b57c8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Mise a jour Artisan";
        
        $__internal_5822fa19223724d4bf4f150da3a3c82193b6e257f5bd7fb4922a82011f3b57c8->leave($__internal_5822fa19223724d4bf4f150da3a3c82193b6e257f5bd7fb4922a82011f3b57c8_prof);

    }

    // line 4
    public function block_titrePage($context, array $blocks = array())
    {
        $__internal_5ad5ce37bfc8e7cdf74f19af8042a11562e2713024ce952f3e81c0f502f19fad = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5ad5ce37bfc8e7cdf74f19af8042a11562e2713024ce952f3e81c0f502f19fad->enter($__internal_5ad5ce37bfc8e7cdf74f19af8042a11562e2713024ce952f3e81c0f502f19fad_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "titrePage"));

        echo "Gestion Artisan / Mise à jour";
        
        $__internal_5ad5ce37bfc8e7cdf74f19af8042a11562e2713024ce952f3e81c0f502f19fad->leave($__internal_5ad5ce37bfc8e7cdf74f19af8042a11562e2713024ce952f3e81c0f502f19fad_prof);

    }

    // line 5
    public function block_contenu($context, array $blocks = array())
    {
        $__internal_80d4c52e80f7c2b7ffad451ab3a1b1a0cd0330620ea7ac6676a001a84361d655 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_80d4c52e80f7c2b7ffad451ab3a1b1a0cd0330620ea7ac6676a001a84361d655->enter($__internal_80d4c52e80f7c2b7ffad451ab3a1b1a0cd0330620ea7ac6676a001a84361d655_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "contenu"));

        // line 6
        echo "    <div class=\"col-lg-1\"></div>
    <div class=\"col-lg-12\">
        <h4><center>Données de l'artisan</center></h4>
        <div class=\"hline\"></div><br>
    </div><br>
    
    <div class=\"col-lg-5\">
        <h3>Données actuel</h3>
        
        ";
        // line 15
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["artisanDisabled"]) ? $context["artisanDisabled"] : $this->getContext($context, "artisanDisabled")), 'form');
        echo "
    </div>
    <div class=\"col-lg-1\"></div>
    <div class=\"col-lg-5\">
        <h3>Données à modifier</h3>
        
        ";
        // line 21
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["artisan"]) ? $context["artisan"] : $this->getContext($context, "artisan")), 'form_start');
        echo "
            ";
        // line 22
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["artisan"]) ? $context["artisan"] : $this->getContext($context, "artisan")), "nom", array()), 'label');
        echo "
            ";
        // line 23
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["artisan"]) ? $context["artisan"] : $this->getContext($context, "artisan")), "nom", array()), 'widget');
        echo "
                            
            ";
        // line 25
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["artisan"]) ? $context["artisan"] : $this->getContext($context, "artisan")), "prenom", array()), 'label');
        echo "
            ";
        // line 26
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["artisan"]) ? $context["artisan"] : $this->getContext($context, "artisan")), "prenom", array()), 'widget');
        echo "
            
            ";
        // line 28
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["artisan"]) ? $context["artisan"] : $this->getContext($context, "artisan")), "dateNaissance", array()), 'label');
        echo "
            ";
        // line 29
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["artisan"]) ? $context["artisan"] : $this->getContext($context, "artisan")), "dateNaissance", array()), 'widget');
        echo "
            
            ";
        // line 31
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["artisan"]) ? $context["artisan"] : $this->getContext($context, "artisan")), "lieuNaissance", array()), 'label');
        echo "
            ";
        // line 32
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["artisan"]) ? $context["artisan"] : $this->getContext($context, "artisan")), "lieuNaissance", array()), 'widget');
        echo "
            
            ";
        // line 34
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["artisan"]) ? $context["artisan"] : $this->getContext($context, "artisan")), "numTel", array()), 'label');
        echo "
            ";
        // line 35
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["artisan"]) ? $context["artisan"] : $this->getContext($context, "artisan")), "numTel", array()), 'widget');
        echo "
            
            ";
        // line 37
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["artisan"]) ? $context["artisan"] : $this->getContext($context, "artisan")), "adresse", array()), 'label');
        echo "
            ";
        // line 38
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["artisan"]) ? $context["artisan"] : $this->getContext($context, "artisan")), "adresse", array()), 'widget');
        echo "
            
            ";
        // line 40
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["artisan"]) ? $context["artisan"] : $this->getContext($context, "artisan")), "cp", array()), 'label');
        echo "
            ";
        // line 41
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["artisan"]) ? $context["artisan"] : $this->getContext($context, "artisan")), "cp", array()), 'widget');
        echo "
            
            ";
        // line 43
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["artisan"]) ? $context["artisan"] : $this->getContext($context, "artisan")), "corspMetier", array()), 'label');
        echo "
            ";
        // line 44
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["artisan"]) ? $context["artisan"] : $this->getContext($context, "artisan")), "corspMetier", array()), 'widget');
        echo "
            
            ";
        // line 46
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["artisan"]) ? $context["artisan"] : $this->getContext($context, "artisan")), "maj", array()), 'widget');
        echo " <a class=\"btn btn-theme\" href=\"";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("page_gestion_artisan");
        echo "\">Retour</a>
               
        ";
        // line 48
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["artisan"]) ? $context["artisan"] : $this->getContext($context, "artisan")), 'form_end');
        echo "
               
    </div>
    
";
        
        $__internal_80d4c52e80f7c2b7ffad451ab3a1b1a0cd0330620ea7ac6676a001a84361d655->leave($__internal_80d4c52e80f7c2b7ffad451ab3a1b1a0cd0330620ea7ac6676a001a84361d655_prof);

    }

    public function getTemplateName()
    {
        return "mehbatiInterimBundle:Gestionnaire:VueMajArtisan.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  169 => 48,  162 => 46,  157 => 44,  153 => 43,  148 => 41,  144 => 40,  139 => 38,  135 => 37,  130 => 35,  126 => 34,  121 => 32,  117 => 31,  112 => 29,  108 => 28,  103 => 26,  99 => 25,  94 => 23,  90 => 22,  86 => 21,  77 => 15,  66 => 6,  60 => 5,  48 => 4,  36 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'mehbatiInterimBundle::base.html.twig' %}

{% block title %}Mise a jour Artisan{% endblock %}
{% block titrePage %}Gestion Artisan / Mise à jour{% endblock %}
{% block contenu %}
    <div class=\"col-lg-1\"></div>
    <div class=\"col-lg-12\">
        <h4><center>Données de l'artisan</center></h4>
        <div class=\"hline\"></div><br>
    </div><br>
    
    <div class=\"col-lg-5\">
        <h3>Données actuel</h3>
        
        {{ form(artisanDisabled) }}
    </div>
    <div class=\"col-lg-1\"></div>
    <div class=\"col-lg-5\">
        <h3>Données à modifier</h3>
        
        {{ form_start(artisan) }}
            {{ form_label(artisan.nom) }}
            {{ form_widget(artisan.nom) }}
                            
            {{ form_label(artisan.prenom) }}
            {{ form_widget(artisan.prenom) }}
            
            {{ form_label(artisan.dateNaissance) }}
            {{ form_widget(artisan.dateNaissance) }}
            
            {{ form_label(artisan.lieuNaissance) }}
            {{ form_widget(artisan.lieuNaissance) }}
            
            {{ form_label(artisan.numTel) }}
            {{ form_widget(artisan.numTel) }}
            
            {{ form_label(artisan.adresse) }}
            {{ form_widget(artisan.adresse) }}
            
            {{ form_label(artisan.cp) }}
            {{ form_widget(artisan.cp) }}
            
            {{ form_label(artisan.corspMetier) }}
            {{ form_widget(artisan.corspMetier) }}
            
            {{ form_widget(artisan.maj) }} <a class=\"btn btn-theme\" href=\"{{path('page_gestion_artisan')}}\">Retour</a>
               
        {{ form_end(artisan) }}
               
    </div>
    
{% endblock%}

", "mehbatiInterimBundle:Gestionnaire:VueMajArtisan.html.twig", "/var/www/batiInterim/src/meh/batiInterimBundle/Resources/views/Gestionnaire/VueMajArtisan.html.twig");
    }
}
