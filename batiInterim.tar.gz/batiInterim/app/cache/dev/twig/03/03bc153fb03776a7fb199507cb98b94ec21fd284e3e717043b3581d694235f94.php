<?php

/* mehbatiInterimBundle:Gestionnaire:VueGestionEntrepreneur.html.twig */
class __TwigTemplate_e9c59440b25089290f11e0ee4dae40269dae2e80be69416a17a87afd48800b79 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("mehbatiInterimBundle::base.html.twig", "mehbatiInterimBundle:Gestionnaire:VueGestionEntrepreneur.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'titrePage' => array($this, 'block_titrePage'),
            'contenu' => array($this, 'block_contenu'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "mehbatiInterimBundle::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2e2282d86838742f32620f36d69766d3bbb8300d10d1bc6407d0db468e80eb06 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2e2282d86838742f32620f36d69766d3bbb8300d10d1bc6407d0db468e80eb06->enter($__internal_2e2282d86838742f32620f36d69766d3bbb8300d10d1bc6407d0db468e80eb06_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "mehbatiInterimBundle:Gestionnaire:VueGestionEntrepreneur.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_2e2282d86838742f32620f36d69766d3bbb8300d10d1bc6407d0db468e80eb06->leave($__internal_2e2282d86838742f32620f36d69766d3bbb8300d10d1bc6407d0db468e80eb06_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_48789a0369702e5c2bcb0cb62e7d4b5b2e6be8959734417a2cbc2f706d6db9cb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_48789a0369702e5c2bcb0cb62e7d4b5b2e6be8959734417a2cbc2f706d6db9cb->enter($__internal_48789a0369702e5c2bcb0cb62e7d4b5b2e6be8959734417a2cbc2f706d6db9cb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Gestion Entrepreneur";
        
        $__internal_48789a0369702e5c2bcb0cb62e7d4b5b2e6be8959734417a2cbc2f706d6db9cb->leave($__internal_48789a0369702e5c2bcb0cb62e7d4b5b2e6be8959734417a2cbc2f706d6db9cb_prof);

    }

    // line 4
    public function block_titrePage($context, array $blocks = array())
    {
        $__internal_21491e4ab49c4b9f1820b4aa08d0b24334a48ae810d5be6c5f11ee0d3b8c0c10 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_21491e4ab49c4b9f1820b4aa08d0b24334a48ae810d5be6c5f11ee0d3b8c0c10->enter($__internal_21491e4ab49c4b9f1820b4aa08d0b24334a48ae810d5be6c5f11ee0d3b8c0c10_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "titrePage"));

        echo "Gestion Entrepreneur";
        
        $__internal_21491e4ab49c4b9f1820b4aa08d0b24334a48ae810d5be6c5f11ee0d3b8c0c10->leave($__internal_21491e4ab49c4b9f1820b4aa08d0b24334a48ae810d5be6c5f11ee0d3b8c0c10_prof);

    }

    // line 5
    public function block_contenu($context, array $blocks = array())
    {
        $__internal_a437eb5370314aa57b0941da573408febc4e5e09adc446a438e9d711142be1c5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a437eb5370314aa57b0941da573408febc4e5e09adc446a438e9d711142be1c5->enter($__internal_a437eb5370314aa57b0941da573408febc4e5e09adc446a438e9d711142be1c5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "contenu"));

        // line 6
        echo "    
    <div class=\"col-lg-1\"></div>
    <div class=\"col-lg-10\">
        <h4><center>Les entrepreneurs</center></h4>
        <div class=\"hline\"></div><br>
        <table class=\"table table-hover\">
            <thead>
                <tr>
                    <th>Nom</th>
                    <th>Prenom</th>
                    <th>Nom de société</th>
                </tr>
            </thead>
            <tbody>
                
            ";
        // line 21
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["entrepreneurs"]) ? $context["entrepreneurs"] : $this->getContext($context, "entrepreneurs")));
        foreach ($context['_seq'] as $context["_key"] => $context["unEntrepreneur"]) {
            // line 22
            echo "                <tr>
                        <td>";
            // line 23
            echo twig_escape_filter($this->env, $this->getAttribute($context["unEntrepreneur"], "nomChef", array()), "html", null, true);
            echo "</td>
                        <td>";
            // line 24
            echo twig_escape_filter($this->env, $this->getAttribute($context["unEntrepreneur"], "prenomChef", array()), "html", null, true);
            echo "</td>
                        <td>";
            // line 25
            echo twig_escape_filter($this->env, $this->getAttribute($context["unEntrepreneur"], "nomSociete", array()), "html", null, true);
            echo "</td>
                        <td><a class=\"btn btn-theme\" href=\"";
            // line 26
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("page_gestion_maj_entrepreneur", array("id" => $this->getAttribute($context["unEntrepreneur"], "idEntrepreneur", array()))), "html", null, true);
            echo "\">Mettre à jour</a></td>
                        <td><a class=\"btn btn-danger\" href=\"";
            // line 27
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("page_gestion_delete_entrepreneur", array("id" => $this->getAttribute($context["unEntrepreneur"], "idEntrepreneur", array()))), "html", null, true);
            echo "\" >Supprimer</a></td>
                    </tr>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['unEntrepreneur'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 29
        echo "  
            </tbody>
        </table>
    </div>
    
";
        
        $__internal_a437eb5370314aa57b0941da573408febc4e5e09adc446a438e9d711142be1c5->leave($__internal_a437eb5370314aa57b0941da573408febc4e5e09adc446a438e9d711142be1c5_prof);

    }

    public function getTemplateName()
    {
        return "mehbatiInterimBundle:Gestionnaire:VueGestionEntrepreneur.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  115 => 29,  106 => 27,  102 => 26,  98 => 25,  94 => 24,  90 => 23,  87 => 22,  83 => 21,  66 => 6,  60 => 5,  48 => 4,  36 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'mehbatiInterimBundle::base.html.twig' %}

{% block title %}Gestion Entrepreneur{% endblock %}
{% block titrePage %}Gestion Entrepreneur{% endblock %}
{% block contenu %}
    
    <div class=\"col-lg-1\"></div>
    <div class=\"col-lg-10\">
        <h4><center>Les entrepreneurs</center></h4>
        <div class=\"hline\"></div><br>
        <table class=\"table table-hover\">
            <thead>
                <tr>
                    <th>Nom</th>
                    <th>Prenom</th>
                    <th>Nom de société</th>
                </tr>
            </thead>
            <tbody>
                
            {% for unEntrepreneur in entrepreneurs %}
                <tr>
                        <td>{{unEntrepreneur.nomChef}}</td>
                        <td>{{unEntrepreneur.prenomChef}}</td>
                        <td>{{unEntrepreneur.nomSociete}}</td>
                        <td><a class=\"btn btn-theme\" href=\"{{path('page_gestion_maj_entrepreneur', {'id': unEntrepreneur.idEntrepreneur })}}\">Mettre à jour</a></td>
                        <td><a class=\"btn btn-danger\" href=\"{{path('page_gestion_delete_entrepreneur', {'id': unEntrepreneur.idEntrepreneur })}}\" >Supprimer</a></td>
                    </tr>
            {% endfor %}  
            </tbody>
        </table>
    </div>
    
{% endblock%}
", "mehbatiInterimBundle:Gestionnaire:VueGestionEntrepreneur.html.twig", "/var/www/batiInterim/src/meh/batiInterimBundle/Resources/views/Gestionnaire/VueGestionEntrepreneur.html.twig");
    }
}
