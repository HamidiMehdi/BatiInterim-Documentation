<?php

/* mehbatiInterimBundle:Commun:VueChangerMdp.html.twig */
class __TwigTemplate_87dadbaf144559a66fa77747e932b7ac58eba863637d8bc869238c5a4ea2c168 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("mehbatiInterimBundle::base.html.twig", "mehbatiInterimBundle:Commun:VueChangerMdp.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'titrePage' => array($this, 'block_titrePage'),
            'contenu' => array($this, 'block_contenu'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "mehbatiInterimBundle::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ebf6bccd4b5bd6454f72df2734a91756efb1cc7bb705e1d3f25c06023e55ac90 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ebf6bccd4b5bd6454f72df2734a91756efb1cc7bb705e1d3f25c06023e55ac90->enter($__internal_ebf6bccd4b5bd6454f72df2734a91756efb1cc7bb705e1d3f25c06023e55ac90_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "mehbatiInterimBundle:Commun:VueChangerMdp.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_ebf6bccd4b5bd6454f72df2734a91756efb1cc7bb705e1d3f25c06023e55ac90->leave($__internal_ebf6bccd4b5bd6454f72df2734a91756efb1cc7bb705e1d3f25c06023e55ac90_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_8936e5c357b8b90177b0277341b47acbbae3e6f2bfb732f0893917e72f9399fc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8936e5c357b8b90177b0277341b47acbbae3e6f2bfb732f0893917e72f9399fc->enter($__internal_8936e5c357b8b90177b0277341b47acbbae3e6f2bfb732f0893917e72f9399fc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Modification mot de passe";
        
        $__internal_8936e5c357b8b90177b0277341b47acbbae3e6f2bfb732f0893917e72f9399fc->leave($__internal_8936e5c357b8b90177b0277341b47acbbae3e6f2bfb732f0893917e72f9399fc_prof);

    }

    // line 4
    public function block_titrePage($context, array $blocks = array())
    {
        $__internal_bafdc0208ef1e1da3b16e31d63b6f75a8852d2d520e0d3e9d0c16b97651f83d9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bafdc0208ef1e1da3b16e31d63b6f75a8852d2d520e0d3e9d0c16b97651f83d9->enter($__internal_bafdc0208ef1e1da3b16e31d63b6f75a8852d2d520e0d3e9d0c16b97651f83d9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "titrePage"));

        echo "Modification mot de passe";
        
        $__internal_bafdc0208ef1e1da3b16e31d63b6f75a8852d2d520e0d3e9d0c16b97651f83d9->leave($__internal_bafdc0208ef1e1da3b16e31d63b6f75a8852d2d520e0d3e9d0c16b97651f83d9_prof);

    }

    // line 5
    public function block_contenu($context, array $blocks = array())
    {
        $__internal_46ebc9f20742ed2b2d8cd0270816d2e1d09c69fd632d6fe7d22636ac735123fe = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_46ebc9f20742ed2b2d8cd0270816d2e1d09c69fd632d6fe7d22636ac735123fe->enter($__internal_46ebc9f20742ed2b2d8cd0270816d2e1d09c69fd632d6fe7d22636ac735123fe_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "contenu"));

        // line 6
        echo "    
    <div class=\"col-lg-2\"></div>
    <div class=\"col-lg-8\">
        <h4><center>Modifier votre mot de passe</center></h4>
        <div class=\"hline\"></div><br>
        ";
        // line 11
        if ( !twig_test_empty((isset($context["erreurMdpActuel"]) ? $context["erreurMdpActuel"] : $this->getContext($context, "erreurMdpActuel")))) {
            // line 12
            echo "            <br><div class=\"alert alert-danger\"><center><b>Erreur : </b>";
            echo twig_escape_filter($this->env, (isset($context["erreurMdpActuel"]) ? $context["erreurMdpActuel"] : $this->getContext($context, "erreurMdpActuel")), "html", null, true);
            echo "</center></div>
        ";
        }
        // line 13
        echo " 
        ";
        // line 14
        if ( !twig_test_empty((isset($context["erreurNewMdp"]) ? $context["erreurNewMdp"] : $this->getContext($context, "erreurNewMdp")))) {
            // line 15
            echo "            <br><div class=\"alert alert-warning\"><center><b>Attention : </b>";
            echo twig_escape_filter($this->env, (isset($context["erreurNewMdp"]) ? $context["erreurNewMdp"] : $this->getContext($context, "erreurNewMdp")), "html", null, true);
            echo "</center></div>
        ";
        }
        // line 16
        echo " 
        ";
        // line 17
        if ( !twig_test_empty((isset($context["succes"]) ? $context["succes"] : $this->getContext($context, "succes")))) {
            // line 18
            echo "            <br><div class=\"alert alert-success\"><center><b>Succès : </b>";
            echo twig_escape_filter($this->env, (isset($context["succes"]) ? $context["succes"] : $this->getContext($context, "succes")), "html", null, true);
            echo "</center></div>
        ";
        }
        // line 19
        echo " 
        ";
        // line 20
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form');
        echo "
    </div>
    
";
        
        $__internal_46ebc9f20742ed2b2d8cd0270816d2e1d09c69fd632d6fe7d22636ac735123fe->leave($__internal_46ebc9f20742ed2b2d8cd0270816d2e1d09c69fd632d6fe7d22636ac735123fe_prof);

    }

    public function getTemplateName()
    {
        return "mehbatiInterimBundle:Commun:VueChangerMdp.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  106 => 20,  103 => 19,  97 => 18,  95 => 17,  92 => 16,  86 => 15,  84 => 14,  81 => 13,  75 => 12,  73 => 11,  66 => 6,  60 => 5,  48 => 4,  36 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'mehbatiInterimBundle::base.html.twig' %}

{% block title %}Modification mot de passe{% endblock %}
{% block titrePage %}Modification mot de passe{% endblock %}
{% block contenu %}
    
    <div class=\"col-lg-2\"></div>
    <div class=\"col-lg-8\">
        <h4><center>Modifier votre mot de passe</center></h4>
        <div class=\"hline\"></div><br>
        {% if erreurMdpActuel is not empty %}
            <br><div class=\"alert alert-danger\"><center><b>Erreur : </b>{{erreurMdpActuel}}</center></div>
        {% endif %} 
        {% if erreurNewMdp is not empty %}
            <br><div class=\"alert alert-warning\"><center><b>Attention : </b>{{erreurNewMdp}}</center></div>
        {% endif %} 
        {% if succes is not empty %}
            <br><div class=\"alert alert-success\"><center><b>Succès : </b>{{succes}}</center></div>
        {% endif %} 
        {{form(form)}}
    </div>
    
{% endblock%}", "mehbatiInterimBundle:Commun:VueChangerMdp.html.twig", "/var/www/batiInterim/src/meh/batiInterimBundle/Resources/views/Commun/VueChangerMdp.html.twig");
    }
}
