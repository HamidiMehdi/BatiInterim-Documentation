<?php

/* mehbatiInterimBundle:Commun:VueChangerMdpPremierConnexion.html.twig */
class __TwigTemplate_918118f52e9ad5918f71cc5c3a30753fff5aa9d0b8018d81481e1cabf59f0a26 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 2
        $this->parent = $this->loadTemplate("mehbatiInterimBundle::base.html.twig", "mehbatiInterimBundle:Commun:VueChangerMdpPremierConnexion.html.twig", 2);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'titrePage' => array($this, 'block_titrePage'),
            'contenu' => array($this, 'block_contenu'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "mehbatiInterimBundle::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5337fd25d50220bc040ad01eb9a3869e4b0352109821690d8805921a05551f46 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5337fd25d50220bc040ad01eb9a3869e4b0352109821690d8805921a05551f46->enter($__internal_5337fd25d50220bc040ad01eb9a3869e4b0352109821690d8805921a05551f46_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "mehbatiInterimBundle:Commun:VueChangerMdpPremierConnexion.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_5337fd25d50220bc040ad01eb9a3869e4b0352109821690d8805921a05551f46->leave($__internal_5337fd25d50220bc040ad01eb9a3869e4b0352109821690d8805921a05551f46_prof);

    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        $__internal_316ffa09c1d5aed97769ef1506191bbc4c2a837ab7ef7b3bd58b07a218365390 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_316ffa09c1d5aed97769ef1506191bbc4c2a837ab7ef7b3bd58b07a218365390->enter($__internal_316ffa09c1d5aed97769ef1506191bbc4c2a837ab7ef7b3bd58b07a218365390_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Premiére connexion";
        
        $__internal_316ffa09c1d5aed97769ef1506191bbc4c2a837ab7ef7b3bd58b07a218365390->leave($__internal_316ffa09c1d5aed97769ef1506191bbc4c2a837ab7ef7b3bd58b07a218365390_prof);

    }

    // line 5
    public function block_titrePage($context, array $blocks = array())
    {
        $__internal_8af7b7f5efba41746544237b14255dd3f12ff6d6f9b3f482b4aa4ba5ba6da759 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8af7b7f5efba41746544237b14255dd3f12ff6d6f9b3f482b4aa4ba5ba6da759->enter($__internal_8af7b7f5efba41746544237b14255dd3f12ff6d6f9b3f482b4aa4ba5ba6da759_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "titrePage"));

        echo "Premiére connexion / mot de passe ";
        
        $__internal_8af7b7f5efba41746544237b14255dd3f12ff6d6f9b3f482b4aa4ba5ba6da759->leave($__internal_8af7b7f5efba41746544237b14255dd3f12ff6d6f9b3f482b4aa4ba5ba6da759_prof);

    }

    // line 6
    public function block_contenu($context, array $blocks = array())
    {
        $__internal_52caffc0dbd96206929455a6d39c5a30cb0a570492e572e77b27bf9edb7c22f2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_52caffc0dbd96206929455a6d39c5a30cb0a570492e572e77b27bf9edb7c22f2->enter($__internal_52caffc0dbd96206929455a6d39c5a30cb0a570492e572e77b27bf9edb7c22f2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "contenu"));

        // line 7
        echo "    
    <div class=\"col-lg-2\"></div>
    <div class=\"col-lg-8\">
        <h4><center>Choisissez votre mot de passe</center></h4>
        <div class=\"hline\"></div><br>
        ";
        // line 12
        if ( !twig_test_empty((isset($context["erreur"]) ? $context["erreur"] : $this->getContext($context, "erreur")))) {
            // line 13
            echo "            <br><div class=\"alert alert-warning\"><center><b>Attention : </b>";
            echo twig_escape_filter($this->env, (isset($context["erreur"]) ? $context["erreur"] : $this->getContext($context, "erreur")), "html", null, true);
            echo "</center></div>
        ";
        }
        // line 14
        echo "  
        ";
        // line 15
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form');
        echo "
    </div>
    
    
";
        
        $__internal_52caffc0dbd96206929455a6d39c5a30cb0a570492e572e77b27bf9edb7c22f2->leave($__internal_52caffc0dbd96206929455a6d39c5a30cb0a570492e572e77b27bf9edb7c22f2_prof);

    }

    public function getTemplateName()
    {
        return "mehbatiInterimBundle:Commun:VueChangerMdpPremierConnexion.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  84 => 15,  81 => 14,  75 => 13,  73 => 12,  66 => 7,  60 => 6,  48 => 5,  36 => 4,  11 => 2,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("
{% extends 'mehbatiInterimBundle::base.html.twig' %}

{% block title %}Premiére connexion{% endblock %}
{% block titrePage %}Premiére connexion / mot de passe {% endblock %}
{% block contenu %}
    
    <div class=\"col-lg-2\"></div>
    <div class=\"col-lg-8\">
        <h4><center>Choisissez votre mot de passe</center></h4>
        <div class=\"hline\"></div><br>
        {% if erreur is not empty %}
            <br><div class=\"alert alert-warning\"><center><b>Attention : </b>{{erreur}}</center></div>
        {% endif %}  
        {{form(form)}}
    </div>
    
    
{% endblock%}

", "mehbatiInterimBundle:Commun:VueChangerMdpPremierConnexion.html.twig", "/var/www/batiInterim/src/meh/batiInterimBundle/Resources/views/Commun/VueChangerMdpPremierConnexion.html.twig");
    }
}
