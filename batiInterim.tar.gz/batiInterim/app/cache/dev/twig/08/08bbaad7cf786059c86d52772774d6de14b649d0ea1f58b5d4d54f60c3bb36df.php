<?php

/* mehbatiInterimBundle:Gestionnaire:VueNewEntrepreneur.html.twig */
class __TwigTemplate_3e8dced0ac0b29b605f6355c12c67cb34efaaaf39d9c8e75703f3f6c3e765028 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("mehbatiInterimBundle::base.html.twig", "mehbatiInterimBundle:Gestionnaire:VueNewEntrepreneur.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'titrePage' => array($this, 'block_titrePage'),
            'contenu' => array($this, 'block_contenu'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "mehbatiInterimBundle::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1a199d92d338b3042877990a6c36f2283ae18a80e12e3cbe7f98d0e838495997 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1a199d92d338b3042877990a6c36f2283ae18a80e12e3cbe7f98d0e838495997->enter($__internal_1a199d92d338b3042877990a6c36f2283ae18a80e12e3cbe7f98d0e838495997_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "mehbatiInterimBundle:Gestionnaire:VueNewEntrepreneur.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_1a199d92d338b3042877990a6c36f2283ae18a80e12e3cbe7f98d0e838495997->leave($__internal_1a199d92d338b3042877990a6c36f2283ae18a80e12e3cbe7f98d0e838495997_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_493d323cbb11cd44184fed2228ac2195e453f2227181dca5596637cfba933242 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_493d323cbb11cd44184fed2228ac2195e453f2227181dca5596637cfba933242->enter($__internal_493d323cbb11cd44184fed2228ac2195e453f2227181dca5596637cfba933242_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Nouveau Entrepreneur";
        
        $__internal_493d323cbb11cd44184fed2228ac2195e453f2227181dca5596637cfba933242->leave($__internal_493d323cbb11cd44184fed2228ac2195e453f2227181dca5596637cfba933242_prof);

    }

    // line 4
    public function block_titrePage($context, array $blocks = array())
    {
        $__internal_099fb43fb385c6bd63cdc4ed382b157b567cd5f8702ffb9f7130fb148cec5efd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_099fb43fb385c6bd63cdc4ed382b157b567cd5f8702ffb9f7130fb148cec5efd->enter($__internal_099fb43fb385c6bd63cdc4ed382b157b567cd5f8702ffb9f7130fb148cec5efd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "titrePage"));

        echo "Nouveau Entrepreneur";
        
        $__internal_099fb43fb385c6bd63cdc4ed382b157b567cd5f8702ffb9f7130fb148cec5efd->leave($__internal_099fb43fb385c6bd63cdc4ed382b157b567cd5f8702ffb9f7130fb148cec5efd_prof);

    }

    // line 5
    public function block_contenu($context, array $blocks = array())
    {
        $__internal_d60fac1d95d51408e9adb64fe8bb0ca6f9a4ce120bfe4c9f7012a017edb3fac7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d60fac1d95d51408e9adb64fe8bb0ca6f9a4ce120bfe4c9f7012a017edb3fac7->enter($__internal_d60fac1d95d51408e9adb64fe8bb0ca6f9a4ce120bfe4c9f7012a017edb3fac7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "contenu"));

        // line 6
        echo "    
    <div class=\"col-lg-2\"></div>
    <div class=\"col-lg-8\">
        <h4><center>Nouvelle entrepreneur</center></h4>
        <div class=\"hline\"></div><br>
        ";
        // line 11
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form');
        echo "
    </div>
    
";
        
        $__internal_d60fac1d95d51408e9adb64fe8bb0ca6f9a4ce120bfe4c9f7012a017edb3fac7->leave($__internal_d60fac1d95d51408e9adb64fe8bb0ca6f9a4ce120bfe4c9f7012a017edb3fac7_prof);

    }

    public function getTemplateName()
    {
        return "mehbatiInterimBundle:Gestionnaire:VueNewEntrepreneur.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 11,  66 => 6,  60 => 5,  48 => 4,  36 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'mehbatiInterimBundle::base.html.twig' %}

{% block title %}Nouveau Entrepreneur{% endblock %}
{% block titrePage %}Nouveau Entrepreneur{% endblock %}
{% block contenu %}
    
    <div class=\"col-lg-2\"></div>
    <div class=\"col-lg-8\">
        <h4><center>Nouvelle entrepreneur</center></h4>
        <div class=\"hline\"></div><br>
        {{form(form)}}
    </div>
    
{% endblock%}

", "mehbatiInterimBundle:Gestionnaire:VueNewEntrepreneur.html.twig", "/var/www/batiInterim/src/meh/batiInterimBundle/Resources/views/Gestionnaire/VueNewEntrepreneur.html.twig");
    }
}
