<?php

/* mehbatiInterimBundle:Entrepreneur_ChefChantier:VueMissionDunChantier.html.twig */
class __TwigTemplate_ff7f7746ccebdacf4fd366ad45d0ca7cb8ec8798c6df638f304934d98aa20020 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("mehbatiInterimBundle::base.html.twig", "mehbatiInterimBundle:Entrepreneur_ChefChantier:VueMissionDunChantier.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'titrePage' => array($this, 'block_titrePage'),
            'contenu' => array($this, 'block_contenu'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "mehbatiInterimBundle::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_60fbc2b6613d7767745f2027cff57595944b4aafd080b4190092cf0069f8ea16 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_60fbc2b6613d7767745f2027cff57595944b4aafd080b4190092cf0069f8ea16->enter($__internal_60fbc2b6613d7767745f2027cff57595944b4aafd080b4190092cf0069f8ea16_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "mehbatiInterimBundle:Entrepreneur_ChefChantier:VueMissionDunChantier.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_60fbc2b6613d7767745f2027cff57595944b4aafd080b4190092cf0069f8ea16->leave($__internal_60fbc2b6613d7767745f2027cff57595944b4aafd080b4190092cf0069f8ea16_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_a17b61a19d0422b167fc8255c9c794c73a4f05840e6b49dc9ca443ad692d0f59 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a17b61a19d0422b167fc8255c9c794c73a4f05840e6b49dc9ca443ad692d0f59->enter($__internal_a17b61a19d0422b167fc8255c9c794c73a4f05840e6b49dc9ca443ad692d0f59_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Mission d'un chantier";
        
        $__internal_a17b61a19d0422b167fc8255c9c794c73a4f05840e6b49dc9ca443ad692d0f59->leave($__internal_a17b61a19d0422b167fc8255c9c794c73a4f05840e6b49dc9ca443ad692d0f59_prof);

    }

    // line 4
    public function block_titrePage($context, array $blocks = array())
    {
        $__internal_a9274d5f8792caba1fad9303c712243be2a0cad8a36e47430beb12699e411c89 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a9274d5f8792caba1fad9303c712243be2a0cad8a36e47430beb12699e411c89->enter($__internal_a9274d5f8792caba1fad9303c712243be2a0cad8a36e47430beb12699e411c89_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "titrePage"));

        echo "Mission d'un chantier";
        
        $__internal_a9274d5f8792caba1fad9303c712243be2a0cad8a36e47430beb12699e411c89->leave($__internal_a9274d5f8792caba1fad9303c712243be2a0cad8a36e47430beb12699e411c89_prof);

    }

    // line 5
    public function block_contenu($context, array $blocks = array())
    {
        $__internal_a95c0b792080dbc954b00b08914ed7ca5f3bf6bd4700106035956f7b8a734d3f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a95c0b792080dbc954b00b08914ed7ca5f3bf6bd4700106035956f7b8a734d3f->enter($__internal_a95c0b792080dbc954b00b08914ed7ca5f3bf6bd4700106035956f7b8a734d3f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "contenu"));

        // line 6
        echo "    
    <div class=\"col-lg-1\"></div>
    <div class=\"col-lg-10\">
        <h4><center>Les missions d'un chantier sélectioné</center></h4>
        <div class=\"hline\"></div><br>
        ";
        // line 11
        if ((twig_length_filter($this->env, (isset($context["missions"]) ? $context["missions"] : $this->getContext($context, "missions"))) >= 1)) {
            // line 12
            echo "            <table class=\"table table-hover\">
                <thead>
                    <tr>
                        <th>Date de début</th>
                        <th>Date de fin</th>
                        <th>Intitulé</th>
                        <th>Nombre d'artisan</th>
                        <th>Prix par jour</th>
                    </tr>
                </thead>
                <tbody>

                ";
            // line 24
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["missions"]) ? $context["missions"] : $this->getContext($context, "missions")));
            foreach ($context['_seq'] as $context["_key"] => $context["uneMissions"]) {
                // line 25
                echo "                    <tr>
                        <td>";
                // line 26
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["uneMissions"], "datedebut", array()), "d/m/Y"), "html", null, true);
                echo "</td>
                        <td>";
                // line 27
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["uneMissions"], "datefin", array()), "d/m/Y"), "html", null, true);
                echo "</td>
                        <td>";
                // line 28
                echo twig_escape_filter($this->env, $this->getAttribute($context["uneMissions"], "intitule", array()), "html", null, true);
                echo "</td>
                        <td>";
                // line 29
                echo twig_escape_filter($this->env, $this->getAttribute($context["uneMissions"], "nbartisans", array()), "html", null, true);
                echo "</td>
                        <td>";
                // line 30
                echo twig_escape_filter($this->env, $this->getAttribute($context["uneMissions"], "prixparjour", array()), "html", null, true);
                echo " €</td>
                    </tr>
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['uneMissions'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 33
            echo "                </tbody>
            </table> 
        ";
        } else {
            // line 35
            echo "    
            Le chantier n'a aucune mission.
        ";
        }
        // line 37
        echo "   
    </div>
        
";
        
        $__internal_a95c0b792080dbc954b00b08914ed7ca5f3bf6bd4700106035956f7b8a734d3f->leave($__internal_a95c0b792080dbc954b00b08914ed7ca5f3bf6bd4700106035956f7b8a734d3f_prof);

    }

    public function getTemplateName()
    {
        return "mehbatiInterimBundle:Entrepreneur_ChefChantier:VueMissionDunChantier.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  131 => 37,  126 => 35,  121 => 33,  112 => 30,  108 => 29,  104 => 28,  100 => 27,  96 => 26,  93 => 25,  89 => 24,  75 => 12,  73 => 11,  66 => 6,  60 => 5,  48 => 4,  36 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'mehbatiInterimBundle::base.html.twig' %}

{% block title %}Mission d'un chantier{% endblock %}
{% block titrePage %}Mission d'un chantier{% endblock %}
{% block contenu %}
    
    <div class=\"col-lg-1\"></div>
    <div class=\"col-lg-10\">
        <h4><center>Les missions d'un chantier sélectioné</center></h4>
        <div class=\"hline\"></div><br>
        {% if missions|length >=1 %}
            <table class=\"table table-hover\">
                <thead>
                    <tr>
                        <th>Date de début</th>
                        <th>Date de fin</th>
                        <th>Intitulé</th>
                        <th>Nombre d'artisan</th>
                        <th>Prix par jour</th>
                    </tr>
                </thead>
                <tbody>

                {% for uneMissions in missions %}
                    <tr>
                        <td>{{uneMissions.datedebut|date('d/m/Y')}}</td>
                        <td>{{uneMissions.datefin|date('d/m/Y')}}</td>
                        <td>{{uneMissions.intitule}}</td>
                        <td>{{uneMissions.nbartisans}}</td>
                        <td>{{uneMissions.prixparjour}} €</td>
                    </tr>
                {% endfor %}
                </tbody>
            </table> 
        {% else %}    
            Le chantier n'a aucune mission.
        {% endif %}   
    </div>
        
{% endblock%}


", "mehbatiInterimBundle:Entrepreneur_ChefChantier:VueMissionDunChantier.html.twig", "/var/www/batiInterim/src/meh/batiInterimBundle/Resources/views/Entrepreneur_ChefChantier/VueMissionDunChantier.html.twig");
    }
}
