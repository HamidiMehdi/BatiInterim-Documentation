<?php

/* mehbatiInterimBundle:Commun:VueConnexion.html.twig */
class __TwigTemplate_dde35c6ba4f16321788391b47ea80b31c27c6d4cb1b5cf3135487cbdbe5e9be2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("mehbatiInterimBundle::base.html.twig", "mehbatiInterimBundle:Commun:VueConnexion.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'titrePage' => array($this, 'block_titrePage'),
            'contenu' => array($this, 'block_contenu'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "mehbatiInterimBundle::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_597dbf76ea7f9ff6e83c19ce11a9a2c3f883b5a04a426c9dee51118473f59c9a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_597dbf76ea7f9ff6e83c19ce11a9a2c3f883b5a04a426c9dee51118473f59c9a->enter($__internal_597dbf76ea7f9ff6e83c19ce11a9a2c3f883b5a04a426c9dee51118473f59c9a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "mehbatiInterimBundle:Commun:VueConnexion.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_597dbf76ea7f9ff6e83c19ce11a9a2c3f883b5a04a426c9dee51118473f59c9a->leave($__internal_597dbf76ea7f9ff6e83c19ce11a9a2c3f883b5a04a426c9dee51118473f59c9a_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_1e751db061630cf83a51f67c45198e63222298ac8b5e26510d623a63773e8934 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1e751db061630cf83a51f67c45198e63222298ac8b5e26510d623a63773e8934->enter($__internal_1e751db061630cf83a51f67c45198e63222298ac8b5e26510d623a63773e8934_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Connexion";
        
        $__internal_1e751db061630cf83a51f67c45198e63222298ac8b5e26510d623a63773e8934->leave($__internal_1e751db061630cf83a51f67c45198e63222298ac8b5e26510d623a63773e8934_prof);

    }

    // line 4
    public function block_titrePage($context, array $blocks = array())
    {
        $__internal_5bd0148bf0868da6d3d730cb869f7d0a55b273820220d3ad680ea154831f8c1d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5bd0148bf0868da6d3d730cb869f7d0a55b273820220d3ad680ea154831f8c1d->enter($__internal_5bd0148bf0868da6d3d730cb869f7d0a55b273820220d3ad680ea154831f8c1d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "titrePage"));

        echo "Connexion";
        
        $__internal_5bd0148bf0868da6d3d730cb869f7d0a55b273820220d3ad680ea154831f8c1d->leave($__internal_5bd0148bf0868da6d3d730cb869f7d0a55b273820220d3ad680ea154831f8c1d_prof);

    }

    // line 5
    public function block_contenu($context, array $blocks = array())
    {
        $__internal_fbc88bef576f2e7810b511cedd56aece2d00dacedf9057aec7ee87861064ecf8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fbc88bef576f2e7810b511cedd56aece2d00dacedf9057aec7ee87861064ecf8->enter($__internal_fbc88bef576f2e7810b511cedd56aece2d00dacedf9057aec7ee87861064ecf8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "contenu"));

        // line 6
        echo "    
    <div class=\"col-lg-2\"></div>
    <div class=\"col-lg-8\">
        <h4><center>Connectez-vous !</center></h4>
        <div class=\"hline\"></div><br>
        ";
        // line 11
        if ( !twig_test_empty((isset($context["erreurConnexion"]) ? $context["erreurConnexion"] : $this->getContext($context, "erreurConnexion")))) {
            // line 12
            echo "            <br><div class=\"alert alert-danger\"><center><b>Erreur : </b>";
            echo twig_escape_filter($this->env, (isset($context["erreurConnexion"]) ? $context["erreurConnexion"] : $this->getContext($context, "erreurConnexion")), "html", null, true);
            echo "</center></div>
        ";
        }
        // line 13
        echo "   
        ";
        // line 14
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "
            ";
        // line 15
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "login", array()), 'label');
        echo "
            ";
        // line 16
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "login", array()), 'widget');
        echo "
                            
            ";
        // line 18
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "mdp", array()), 'label');
        echo "
            ";
        // line 19
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "mdp", array()), 'widget');
        echo "
                            
            ";
        // line 21
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "profils", array()), 'label');
        echo "
            ";
        // line 22
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "profils", array()), 'widget');
        echo "
            <br>    
        ";
        // line 24
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "
                
    </div>
    
";
        
        $__internal_fbc88bef576f2e7810b511cedd56aece2d00dacedf9057aec7ee87861064ecf8->leave($__internal_fbc88bef576f2e7810b511cedd56aece2d00dacedf9057aec7ee87861064ecf8_prof);

    }

    public function getTemplateName()
    {
        return "mehbatiInterimBundle:Commun:VueConnexion.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  115 => 24,  110 => 22,  106 => 21,  101 => 19,  97 => 18,  92 => 16,  88 => 15,  84 => 14,  81 => 13,  75 => 12,  73 => 11,  66 => 6,  60 => 5,  48 => 4,  36 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'mehbatiInterimBundle::base.html.twig' %}

{% block title %}Connexion{% endblock %}
{% block titrePage %}Connexion{% endblock %}
{% block contenu %}
    
    <div class=\"col-lg-2\"></div>
    <div class=\"col-lg-8\">
        <h4><center>Connectez-vous !</center></h4>
        <div class=\"hline\"></div><br>
        {% if erreurConnexion is not empty %}
            <br><div class=\"alert alert-danger\"><center><b>Erreur : </b>{{erreurConnexion}}</center></div>
        {% endif %}   
        {{ form_start(form) }}
            {{ form_label(form.login) }}
            {{ form_widget(form.login) }}
                            
            {{ form_label(form.mdp) }}
            {{ form_widget(form.mdp) }}
                            
            {{ form_label(form.profils) }}
            {{ form_widget(form.profils) }}
            <br>    
        {{ form_end(form) }}
                
    </div>
    
{% endblock%}




", "mehbatiInterimBundle:Commun:VueConnexion.html.twig", "/var/www/batiInterim/src/meh/batiInterimBundle/Resources/views/Commun/VueConnexion.html.twig");
    }
}
