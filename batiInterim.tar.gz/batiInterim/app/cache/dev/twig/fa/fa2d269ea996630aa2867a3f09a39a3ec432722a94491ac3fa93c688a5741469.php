<?php

/* TwigBundle:Exception:error.rdf.twig */
class __TwigTemplate_e5489cb2ad0e5b491a20e5a252701fd5f957c7f3fb9f1e9bb6089bb0d151f458 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_48b220f848a86a14da19231839124f6e2e5759ed8761a84b8c2d8b1ce6a125c5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_48b220f848a86a14da19231839124f6e2e5759ed8761a84b8c2d8b1ce6a125c5->enter($__internal_48b220f848a86a14da19231839124f6e2e5759ed8761a84b8c2d8b1ce6a125c5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.rdf.twig"));

        // line 1
        $this->loadTemplate("TwigBundle:Exception:error.xml.twig", "TwigBundle:Exception:error.rdf.twig", 1)->display($context);
        
        $__internal_48b220f848a86a14da19231839124f6e2e5759ed8761a84b8c2d8b1ce6a125c5->leave($__internal_48b220f848a86a14da19231839124f6e2e5759ed8761a84b8c2d8b1ce6a125c5_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.rdf.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% include 'TwigBundle:Exception:error.xml.twig' %}
", "TwigBundle:Exception:error.rdf.twig", "/var/www/batiInterim/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/error.rdf.twig");
    }
}
