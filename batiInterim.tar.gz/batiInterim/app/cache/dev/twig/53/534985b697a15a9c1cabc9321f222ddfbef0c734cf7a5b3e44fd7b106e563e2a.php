<?php

/* mehbatiInterimBundle:Artisan:VueGestionConge.html.twig */
class __TwigTemplate_97551bd32f847dfec4e62d85038c1bb09f00ba18cc4f7cdb1e64aea85bebe169 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 2
        $this->parent = $this->loadTemplate("mehbatiInterimBundle::base.html.twig", "mehbatiInterimBundle:Artisan:VueGestionConge.html.twig", 2);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'titrePage' => array($this, 'block_titrePage'),
            'contenu' => array($this, 'block_contenu'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "mehbatiInterimBundle::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6c4a9fde32bed1be3c07a29d37f231b0f8c3a58039601a8974fddface9d6cd7d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6c4a9fde32bed1be3c07a29d37f231b0f8c3a58039601a8974fddface9d6cd7d->enter($__internal_6c4a9fde32bed1be3c07a29d37f231b0f8c3a58039601a8974fddface9d6cd7d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "mehbatiInterimBundle:Artisan:VueGestionConge.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_6c4a9fde32bed1be3c07a29d37f231b0f8c3a58039601a8974fddface9d6cd7d->leave($__internal_6c4a9fde32bed1be3c07a29d37f231b0f8c3a58039601a8974fddface9d6cd7d_prof);

    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        $__internal_fccfc442d6dc861fac8e9c9f9debcbd19e4dcae218d16e7fe87d2abf74cc8f6d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fccfc442d6dc861fac8e9c9f9debcbd19e4dcae218d16e7fe87d2abf74cc8f6d->enter($__internal_fccfc442d6dc861fac8e9c9f9debcbd19e4dcae218d16e7fe87d2abf74cc8f6d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Gestion congé";
        
        $__internal_fccfc442d6dc861fac8e9c9f9debcbd19e4dcae218d16e7fe87d2abf74cc8f6d->leave($__internal_fccfc442d6dc861fac8e9c9f9debcbd19e4dcae218d16e7fe87d2abf74cc8f6d_prof);

    }

    // line 5
    public function block_titrePage($context, array $blocks = array())
    {
        $__internal_d69365321c6824ac917bdd21f3e917498b62a14bc26d1a3d01734b41d7bddb30 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d69365321c6824ac917bdd21f3e917498b62a14bc26d1a3d01734b41d7bddb30->enter($__internal_d69365321c6824ac917bdd21f3e917498b62a14bc26d1a3d01734b41d7bddb30_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "titrePage"));

        echo "Gestion congé ";
        
        $__internal_d69365321c6824ac917bdd21f3e917498b62a14bc26d1a3d01734b41d7bddb30->leave($__internal_d69365321c6824ac917bdd21f3e917498b62a14bc26d1a3d01734b41d7bddb30_prof);

    }

    // line 6
    public function block_contenu($context, array $blocks = array())
    {
        $__internal_82b418ae5920cb8bc4a3568f770415a0ed1e777d3d143dbe1ed3a02a098f287c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_82b418ae5920cb8bc4a3568f770415a0ed1e777d3d143dbe1ed3a02a098f287c->enter($__internal_82b418ae5920cb8bc4a3568f770415a0ed1e777d3d143dbe1ed3a02a098f287c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "contenu"));

        // line 7
        echo "    
    <div class=\"col-lg-1\"></div>
    <div class=\"col-lg-10\">
        <h4><center>Gestion des congés</center></h4>
        <div class=\"hline\"></div><br>
        ";
        // line 12
        if ((twig_length_filter($this->env, (isset($context["conges"]) ? $context["conges"] : $this->getContext($context, "conges"))) >= 1)) {
            // line 13
            echo "        <table class=\"table table-hover\">
            <thead>
                <tr>
                    <th>Congé numero</th>
                    <th>Date de debut</th>
                    <th>Date de fin</th>
                    <th>Etat</th>
                </tr>
            </thead>
            <tbody>
                
            ";
            // line 24
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["conges"]) ? $context["conges"] : $this->getContext($context, "conges")));
            foreach ($context['_seq'] as $context["_key"] => $context["unConger"]) {
                // line 25
                echo "                <tr>
                        <td>";
                // line 26
                echo twig_escape_filter($this->env, $this->getAttribute($context["unConger"], "idconger", array()), "html", null, true);
                echo "</td>
                        <td>";
                // line 27
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["unConger"], "datedebut", array()), "d/m/Y"), "html", null, true);
                echo "</td>
                        <td>";
                // line 28
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["unConger"], "datefin", array()), "d/m/Y"), "html", null, true);
                echo "</td>
                        <td>";
                // line 29
                echo twig_escape_filter($this->env, $this->getAttribute($context["unConger"], "valider", array()), "html", null, true);
                echo "</td>
                        
                        <td><a class=\"btn btn-theme\" href=\"";
                // line 31
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("page_gestion_modifier_conge", array("id" => $this->getAttribute($context["unConger"], "idconger", array()))), "html", null, true);
                echo "\">Modifier</a></td>
                        <td><a class=\"btn btn-danger\" href=\"";
                // line 32
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("page_gestion_delete_conge", array("id" => $this->getAttribute($context["unConger"], "idconger", array()))), "html", null, true);
                echo "\">Supprimer</a></td>              
                </tr>
            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['unConger'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 34
            echo "  
            </tbody>
        </table>
        ";
        } else {
            // line 38
            echo "            Vous n'avez pas de congé
        ";
        }
        // line 40
        echo "    </div>
    
    
";
        
        $__internal_82b418ae5920cb8bc4a3568f770415a0ed1e777d3d143dbe1ed3a02a098f287c->leave($__internal_82b418ae5920cb8bc4a3568f770415a0ed1e777d3d143dbe1ed3a02a098f287c_prof);

    }

    public function getTemplateName()
    {
        return "mehbatiInterimBundle:Artisan:VueGestionConge.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  135 => 40,  131 => 38,  125 => 34,  116 => 32,  112 => 31,  107 => 29,  103 => 28,  99 => 27,  95 => 26,  92 => 25,  88 => 24,  75 => 13,  73 => 12,  66 => 7,  60 => 6,  48 => 5,  36 => 4,  11 => 2,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("
{% extends 'mehbatiInterimBundle::base.html.twig' %}

{% block title %}Gestion congé{% endblock %}
{% block titrePage %}Gestion congé {% endblock %}
{% block contenu %}
    
    <div class=\"col-lg-1\"></div>
    <div class=\"col-lg-10\">
        <h4><center>Gestion des congés</center></h4>
        <div class=\"hline\"></div><br>
        {% if conges|length >= 1%}
        <table class=\"table table-hover\">
            <thead>
                <tr>
                    <th>Congé numero</th>
                    <th>Date de debut</th>
                    <th>Date de fin</th>
                    <th>Etat</th>
                </tr>
            </thead>
            <tbody>
                
            {% for unConger in conges %}
                <tr>
                        <td>{{unConger.idconger}}</td>
                        <td>{{unConger.datedebut|date('d/m/Y')}}</td>
                        <td>{{unConger.datefin|date('d/m/Y')}}</td>
                        <td>{{unConger.valider }}</td>
                        
                        <td><a class=\"btn btn-theme\" href=\"{{path('page_gestion_modifier_conge', {'id': unConger.idconger })}}\">Modifier</a></td>
                        <td><a class=\"btn btn-danger\" href=\"{{path('page_gestion_delete_conge', {'id': unConger.idconger })}}\">Supprimer</a></td>              
                </tr>
            {% endfor %}  
            </tbody>
        </table>
        {% else%}
            Vous n'avez pas de congé
        {% endif%}
    </div>
    
    
{% endblock%}
", "mehbatiInterimBundle:Artisan:VueGestionConge.html.twig", "/var/www/batiInterim/src/meh/batiInterimBundle/Resources/views/Artisan/VueGestionConge.html.twig");
    }
}
