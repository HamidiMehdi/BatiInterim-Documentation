<?php

/* mehbatiInterimBundle:Entrepreneur_ChefChantier:VueNewChantier.html.twig */
class __TwigTemplate_da0303d72ea3a8c11b64eabd294b2a79c25814a25918c731a9437a24ee69aac8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("mehbatiInterimBundle::base.html.twig", "mehbatiInterimBundle:Entrepreneur_ChefChantier:VueNewChantier.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'titrePage' => array($this, 'block_titrePage'),
            'contenu' => array($this, 'block_contenu'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "mehbatiInterimBundle::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_532727dec199cd8a4dbbdba14188cbe1422c2f12da7e0bec9e33ee4e5e5fcf65 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_532727dec199cd8a4dbbdba14188cbe1422c2f12da7e0bec9e33ee4e5e5fcf65->enter($__internal_532727dec199cd8a4dbbdba14188cbe1422c2f12da7e0bec9e33ee4e5e5fcf65_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "mehbatiInterimBundle:Entrepreneur_ChefChantier:VueNewChantier.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_532727dec199cd8a4dbbdba14188cbe1422c2f12da7e0bec9e33ee4e5e5fcf65->leave($__internal_532727dec199cd8a4dbbdba14188cbe1422c2f12da7e0bec9e33ee4e5e5fcf65_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_0edb05019f2560b7defcf11e157a834d7948ccf9c4ceaaf49538ef3a2c5d284d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0edb05019f2560b7defcf11e157a834d7948ccf9c4ceaaf49538ef3a2c5d284d->enter($__internal_0edb05019f2560b7defcf11e157a834d7948ccf9c4ceaaf49538ef3a2c5d284d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Nouveau chantier";
        
        $__internal_0edb05019f2560b7defcf11e157a834d7948ccf9c4ceaaf49538ef3a2c5d284d->leave($__internal_0edb05019f2560b7defcf11e157a834d7948ccf9c4ceaaf49538ef3a2c5d284d_prof);

    }

    // line 4
    public function block_titrePage($context, array $blocks = array())
    {
        $__internal_9fec6268c0c0cd84235b0490e285fbd90c1bb21e63b0f4b0fd9108b864e39052 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9fec6268c0c0cd84235b0490e285fbd90c1bb21e63b0f4b0fd9108b864e39052->enter($__internal_9fec6268c0c0cd84235b0490e285fbd90c1bb21e63b0f4b0fd9108b864e39052_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "titrePage"));

        echo "Nouveau chantier";
        
        $__internal_9fec6268c0c0cd84235b0490e285fbd90c1bb21e63b0f4b0fd9108b864e39052->leave($__internal_9fec6268c0c0cd84235b0490e285fbd90c1bb21e63b0f4b0fd9108b864e39052_prof);

    }

    // line 5
    public function block_contenu($context, array $blocks = array())
    {
        $__internal_63acb30441d6f368ad3e84a055e7764b0eea1bbb07d072969c1b8226d7e5c4bc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_63acb30441d6f368ad3e84a055e7764b0eea1bbb07d072969c1b8226d7e5c4bc->enter($__internal_63acb30441d6f368ad3e84a055e7764b0eea1bbb07d072969c1b8226d7e5c4bc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "contenu"));

        // line 6
        echo "    
    <div class=\"col-lg-2\"></div>
    <div class=\"col-lg-8\">
        <h4><center>Creer un nouveau chantier</center></h4>
        <div class=\"hline\"></div><br>
        ";
        // line 11
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form');
        echo "
    </div>
    
";
        
        $__internal_63acb30441d6f368ad3e84a055e7764b0eea1bbb07d072969c1b8226d7e5c4bc->leave($__internal_63acb30441d6f368ad3e84a055e7764b0eea1bbb07d072969c1b8226d7e5c4bc_prof);

    }

    public function getTemplateName()
    {
        return "mehbatiInterimBundle:Entrepreneur_ChefChantier:VueNewChantier.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 11,  66 => 6,  60 => 5,  48 => 4,  36 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'mehbatiInterimBundle::base.html.twig' %}

{% block title %}Nouveau chantier{% endblock %}
{% block titrePage %}Nouveau chantier{% endblock %}
{% block contenu %}
    
    <div class=\"col-lg-2\"></div>
    <div class=\"col-lg-8\">
        <h4><center>Creer un nouveau chantier</center></h4>
        <div class=\"hline\"></div><br>
        {{ form(form) }}
    </div>
    
{% endblock%}", "mehbatiInterimBundle:Entrepreneur_ChefChantier:VueNewChantier.html.twig", "/var/www/batiInterim/src/meh/batiInterimBundle/Resources/views/Entrepreneur_ChefChantier/VueNewChantier.html.twig");
    }
}
