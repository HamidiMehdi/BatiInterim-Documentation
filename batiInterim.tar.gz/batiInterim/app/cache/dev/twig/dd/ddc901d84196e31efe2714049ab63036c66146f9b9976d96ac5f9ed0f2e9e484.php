<?php

/* mehbatiInterimBundle:Entrepreneur_ChefChantier:VueArtisanParCorpsMetier.html.twig */
class __TwigTemplate_ab1a19a476ac0c45530e61d0080bcff369ebbf370b8a206dd393a639f87b45f4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 2
        $this->parent = $this->loadTemplate("mehbatiInterimBundle::base.html.twig", "mehbatiInterimBundle:Entrepreneur_ChefChantier:VueArtisanParCorpsMetier.html.twig", 2);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'titrePage' => array($this, 'block_titrePage'),
            'contenu' => array($this, 'block_contenu'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "mehbatiInterimBundle::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d85156db867273c6346ec8a08114973c1e315022c77ecb7735cf7c8e3b788c70 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d85156db867273c6346ec8a08114973c1e315022c77ecb7735cf7c8e3b788c70->enter($__internal_d85156db867273c6346ec8a08114973c1e315022c77ecb7735cf7c8e3b788c70_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "mehbatiInterimBundle:Entrepreneur_ChefChantier:VueArtisanParCorpsMetier.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_d85156db867273c6346ec8a08114973c1e315022c77ecb7735cf7c8e3b788c70->leave($__internal_d85156db867273c6346ec8a08114973c1e315022c77ecb7735cf7c8e3b788c70_prof);

    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        $__internal_4e8b0b7392c63e38324724a0b5a4bf5e3776d3089fee494b9762f929cfdb7240 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4e8b0b7392c63e38324724a0b5a4bf5e3776d3089fee494b9762f929cfdb7240->enter($__internal_4e8b0b7392c63e38324724a0b5a4bf5e3776d3089fee494b9762f929cfdb7240_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Artisan par corps de metier";
        
        $__internal_4e8b0b7392c63e38324724a0b5a4bf5e3776d3089fee494b9762f929cfdb7240->leave($__internal_4e8b0b7392c63e38324724a0b5a4bf5e3776d3089fee494b9762f929cfdb7240_prof);

    }

    // line 5
    public function block_titrePage($context, array $blocks = array())
    {
        $__internal_c8d864baa7388460bcd2ffd9e70c09f5deca9b9989c974635d55a6699f880265 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c8d864baa7388460bcd2ffd9e70c09f5deca9b9989c974635d55a6699f880265->enter($__internal_c8d864baa7388460bcd2ffd9e70c09f5deca9b9989c974635d55a6699f880265_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "titrePage"));

        echo "Artisan par corps de metier ";
        
        $__internal_c8d864baa7388460bcd2ffd9e70c09f5deca9b9989c974635d55a6699f880265->leave($__internal_c8d864baa7388460bcd2ffd9e70c09f5deca9b9989c974635d55a6699f880265_prof);

    }

    // line 6
    public function block_contenu($context, array $blocks = array())
    {
        $__internal_d5c3251dbbbfae2eed6240884518d8a8fdc4722239ad879ab1644c37fc6ab21b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d5c3251dbbbfae2eed6240884518d8a8fdc4722239ad879ab1644c37fc6ab21b->enter($__internal_d5c3251dbbbfae2eed6240884518d8a8fdc4722239ad879ab1644c37fc6ab21b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "contenu"));

        // line 7
        echo "    
    <div class=\"col-lg-1\"></div>
    <div class=\"col-lg-10\">
        <h4><center>Choisir le corps de metier</center></h4>
        <div class=\"hline\"></div><br>
        ";
        // line 12
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form');
        echo "
        ";
        // line 13
        if ( !twig_test_empty((isset($context["artisan"]) ? $context["artisan"] : $this->getContext($context, "artisan")))) {
            // line 14
            echo "            <div class=\"hline\"></div><br>
            
            <table class=\"table table-hover\">
                <thead>
                    <tr>
                        <th>Nom</th>
                        <th>Prenom</th>
                        <th>Date de naissance</th>
                        <th>Lieu de naissance</th>
                        <th>Numero de telephone</th>
                        <th>Adresse</th>
                    </tr>
                </thead>
                <tbody>

                ";
            // line 29
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["artisan"]) ? $context["artisan"] : $this->getContext($context, "artisan")));
            foreach ($context['_seq'] as $context["_key"] => $context["unArtisan"]) {
                // line 30
                echo "                    <tr>
                        <td>";
                // line 31
                echo twig_escape_filter($this->env, $this->getAttribute($context["unArtisan"], "nom", array()), "html", null, true);
                echo "</td>
                        <td>";
                // line 32
                echo twig_escape_filter($this->env, $this->getAttribute($context["unArtisan"], "prenom", array()), "html", null, true);
                echo "</td>
                        <td>";
                // line 33
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["unArtisan"], "dateNaissance", array()), "d/m/Y"), "html", null, true);
                echo "</td>
                        <td>";
                // line 34
                echo twig_escape_filter($this->env, $this->getAttribute($context["unArtisan"], "lieuNaissance", array()), "html", null, true);
                echo "</td>
                        <td>";
                // line 35
                echo twig_escape_filter($this->env, $this->getAttribute($context["unArtisan"], "numTel", array()), "html", null, true);
                echo "</td>
                        <td>";
                // line 36
                echo twig_escape_filter($this->env, $this->getAttribute($context["unArtisan"], "adresse", array()), "html", null, true);
                echo ", ";
                echo twig_escape_filter($this->env, $this->getAttribute($context["unArtisan"], "cp", array()), "html", null, true);
                echo "</td>
                    </tr>
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['unArtisan'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 39
            echo "                </tbody>
            </table> 
        ";
        }
        // line 41
        echo "   
    </div>
        
";
        
        $__internal_d5c3251dbbbfae2eed6240884518d8a8fdc4722239ad879ab1644c37fc6ab21b->leave($__internal_d5c3251dbbbfae2eed6240884518d8a8fdc4722239ad879ab1644c37fc6ab21b_prof);

    }

    public function getTemplateName()
    {
        return "mehbatiInterimBundle:Entrepreneur_ChefChantier:VueArtisanParCorpsMetier.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  139 => 41,  134 => 39,  123 => 36,  119 => 35,  115 => 34,  111 => 33,  107 => 32,  103 => 31,  100 => 30,  96 => 29,  79 => 14,  77 => 13,  73 => 12,  66 => 7,  60 => 6,  48 => 5,  36 => 4,  11 => 2,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("
{% extends 'mehbatiInterimBundle::base.html.twig' %}

{% block title %}Artisan par corps de metier{% endblock %}
{% block titrePage %}Artisan par corps de metier {% endblock %}
{% block contenu %}
    
    <div class=\"col-lg-1\"></div>
    <div class=\"col-lg-10\">
        <h4><center>Choisir le corps de metier</center></h4>
        <div class=\"hline\"></div><br>
        {{form(form)}}
        {% if artisan is not empty %}
            <div class=\"hline\"></div><br>
            
            <table class=\"table table-hover\">
                <thead>
                    <tr>
                        <th>Nom</th>
                        <th>Prenom</th>
                        <th>Date de naissance</th>
                        <th>Lieu de naissance</th>
                        <th>Numero de telephone</th>
                        <th>Adresse</th>
                    </tr>
                </thead>
                <tbody>

                {% for unArtisan in artisan %}
                    <tr>
                        <td>{{unArtisan.nom}}</td>
                        <td>{{unArtisan.prenom}}</td>
                        <td>{{unArtisan.dateNaissance|date('d/m/Y')}}</td>
                        <td>{{unArtisan.lieuNaissance}}</td>
                        <td>{{unArtisan.numTel}}</td>
                        <td>{{unArtisan.adresse}}, {{unArtisan.cp}}</td>
                    </tr>
                {% endfor %}
                </tbody>
            </table> 
        {% endif %}   
    </div>
        
{% endblock%}

", "mehbatiInterimBundle:Entrepreneur_ChefChantier:VueArtisanParCorpsMetier.html.twig", "/var/www/batiInterim/src/meh/batiInterimBundle/Resources/views/Entrepreneur_ChefChantier/VueArtisanParCorpsMetier.html.twig");
    }
}
