<?php

/* mehbatiInterimBundle:Entrepreneur_ChefChantier:VueGestionChantier.html.twig */
class __TwigTemplate_ce3ab3952e58960c90b3f57a42e099eab8188cb3277351172432e609889ea2a2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("mehbatiInterimBundle::base.html.twig", "mehbatiInterimBundle:Entrepreneur_ChefChantier:VueGestionChantier.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'titrePage' => array($this, 'block_titrePage'),
            'contenu' => array($this, 'block_contenu'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "mehbatiInterimBundle::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5c0f14c3e9391d2d9e6f5e2d6155b80625367e2377e5185c7c40a883edb0c30f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5c0f14c3e9391d2d9e6f5e2d6155b80625367e2377e5185c7c40a883edb0c30f->enter($__internal_5c0f14c3e9391d2d9e6f5e2d6155b80625367e2377e5185c7c40a883edb0c30f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "mehbatiInterimBundle:Entrepreneur_ChefChantier:VueGestionChantier.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_5c0f14c3e9391d2d9e6f5e2d6155b80625367e2377e5185c7c40a883edb0c30f->leave($__internal_5c0f14c3e9391d2d9e6f5e2d6155b80625367e2377e5185c7c40a883edb0c30f_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_35bd94cb4b2f00bbdc3d9a8634394ffe757537881550fc28d55718433792bbd7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_35bd94cb4b2f00bbdc3d9a8634394ffe757537881550fc28d55718433792bbd7->enter($__internal_35bd94cb4b2f00bbdc3d9a8634394ffe757537881550fc28d55718433792bbd7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Gestion chantier";
        
        $__internal_35bd94cb4b2f00bbdc3d9a8634394ffe757537881550fc28d55718433792bbd7->leave($__internal_35bd94cb4b2f00bbdc3d9a8634394ffe757537881550fc28d55718433792bbd7_prof);

    }

    // line 4
    public function block_titrePage($context, array $blocks = array())
    {
        $__internal_d5a526ca5c51347d796924478475a07091af3efb9e417aa27ff5fbc5d05e7a4a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d5a526ca5c51347d796924478475a07091af3efb9e417aa27ff5fbc5d05e7a4a->enter($__internal_d5a526ca5c51347d796924478475a07091af3efb9e417aa27ff5fbc5d05e7a4a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "titrePage"));

        echo "Gestion chantier";
        
        $__internal_d5a526ca5c51347d796924478475a07091af3efb9e417aa27ff5fbc5d05e7a4a->leave($__internal_d5a526ca5c51347d796924478475a07091af3efb9e417aa27ff5fbc5d05e7a4a_prof);

    }

    // line 5
    public function block_contenu($context, array $blocks = array())
    {
        $__internal_35c56e998e4dce24bc64be4ef138827bd3bb96f4dba8a79bdabfd5f4541d4179 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_35c56e998e4dce24bc64be4ef138827bd3bb96f4dba8a79bdabfd5f4541d4179->enter($__internal_35c56e998e4dce24bc64be4ef138827bd3bb96f4dba8a79bdabfd5f4541d4179_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "contenu"));

        // line 6
        echo "    
    <div class=\"col-lg-1\"></div>
    <div class=\"col-lg-10\">
        <h4><center>Les chantiers </center></h4>
        <div class=\"hline\"></div><br>
        ";
        // line 11
        if ((twig_length_filter($this->env, (isset($context["chantiers"]) ? $context["chantiers"] : $this->getContext($context, "chantiers"))) >= 1)) {
            // line 12
            echo "            <table class=\"table table-hover\">
                <thead>
                    <tr>
                        <th>Chantier numéro</th>
                        <th>Nom</th>
                        <th>Chef du chantier</th>
                        <th>Entrepreneur</th>
                    </tr>
                </thead>
                <tbody>

                ";
            // line 23
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["chantiers"]) ? $context["chantiers"] : $this->getContext($context, "chantiers")));
            foreach ($context['_seq'] as $context["_key"] => $context["unChantier"]) {
                // line 24
                echo "                    <tr>
                        <td>";
                // line 25
                echo twig_escape_filter($this->env, $this->getAttribute($context["unChantier"], "idchantier", array()), "html", null, true);
                echo "</td>
                        <td>";
                // line 26
                echo twig_escape_filter($this->env, $this->getAttribute($context["unChantier"], "nom", array()), "html", null, true);
                echo "</td>
                        <td>";
                // line 27
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["unChantier"], "idchefchantier", array()), "nom", array()), "html", null, true);
                echo " ";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["unChantier"], "idchefchantier", array()), "prenom", array()), "html", null, true);
                echo "</td>
                        <td>";
                // line 28
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["unChantier"], "identrepreneur", array()), "nomsociete", array()), "html", null, true);
                echo "</td>
                        <td><a class=\"btn btn-theme\" href=\"";
                // line 29
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("page_mission_dun_chantier", array("id" => $this->getAttribute($context["unChantier"], "idchantier", array()))), "html", null, true);
                echo "\">Voir les missions</a></td>
                    </tr>
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['unChantier'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 32
            echo "                </tbody>
            </table> 
        ";
        } else {
            // line 34
            echo "    
            Vous n'avez pas de chantier.
        ";
        }
        // line 36
        echo "   
    </div>
        
";
        
        $__internal_35c56e998e4dce24bc64be4ef138827bd3bb96f4dba8a79bdabfd5f4541d4179->leave($__internal_35c56e998e4dce24bc64be4ef138827bd3bb96f4dba8a79bdabfd5f4541d4179_prof);

    }

    public function getTemplateName()
    {
        return "mehbatiInterimBundle:Entrepreneur_ChefChantier:VueGestionChantier.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  132 => 36,  127 => 34,  122 => 32,  113 => 29,  109 => 28,  103 => 27,  99 => 26,  95 => 25,  92 => 24,  88 => 23,  75 => 12,  73 => 11,  66 => 6,  60 => 5,  48 => 4,  36 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'mehbatiInterimBundle::base.html.twig' %}

{% block title %}Gestion chantier{% endblock %}
{% block titrePage %}Gestion chantier{% endblock %}
{% block contenu %}
    
    <div class=\"col-lg-1\"></div>
    <div class=\"col-lg-10\">
        <h4><center>Les chantiers </center></h4>
        <div class=\"hline\"></div><br>
        {% if chantiers|length >=1 %}
            <table class=\"table table-hover\">
                <thead>
                    <tr>
                        <th>Chantier numéro</th>
                        <th>Nom</th>
                        <th>Chef du chantier</th>
                        <th>Entrepreneur</th>
                    </tr>
                </thead>
                <tbody>

                {% for unChantier in chantiers %}
                    <tr>
                        <td>{{unChantier.idchantier}}</td>
                        <td>{{unChantier.nom}}</td>
                        <td>{{unChantier.idchefchantier.nom}} {{unChantier.idchefchantier.prenom}}</td>
                        <td>{{unChantier.identrepreneur.nomsociete}}</td>
                        <td><a class=\"btn btn-theme\" href=\"{{path('page_mission_dun_chantier', {'id': unChantier.idchantier })}}\">Voir les missions</a></td>
                    </tr>
                {% endfor %}
                </tbody>
            </table> 
        {% else %}    
            Vous n'avez pas de chantier.
        {% endif %}   
    </div>
        
{% endblock%}

", "mehbatiInterimBundle:Entrepreneur_ChefChantier:VueGestionChantier.html.twig", "/var/www/batiInterim/src/meh/batiInterimBundle/Resources/views/Entrepreneur_ChefChantier/VueGestionChantier.html.twig");
    }
}
