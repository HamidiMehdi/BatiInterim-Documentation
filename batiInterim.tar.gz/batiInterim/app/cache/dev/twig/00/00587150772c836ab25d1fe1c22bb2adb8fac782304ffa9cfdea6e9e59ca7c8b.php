<?php

/* WebProfilerBundle:Profiler:ajax_layout.html.twig */
class __TwigTemplate_0025508d65b7054def967fe5eef8e78891aa11dc7b33923191d01d0e2e2539f8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5187e598de96e68f941a47b8b1f239a42ebfdd0884f090a73dea5c4e570c3d07 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5187e598de96e68f941a47b8b1f239a42ebfdd0884f090a73dea5c4e570c3d07->enter($__internal_5187e598de96e68f941a47b8b1f239a42ebfdd0884f090a73dea5c4e570c3d07_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_5187e598de96e68f941a47b8b1f239a42ebfdd0884f090a73dea5c4e570c3d07->leave($__internal_5187e598de96e68f941a47b8b1f239a42ebfdd0884f090a73dea5c4e570c3d07_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_315f34cccdad62170ddeced0254131d42daca632ea50eb934123e4ca8a2cf3b9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_315f34cccdad62170ddeced0254131d42daca632ea50eb934123e4ca8a2cf3b9->enter($__internal_315f34cccdad62170ddeced0254131d42daca632ea50eb934123e4ca8a2cf3b9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_315f34cccdad62170ddeced0254131d42daca632ea50eb934123e4ca8a2cf3b9->leave($__internal_315f34cccdad62170ddeced0254131d42daca632ea50eb934123e4ca8a2cf3b9_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  23 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% block panel '' %}
", "WebProfilerBundle:Profiler:ajax_layout.html.twig", "/var/www/batiInterim/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Profiler/ajax_layout.html.twig");
    }
}
