<?php

/* mehbatiInterimBundle:Commun:VueAccueil.html.twig */
class __TwigTemplate_498562b3ff3197d482d481e60e1e6c49c92b176cc8ec803fe3043b207d533c91 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("mehbatiInterimBundle::base.html.twig", "mehbatiInterimBundle:Commun:VueAccueil.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'titrePage' => array($this, 'block_titrePage'),
            'contenu' => array($this, 'block_contenu'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "mehbatiInterimBundle::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_75e89cf5c31424a5283ef8c45153e5103ccc68030d7249f61361ba0a1b980041 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_75e89cf5c31424a5283ef8c45153e5103ccc68030d7249f61361ba0a1b980041->enter($__internal_75e89cf5c31424a5283ef8c45153e5103ccc68030d7249f61361ba0a1b980041_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "mehbatiInterimBundle:Commun:VueAccueil.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_75e89cf5c31424a5283ef8c45153e5103ccc68030d7249f61361ba0a1b980041->leave($__internal_75e89cf5c31424a5283ef8c45153e5103ccc68030d7249f61361ba0a1b980041_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_418b81c454fcedf421db8b188d56c607004afb726aadb46db58f341dea43d273 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_418b81c454fcedf421db8b188d56c607004afb726aadb46db58f341dea43d273->enter($__internal_418b81c454fcedf421db8b188d56c607004afb726aadb46db58f341dea43d273_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Accueil";
        
        $__internal_418b81c454fcedf421db8b188d56c607004afb726aadb46db58f341dea43d273->leave($__internal_418b81c454fcedf421db8b188d56c607004afb726aadb46db58f341dea43d273_prof);

    }

    // line 4
    public function block_titrePage($context, array $blocks = array())
    {
        $__internal_00f98a8fee1a4f43c1fca8411b75f1042abca9225de27d8d4a536611424e4823 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_00f98a8fee1a4f43c1fca8411b75f1042abca9225de27d8d4a536611424e4823->enter($__internal_00f98a8fee1a4f43c1fca8411b75f1042abca9225de27d8d4a536611424e4823_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "titrePage"));

        echo "Accueil";
        
        $__internal_00f98a8fee1a4f43c1fca8411b75f1042abca9225de27d8d4a536611424e4823->leave($__internal_00f98a8fee1a4f43c1fca8411b75f1042abca9225de27d8d4a536611424e4823_prof);

    }

    // line 5
    public function block_contenu($context, array $blocks = array())
    {
        $__internal_00aaf19ef16b10cd39a95b92879bbdb3cd6eabbb84c70e148e0856195b3d0b12 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_00aaf19ef16b10cd39a95b92879bbdb3cd6eabbb84c70e148e0856195b3d0b12->enter($__internal_00aaf19ef16b10cd39a95b92879bbdb3cd6eabbb84c70e148e0856195b3d0b12_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "contenu"));

        // line 6
        echo "    
    <div class=\"col-lg-2\"></div>
    <div class=\"col-lg-8\">
        <h2>Bonjour ";
        // line 9
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "get", array(0 => "nom"), "method"), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "get", array(0 => "prenom"), "method"), "html", null, true);
        echo " (";
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "get", array(0 => "profil"), "method"), "html", null, true);
        echo ")</h2>   
    </div>
    
";
        
        $__internal_00aaf19ef16b10cd39a95b92879bbdb3cd6eabbb84c70e148e0856195b3d0b12->leave($__internal_00aaf19ef16b10cd39a95b92879bbdb3cd6eabbb84c70e148e0856195b3d0b12_prof);

    }

    public function getTemplateName()
    {
        return "mehbatiInterimBundle:Commun:VueAccueil.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  71 => 9,  66 => 6,  60 => 5,  48 => 4,  36 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'mehbatiInterimBundle::base.html.twig' %}

{% block title %}Accueil{% endblock %}
{% block titrePage %}Accueil{% endblock %}
{% block contenu %}
    
    <div class=\"col-lg-2\"></div>
    <div class=\"col-lg-8\">
        <h2>Bonjour {{app.session.get('nom')}} {{app.session.get('prenom')}} ({{app.session.get('profil')}})</h2>   
    </div>
    
{% endblock%}
", "mehbatiInterimBundle:Commun:VueAccueil.html.twig", "/var/www/batiInterim/src/meh/batiInterimBundle/Resources/views/Commun/VueAccueil.html.twig");
    }
}
