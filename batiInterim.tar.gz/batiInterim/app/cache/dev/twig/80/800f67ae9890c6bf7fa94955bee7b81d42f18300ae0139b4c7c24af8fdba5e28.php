<?php

/* mehbatiInterimBundle:Artisan:VueMission.html.twig */
class __TwigTemplate_bb73b34391303d1ba1f2ee0d566597be550dfbe2332f017c6b78a8bb00471e7d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("mehbatiInterimBundle::base.html.twig", "mehbatiInterimBundle:Artisan:VueMission.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'titrePage' => array($this, 'block_titrePage'),
            'contenu' => array($this, 'block_contenu'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "mehbatiInterimBundle::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a90ce7db69904eebf2c7dc31b3a7b317a23c64a4b7e5780403e0824727695b65 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a90ce7db69904eebf2c7dc31b3a7b317a23c64a4b7e5780403e0824727695b65->enter($__internal_a90ce7db69904eebf2c7dc31b3a7b317a23c64a4b7e5780403e0824727695b65_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "mehbatiInterimBundle:Artisan:VueMission.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_a90ce7db69904eebf2c7dc31b3a7b317a23c64a4b7e5780403e0824727695b65->leave($__internal_a90ce7db69904eebf2c7dc31b3a7b317a23c64a4b7e5780403e0824727695b65_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_0ce72664c5e29ad495935fb6f13ded45ef69dc3d415358cb3a8728f65e2a4035 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0ce72664c5e29ad495935fb6f13ded45ef69dc3d415358cb3a8728f65e2a4035->enter($__internal_0ce72664c5e29ad495935fb6f13ded45ef69dc3d415358cb3a8728f65e2a4035_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Missions";
        
        $__internal_0ce72664c5e29ad495935fb6f13ded45ef69dc3d415358cb3a8728f65e2a4035->leave($__internal_0ce72664c5e29ad495935fb6f13ded45ef69dc3d415358cb3a8728f65e2a4035_prof);

    }

    // line 4
    public function block_titrePage($context, array $blocks = array())
    {
        $__internal_f9b882259457233015ff24219e78f49a78dbb9e05ced435a6ee85527caa8f61b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f9b882259457233015ff24219e78f49a78dbb9e05ced435a6ee85527caa8f61b->enter($__internal_f9b882259457233015ff24219e78f49a78dbb9e05ced435a6ee85527caa8f61b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "titrePage"));

        echo "Mes missions";
        
        $__internal_f9b882259457233015ff24219e78f49a78dbb9e05ced435a6ee85527caa8f61b->leave($__internal_f9b882259457233015ff24219e78f49a78dbb9e05ced435a6ee85527caa8f61b_prof);

    }

    // line 5
    public function block_contenu($context, array $blocks = array())
    {
        $__internal_de1f5ddb30a0ee7679d85d9bf2ef7cc2978bffad7013b2b4c97b5d7505f15bdc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_de1f5ddb30a0ee7679d85d9bf2ef7cc2978bffad7013b2b4c97b5d7505f15bdc->enter($__internal_de1f5ddb30a0ee7679d85d9bf2ef7cc2978bffad7013b2b4c97b5d7505f15bdc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "contenu"));

        // line 6
        echo "    
    <div class=\"col-lg-1\"></div>
    <div class=\"col-lg-10\">
        <h4><center>Liste des missions affectés </center></h4>
        <div class=\"hline\"></div><br>
        ";
        // line 11
        if ((twig_length_filter($this->env, (isset($context["missions"]) ? $context["missions"] : $this->getContext($context, "missions"))) >= 1)) {
            // line 12
            echo "            <table class=\"table table-hover\">
                <thead>
                    <tr>
                        <th>Entrepreneur</th>
                        <th>Chef de chantier</th>
                        <th>Mission</th>
                        <th>Date mission</th>
                        <th>Etat</th>
                    </tr>
                </thead>
                <tbody>

                ";
            // line 24
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["missions"]) ? $context["missions"] : $this->getContext($context, "missions")));
            foreach ($context['_seq'] as $context["_key"] => $context["uneMission"]) {
                // line 25
                echo "                    <tr>
                        <td>";
                // line 26
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($this->getAttribute($context["uneMission"], "idmission", array()), "idchantier", array()), "identrepreneur", array()), "nomsociete", array()), "html", null, true);
                echo "</td>
                        <td>";
                // line 27
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($this->getAttribute($context["uneMission"], "idmission", array()), "idchantier", array()), "idchefchantier", array()), "nom", array()), "html", null, true);
                echo " ";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($this->getAttribute($context["uneMission"], "idmission", array()), "idchantier", array()), "idchefchantier", array()), "prenom", array()), "html", null, true);
                echo "</td>
                        <td>";
                // line 28
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["uneMission"], "idmission", array()), "intitule", array()), "html", null, true);
                echo "</td>
                        <td>";
                // line 29
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($this->getAttribute($context["uneMission"], "idmission", array()), "datedebut", array()), "d/m/Y"), "html", null, true);
                echo " au ";
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($this->getAttribute($context["uneMission"], "idmission", array()), "datefin", array()), "d/m/Y"), "html", null, true);
                echo "</td>
                        <td>";
                // line 30
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["uneMission"], "idetat", array()), "alias", array()), "html", null, true);
                echo " (";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["uneMission"], "idetat", array()), "libelle", array()), "html", null, true);
                echo ")</td>
                        <td><a class=\"btn btn-success\" href=\"";
                // line 31
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("update_etat_mission", array("idMission" => $this->getAttribute($this->getAttribute($context["uneMission"], "idmission", array()), "idmission", array()), "btn" => 1)), "html", null, true);
                echo "\">Accepter</a></td>
                        <td><a class=\"btn btn-danger\" href=\"";
                // line 32
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("update_etat_mission", array("idMission" => $this->getAttribute($this->getAttribute($context["uneMission"], "idmission", array()), "idmission", array()), "btn" => 2)), "html", null, true);
                echo "\">Refuser</a></td>

                    </tr>
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['uneMission'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 36
            echo "                </tbody>
            </table> 
        ";
        } else {
            // line 38
            echo "    
            Vous n'avez aucune mission.
        ";
        }
        // line 40
        echo "   
    </div>
        
";
        
        $__internal_de1f5ddb30a0ee7679d85d9bf2ef7cc2978bffad7013b2b4c97b5d7505f15bdc->leave($__internal_de1f5ddb30a0ee7679d85d9bf2ef7cc2978bffad7013b2b4c97b5d7505f15bdc_prof);

    }

    public function getTemplateName()
    {
        return "mehbatiInterimBundle:Artisan:VueMission.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  146 => 40,  141 => 38,  136 => 36,  126 => 32,  122 => 31,  116 => 30,  110 => 29,  106 => 28,  100 => 27,  96 => 26,  93 => 25,  89 => 24,  75 => 12,  73 => 11,  66 => 6,  60 => 5,  48 => 4,  36 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'mehbatiInterimBundle::base.html.twig' %}

{% block title %}Missions{% endblock %}
{% block titrePage %}Mes missions{% endblock %}
{% block contenu %}
    
    <div class=\"col-lg-1\"></div>
    <div class=\"col-lg-10\">
        <h4><center>Liste des missions affectés </center></h4>
        <div class=\"hline\"></div><br>
        {% if missions|length >=1 %}
            <table class=\"table table-hover\">
                <thead>
                    <tr>
                        <th>Entrepreneur</th>
                        <th>Chef de chantier</th>
                        <th>Mission</th>
                        <th>Date mission</th>
                        <th>Etat</th>
                    </tr>
                </thead>
                <tbody>

                {% for uneMission in missions %}
                    <tr>
                        <td>{{uneMission.idmission.idchantier.identrepreneur.nomsociete}}</td>
                        <td>{{uneMission.idmission.idchantier.idchefchantier.nom}} {{uneMission.idmission.idchantier.idchefchantier.prenom}}</td>
                        <td>{{uneMission.idmission.intitule}}</td>
                        <td>{{uneMission.idmission.datedebut|date('d/m/Y')}} au {{uneMission.idmission.datefin|date('d/m/Y')}}</td>
                        <td>{{uneMission.idetat.alias}} ({{uneMission.idetat.libelle}})</td>
                        <td><a class=\"btn btn-success\" href=\"{{path('update_etat_mission', {'idMission': uneMission.idmission.idmission, 'btn':1 })}}\">Accepter</a></td>
                        <td><a class=\"btn btn-danger\" href=\"{{path('update_etat_mission', {'idMission': uneMission.idmission.idmission, 'btn':2 })}}\">Refuser</a></td>

                    </tr>
                {% endfor %}
                </tbody>
            </table> 
        {% else %}    
            Vous n'avez aucune mission.
        {% endif %}   
    </div>
        
{% endblock%}


", "mehbatiInterimBundle:Artisan:VueMission.html.twig", "/var/www/batiInterim/src/meh/batiInterimBundle/Resources/views/Artisan/VueMission.html.twig");
    }
}
