<?php

/* mehbatiInterimBundle:Entrepreneur_ChefChantier:VueAffecterMission.html.twig */
class __TwigTemplate_a491a90d7ed786689e7eebb689dae35710889e1b8a927815308f72d17f34504f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("mehbatiInterimBundle::base.html.twig", "mehbatiInterimBundle:Entrepreneur_ChefChantier:VueAffecterMission.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'titrePage' => array($this, 'block_titrePage'),
            'contenu' => array($this, 'block_contenu'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "mehbatiInterimBundle::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_714e1b3e88bd000bb6bba4e889da7af2ded0a4d55ebe2d6bb3c75c625400476a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_714e1b3e88bd000bb6bba4e889da7af2ded0a4d55ebe2d6bb3c75c625400476a->enter($__internal_714e1b3e88bd000bb6bba4e889da7af2ded0a4d55ebe2d6bb3c75c625400476a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "mehbatiInterimBundle:Entrepreneur_ChefChantier:VueAffecterMission.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_714e1b3e88bd000bb6bba4e889da7af2ded0a4d55ebe2d6bb3c75c625400476a->leave($__internal_714e1b3e88bd000bb6bba4e889da7af2ded0a4d55ebe2d6bb3c75c625400476a_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_0d7653f547142c037aa13d60363c96290e60e69252ca2e9ada309d6a0a7106a5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0d7653f547142c037aa13d60363c96290e60e69252ca2e9ada309d6a0a7106a5->enter($__internal_0d7653f547142c037aa13d60363c96290e60e69252ca2e9ada309d6a0a7106a5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Affecter mission";
        
        $__internal_0d7653f547142c037aa13d60363c96290e60e69252ca2e9ada309d6a0a7106a5->leave($__internal_0d7653f547142c037aa13d60363c96290e60e69252ca2e9ada309d6a0a7106a5_prof);

    }

    // line 4
    public function block_titrePage($context, array $blocks = array())
    {
        $__internal_5fcc59a54d784779ba58bbdbb4ae50a021a392192a572435663a9ff22d060107 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5fcc59a54d784779ba58bbdbb4ae50a021a392192a572435663a9ff22d060107->enter($__internal_5fcc59a54d784779ba58bbdbb4ae50a021a392192a572435663a9ff22d060107_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "titrePage"));

        echo "Affecter mission";
        
        $__internal_5fcc59a54d784779ba58bbdbb4ae50a021a392192a572435663a9ff22d060107->leave($__internal_5fcc59a54d784779ba58bbdbb4ae50a021a392192a572435663a9ff22d060107_prof);

    }

    // line 5
    public function block_contenu($context, array $blocks = array())
    {
        $__internal_0aec71925f0219f1eb9282aacc47601e883f4421ad9258ff7569743c0587fd13 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0aec71925f0219f1eb9282aacc47601e883f4421ad9258ff7569743c0587fd13->enter($__internal_0aec71925f0219f1eb9282aacc47601e883f4421ad9258ff7569743c0587fd13_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "contenu"));

        // line 6
        echo "    
    <div class=\"col-lg-1\"></div>
    <div class=\"col-lg-10\">
        <h4><center>Les missions d'un chantier sélectioné</center></h4>
        <div class=\"hline\"></div><br>
        ";
        // line 11
        if ((twig_length_filter($this->env, (isset($context["missions"]) ? $context["missions"] : $this->getContext($context, "missions"))) >= 1)) {
            // line 12
            echo "            <table class=\"table table-hover\">
                <thead>
                    <tr>
                        <th>Date de début</th>
                        <th>Date de fin</th>
                        <th>Intitulé</th>
                        <th>Nombre d'artisan</th>
                        <th>Prix par jour</th>
                    </tr>
                </thead>
                <tbody>

                ";
            // line 24
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["missions"]) ? $context["missions"] : $this->getContext($context, "missions")));
            foreach ($context['_seq'] as $context["_key"] => $context["uneMissions"]) {
                // line 25
                echo "                    <tr>
                        <td>";
                // line 26
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["uneMissions"], "datedebut", array()), "d/m/Y"), "html", null, true);
                echo "</td>
                        <td>";
                // line 27
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["uneMissions"], "datefin", array()), "d/m/Y"), "html", null, true);
                echo "</td>
                        <td>";
                // line 28
                echo twig_escape_filter($this->env, $this->getAttribute($context["uneMissions"], "intitule", array()), "html", null, true);
                echo "</td>
                        <td>";
                // line 29
                echo twig_escape_filter($this->env, $this->getAttribute($context["uneMissions"], "nbartisans", array()), "html", null, true);
                echo "</td>
                        <td>";
                // line 30
                echo twig_escape_filter($this->env, $this->getAttribute($context["uneMissions"], "prixparjour", array()), "html", null, true);
                echo " €</td>
                        <td><a class=\"btn btn-theme\" href=\"";
                // line 31
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("page_affecter_artisan", array("id" => $this->getAttribute($context["uneMissions"], "idmission", array()))), "html", null, true);
                echo "\">Selectionné</a></td>
                    </tr>
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['uneMissions'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 34
            echo "                </tbody>
            </table> 
        ";
        } else {
            // line 36
            echo "    
            Le chantier n'a aucune mission.
        ";
        }
        // line 38
        echo "   
    </div>
        
";
        
        $__internal_0aec71925f0219f1eb9282aacc47601e883f4421ad9258ff7569743c0587fd13->leave($__internal_0aec71925f0219f1eb9282aacc47601e883f4421ad9258ff7569743c0587fd13_prof);

    }

    public function getTemplateName()
    {
        return "mehbatiInterimBundle:Entrepreneur_ChefChantier:VueAffecterMission.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  135 => 38,  130 => 36,  125 => 34,  116 => 31,  112 => 30,  108 => 29,  104 => 28,  100 => 27,  96 => 26,  93 => 25,  89 => 24,  75 => 12,  73 => 11,  66 => 6,  60 => 5,  48 => 4,  36 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'mehbatiInterimBundle::base.html.twig' %}

{% block title %}Affecter mission{% endblock %}
{% block titrePage %}Affecter mission{% endblock %}
{% block contenu %}
    
    <div class=\"col-lg-1\"></div>
    <div class=\"col-lg-10\">
        <h4><center>Les missions d'un chantier sélectioné</center></h4>
        <div class=\"hline\"></div><br>
        {% if missions|length >=1 %}
            <table class=\"table table-hover\">
                <thead>
                    <tr>
                        <th>Date de début</th>
                        <th>Date de fin</th>
                        <th>Intitulé</th>
                        <th>Nombre d'artisan</th>
                        <th>Prix par jour</th>
                    </tr>
                </thead>
                <tbody>

                {% for uneMissions in missions %}
                    <tr>
                        <td>{{uneMissions.datedebut|date('d/m/Y')}}</td>
                        <td>{{uneMissions.datefin|date('d/m/Y')}}</td>
                        <td>{{uneMissions.intitule}}</td>
                        <td>{{uneMissions.nbartisans}}</td>
                        <td>{{uneMissions.prixparjour}} €</td>
                        <td><a class=\"btn btn-theme\" href=\"{{path('page_affecter_artisan', {'id': uneMissions.idmission })}}\">Selectionné</a></td>
                    </tr>
                {% endfor %}
                </tbody>
            </table> 
        {% else %}    
            Le chantier n'a aucune mission.
        {% endif %}   
    </div>
        
{% endblock%}

", "mehbatiInterimBundle:Entrepreneur_ChefChantier:VueAffecterMission.html.twig", "/var/www/batiInterim/src/meh/batiInterimBundle/Resources/views/Entrepreneur_ChefChantier/VueAffecterMission.html.twig");
    }
}
