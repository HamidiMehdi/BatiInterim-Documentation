<?php

use Symfony\Component\Routing\Exception\MethodNotAllowedException;
use Symfony\Component\Routing\Exception\ResourceNotFoundException;
use Symfony\Component\Routing\RequestContext;

/**
 * appDevDebugProjectContainerUrlMatcher.
 *
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class appDevDebugProjectContainerUrlMatcher extends Symfony\Bundle\FrameworkBundle\Routing\RedirectableUrlMatcher
{
    /**
     * Constructor.
     */
    public function __construct(RequestContext $context)
    {
        $this->context = $context;
    }

    public function match($pathinfo)
    {
        $allow = array();
        $pathinfo = rawurldecode($pathinfo);
        $context = $this->context;
        $request = $this->request;

        if (0 === strpos($pathinfo, '/css')) {
            if (0 === strpos($pathinfo, '/css/d110ff7')) {
                // _assetic_d110ff7
                if ($pathinfo === '/css/d110ff7.css') {
                    return array (  '_controller' => 'assetic.controller:render',  'name' => 'd110ff7',  'pos' => NULL,  '_format' => 'css',  '_route' => '_assetic_d110ff7',);
                }

                // _assetic_d110ff7_0
                if ($pathinfo === '/css/d110ff7_bootstrap_1.css') {
                    return array (  '_controller' => 'assetic.controller:render',  'name' => 'd110ff7',  'pos' => 0,  '_format' => 'css',  '_route' => '_assetic_d110ff7_0',);
                }

            }

            if (0 === strpos($pathinfo, '/css/637d219')) {
                // _assetic_637d219
                if ($pathinfo === '/css/637d219.css') {
                    return array (  '_controller' => 'assetic.controller:render',  'name' => '637d219',  'pos' => NULL,  '_format' => 'css',  '_route' => '_assetic_637d219',);
                }

                // _assetic_637d219_0
                if ($pathinfo === '/css/637d219_style_1.css') {
                    return array (  '_controller' => 'assetic.controller:render',  'name' => '637d219',  'pos' => 0,  '_format' => 'css',  '_route' => '_assetic_637d219_0',);
                }

            }

            if (0 === strpos($pathinfo, '/css/2269066')) {
                // _assetic_2269066
                if ($pathinfo === '/css/2269066.css') {
                    return array (  '_controller' => 'assetic.controller:render',  'name' => 2269066,  'pos' => NULL,  '_format' => 'css',  '_route' => '_assetic_2269066',);
                }

                // _assetic_2269066_0
                if ($pathinfo === '/css/2269066_font-awesome.min_1.css') {
                    return array (  '_controller' => 'assetic.controller:render',  'name' => 2269066,  'pos' => 0,  '_format' => 'css',  '_route' => '_assetic_2269066_0',);
                }

            }

        }

        if (0 === strpos($pathinfo, '/js')) {
            if (0 === strpos($pathinfo, '/js/9e7a6dd')) {
                // _assetic_9e7a6dd
                if ($pathinfo === '/js/9e7a6dd.js') {
                    return array (  '_controller' => 'assetic.controller:render',  'name' => '9e7a6dd',  'pos' => NULL,  '_format' => 'js',  '_route' => '_assetic_9e7a6dd',);
                }

                // _assetic_9e7a6dd_0
                if ($pathinfo === '/js/9e7a6dd_bootstrap.min_1.js') {
                    return array (  '_controller' => 'assetic.controller:render',  'name' => '9e7a6dd',  'pos' => 0,  '_format' => 'js',  '_route' => '_assetic_9e7a6dd_0',);
                }

            }

            if (0 === strpos($pathinfo, '/js/aa6c98c')) {
                // _assetic_aa6c98c
                if ($pathinfo === '/js/aa6c98c.js') {
                    return array (  '_controller' => 'assetic.controller:render',  'name' => 'aa6c98c',  'pos' => NULL,  '_format' => 'js',  '_route' => '_assetic_aa6c98c',);
                }

                // _assetic_aa6c98c_0
                if ($pathinfo === '/js/aa6c98c_retina-1.1.0_1.js') {
                    return array (  '_controller' => 'assetic.controller:render',  'name' => 'aa6c98c',  'pos' => 0,  '_format' => 'js',  '_route' => '_assetic_aa6c98c_0',);
                }

            }

            if (0 === strpos($pathinfo, '/js/55fed6f')) {
                // _assetic_55fed6f
                if ($pathinfo === '/js/55fed6f.js') {
                    return array (  '_controller' => 'assetic.controller:render',  'name' => '55fed6f',  'pos' => NULL,  '_format' => 'js',  '_route' => '_assetic_55fed6f',);
                }

                // _assetic_55fed6f_0
                if ($pathinfo === '/js/55fed6f_jquery.hoverdir_1.js') {
                    return array (  '_controller' => 'assetic.controller:render',  'name' => '55fed6f',  'pos' => 0,  '_format' => 'js',  '_route' => '_assetic_55fed6f_0',);
                }

            }

            if (0 === strpos($pathinfo, '/js/4e4daf1')) {
                // _assetic_4e4daf1
                if ($pathinfo === '/js/4e4daf1.js') {
                    return array (  '_controller' => 'assetic.controller:render',  'name' => '4e4daf1',  'pos' => NULL,  '_format' => 'js',  '_route' => '_assetic_4e4daf1',);
                }

                // _assetic_4e4daf1_0
                if ($pathinfo === '/js/4e4daf1_jquery.hoverex.min_1.js') {
                    return array (  '_controller' => 'assetic.controller:render',  'name' => '4e4daf1',  'pos' => 0,  '_format' => 'js',  '_route' => '_assetic_4e4daf1_0',);
                }

            }

            if (0 === strpos($pathinfo, '/js/6326506')) {
                // _assetic_6326506
                if ($pathinfo === '/js/6326506.js') {
                    return array (  '_controller' => 'assetic.controller:render',  'name' => 6326506,  'pos' => NULL,  '_format' => 'js',  '_route' => '_assetic_6326506',);
                }

                // _assetic_6326506_0
                if ($pathinfo === '/js/6326506_jquery.prettyPhoto_1.js') {
                    return array (  '_controller' => 'assetic.controller:render',  'name' => 6326506,  'pos' => 0,  '_format' => 'js',  '_route' => '_assetic_6326506_0',);
                }

            }

            if (0 === strpos($pathinfo, '/js/0de8a66')) {
                // _assetic_0de8a66
                if ($pathinfo === '/js/0de8a66.js') {
                    return array (  '_controller' => 'assetic.controller:render',  'name' => '0de8a66',  'pos' => NULL,  '_format' => 'js',  '_route' => '_assetic_0de8a66',);
                }

                // _assetic_0de8a66_0
                if ($pathinfo === '/js/0de8a66_jquery.isotope.min_1.js') {
                    return array (  '_controller' => 'assetic.controller:render',  'name' => '0de8a66',  'pos' => 0,  '_format' => 'js',  '_route' => '_assetic_0de8a66_0',);
                }

            }

            if (0 === strpos($pathinfo, '/js/af3c089')) {
                // _assetic_af3c089
                if ($pathinfo === '/js/af3c089.js') {
                    return array (  '_controller' => 'assetic.controller:render',  'name' => 'af3c089',  'pos' => NULL,  '_format' => 'js',  '_route' => '_assetic_af3c089',);
                }

                // _assetic_af3c089_0
                if ($pathinfo === '/js/af3c089_custom_1.js') {
                    return array (  '_controller' => 'assetic.controller:render',  'name' => 'af3c089',  'pos' => 0,  '_format' => 'js',  '_route' => '_assetic_af3c089_0',);
                }

            }

        }

        if (0 === strpos($pathinfo, '/_')) {
            // _wdt
            if (0 === strpos($pathinfo, '/_wdt') && preg_match('#^/_wdt/(?P<token>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => '_wdt')), array (  '_controller' => 'web_profiler.controller.profiler:toolbarAction',));
            }

            if (0 === strpos($pathinfo, '/_profiler')) {
                // _profiler_home
                if (rtrim($pathinfo, '/') === '/_profiler') {
                    if (substr($pathinfo, -1) !== '/') {
                        return $this->redirect($pathinfo.'/', '_profiler_home');
                    }

                    return array (  '_controller' => 'web_profiler.controller.profiler:homeAction',  '_route' => '_profiler_home',);
                }

                if (0 === strpos($pathinfo, '/_profiler/search')) {
                    // _profiler_search
                    if ($pathinfo === '/_profiler/search') {
                        return array (  '_controller' => 'web_profiler.controller.profiler:searchAction',  '_route' => '_profiler_search',);
                    }

                    // _profiler_search_bar
                    if ($pathinfo === '/_profiler/search_bar') {
                        return array (  '_controller' => 'web_profiler.controller.profiler:searchBarAction',  '_route' => '_profiler_search_bar',);
                    }

                }

                // _profiler_purge
                if ($pathinfo === '/_profiler/purge') {
                    return array (  '_controller' => 'web_profiler.controller.profiler:purgeAction',  '_route' => '_profiler_purge',);
                }

                // _profiler_info
                if (0 === strpos($pathinfo, '/_profiler/info') && preg_match('#^/_profiler/info/(?P<about>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_info')), array (  '_controller' => 'web_profiler.controller.profiler:infoAction',));
                }

                // _profiler_phpinfo
                if ($pathinfo === '/_profiler/phpinfo') {
                    return array (  '_controller' => 'web_profiler.controller.profiler:phpinfoAction',  '_route' => '_profiler_phpinfo',);
                }

                // _profiler_search_results
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/search/results$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_search_results')), array (  '_controller' => 'web_profiler.controller.profiler:searchResultsAction',));
                }

                // _profiler
                if (preg_match('#^/_profiler/(?P<token>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler')), array (  '_controller' => 'web_profiler.controller.profiler:panelAction',));
                }

                // _profiler_router
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/router$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_router')), array (  '_controller' => 'web_profiler.controller.router:panelAction',));
                }

                // _profiler_exception
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/exception$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_exception')), array (  '_controller' => 'web_profiler.controller.exception:showAction',));
                }

                // _profiler_exception_css
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/exception\\.css$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_exception_css')), array (  '_controller' => 'web_profiler.controller.exception:cssAction',));
                }

            }

            if (0 === strpos($pathinfo, '/_configurator')) {
                // _configurator_home
                if (rtrim($pathinfo, '/') === '/_configurator') {
                    if (substr($pathinfo, -1) !== '/') {
                        return $this->redirect($pathinfo.'/', '_configurator_home');
                    }

                    return array (  '_controller' => 'Sensio\\Bundle\\DistributionBundle\\Controller\\ConfiguratorController::checkAction',  '_route' => '_configurator_home',);
                }

                // _configurator_step
                if (0 === strpos($pathinfo, '/_configurator/step') && preg_match('#^/_configurator/step/(?P<index>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_configurator_step')), array (  '_controller' => 'Sensio\\Bundle\\DistributionBundle\\Controller\\ConfiguratorController::stepAction',));
                }

                // _configurator_final
                if ($pathinfo === '/_configurator/final') {
                    return array (  '_controller' => 'Sensio\\Bundle\\DistributionBundle\\Controller\\ConfiguratorController::finalAction',  '_route' => '_configurator_final',);
                }

            }

            // _twig_error_test
            if (0 === strpos($pathinfo, '/_error') && preg_match('#^/_error/(?P<code>\\d+)(?:\\.(?P<_format>[^/]++))?$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => '_twig_error_test')), array (  '_controller' => 'twig.controller.preview_error:previewErrorPageAction',  '_format' => 'html',));
            }

        }

        // page_de_connexion
        if ($pathinfo === '/connexion') {
            return array (  '_controller' => 'meh\\batiInterimBundle\\Controller\\CommunController\\ConnexionController::pageConnexionAction',  '_route' => 'page_de_connexion',);
        }

        // déconnexion
        if ($pathinfo === '/déconnexion') {
            return array (  '_controller' => 'meh\\batiInterimBundle\\Controller\\CommunController\\ConnexionController::deconnexionAction',  '_route' => 'déconnexion',);
        }

        // page_accueil
        if ($pathinfo === '/accueil') {
            return array (  '_controller' => 'meh\\batiInterimBundle\\Controller\\CommunController\\AccueilController::pageAccueilAction',  '_route' => 'page_accueil',);
        }

        if (0 === strpos($pathinfo, '/change')) {
            // page_changer_mdp_permiere_connexion
            if ($pathinfo === '/changement_mdp_premier_connexion') {
                return array (  '_controller' => 'meh\\batiInterimBundle\\Controller\\CommunController\\AccueilController::pageModificationMdpPremierConnexionAction',  '_route' => 'page_changer_mdp_permiere_connexion',);
            }

            // page_changer_mdp
            if ($pathinfo === '/changer_mdp') {
                return array (  '_controller' => 'meh\\batiInterimBundle\\Controller\\CommunController\\AccueilController::pageChangerMdpAction',  '_route' => 'page_changer_mdp',);
            }

        }

        // page_nouveau_artisan
        if ($pathinfo === '/nouveau_artisan') {
            return array (  '_controller' => 'meh\\batiInterimBundle\\Controller\\GestionnaireController\\ArtisanController::pageNewArtisanAction',  '_route' => 'page_nouveau_artisan',);
        }

        // page_gestion_artisan
        if ($pathinfo === '/gestion_artisan') {
            return array (  '_controller' => 'meh\\batiInterimBundle\\Controller\\GestionnaireController\\ArtisanController::pageGestionArtisanAction',  '_route' => 'page_gestion_artisan',);
        }

        // page_gestion_delete_artisan
        if (0 === strpos($pathinfo, '/supprimer_artisan') && preg_match('#^/supprimer_artisan/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
            return $this->mergeDefaults(array_replace($matches, array('_route' => 'page_gestion_delete_artisan')), array (  '_controller' => 'meh\\batiInterimBundle\\Controller\\GestionnaireController\\ArtisanController::deleteArtisanAction',));
        }

        // page_gestion_maj_artisan
        if (0 === strpos($pathinfo, '/maj_artisan') && preg_match('#^/maj_artisan/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
            return $this->mergeDefaults(array_replace($matches, array('_route' => 'page_gestion_maj_artisan')), array (  '_controller' => 'meh\\batiInterimBundle\\Controller\\GestionnaireController\\ArtisanController::pageMajArtisanAction',));
        }

        // page_nouveau_entrepreneur
        if ($pathinfo === '/nouveau_entrepreneur') {
            return array (  '_controller' => 'meh\\batiInterimBundle\\Controller\\GestionnaireController\\EntrepreneurController::pageNewEntrepreneurAction',  '_route' => 'page_nouveau_entrepreneur',);
        }

        // page_inserer_chef_chantier
        if (0 === strpos($pathinfo, '/chef_chantier') && preg_match('#^/chef_chantier/(?P<nomSociete>[^/]++)$#s', $pathinfo, $matches)) {
            return $this->mergeDefaults(array_replace($matches, array('_route' => 'page_inserer_chef_chantier')), array (  '_controller' => 'meh\\batiInterimBundle\\Controller\\GestionnaireController\\EntrepreneurController::pageSelectChefChantierAction',));
        }

        // page_gestion_entrepreneur
        if ($pathinfo === '/gestion_entrepreneur') {
            return array (  '_controller' => 'meh\\batiInterimBundle\\Controller\\GestionnaireController\\EntrepreneurController::pageGestionEntrepreneurAction',  '_route' => 'page_gestion_entrepreneur',);
        }

        // page_gestion_delete_entrepreneur
        if (0 === strpos($pathinfo, '/supprimer_entrepreneur') && preg_match('#^/supprimer_entrepreneur/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
            return $this->mergeDefaults(array_replace($matches, array('_route' => 'page_gestion_delete_entrepreneur')), array (  '_controller' => 'meh\\batiInterimBundle\\Controller\\GestionnaireController\\EntrepreneurController::deleteEntrepreneurAction',));
        }

        // page_gestion_maj_entrepreneur
        if (0 === strpos($pathinfo, '/maj_entrepreneur') && preg_match('#^/maj_entrepreneur/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
            return $this->mergeDefaults(array_replace($matches, array('_route' => 'page_gestion_maj_entrepreneur')), array (  '_controller' => 'meh\\batiInterimBundle\\Controller\\GestionnaireController\\EntrepreneurController::pageMajEntrepreneurAction',));
        }

        // page_conges_gestionnaire
        if ($pathinfo === '/conges_artisan') {
            return array (  '_controller' => 'meh\\batiInterimBundle\\Controller\\GestionnaireController\\CongesController::pageCongeAction',  '_route' => 'page_conges_gestionnaire',);
        }

        // page_conges_update_etat
        if (0 === strpos($pathinfo, '/maj_etat_conge') && preg_match('#^/maj_etat_conge/(?P<id>[^/]++)/(?P<btn>[^/]++)$#s', $pathinfo, $matches)) {
            return $this->mergeDefaults(array_replace($matches, array('_route' => 'page_conges_update_etat')), array (  '_controller' => 'meh\\batiInterimBundle\\Controller\\GestionnaireController\\CongesController::updateEtatCongeAction',));
        }

        // page_nouveau_conge
        if ($pathinfo === '/nouveau_conge') {
            return array (  '_controller' => 'meh\\batiInterimBundle\\Controller\\ArtisanController\\CongeController::pageNouveauCongeAction',  '_route' => 'page_nouveau_conge',);
        }

        // page_gestion_conge
        if ($pathinfo === '/gestion_conge') {
            return array (  '_controller' => 'meh\\batiInterimBundle\\Controller\\ArtisanController\\CongeController::pageGestionCongeAction',  '_route' => 'page_gestion_conge',);
        }

        // page_gestion_delete_conge
        if (0 === strpos($pathinfo, '/supprimer_conge') && preg_match('#^/supprimer_conge/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
            return $this->mergeDefaults(array_replace($matches, array('_route' => 'page_gestion_delete_conge')), array (  '_controller' => 'meh\\batiInterimBundle\\Controller\\ArtisanController\\CongeController::deleteCongeAction',));
        }

        if (0 === strpos($pathinfo, '/m')) {
            // page_gestion_modifier_conge
            if (0 === strpos($pathinfo, '/modifier_conge') && preg_match('#^/modifier_conge/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'page_gestion_modifier_conge')), array (  '_controller' => 'meh\\batiInterimBundle\\Controller\\ArtisanController\\CongeController::pageModifierCongeAction',));
            }

            // page_maj_coordonnées_artisan
            if ($pathinfo === '/maj_coordonnées') {
                return array (  '_controller' => 'meh\\batiInterimBundle\\Controller\\ArtisanController\\ArtisanController::pageMajCoordonneesArtisanAction',  '_route' => 'page_maj_coordonnées_artisan',);
            }

            // page_mission_artisan
            if ($pathinfo === '/mission') {
                return array (  '_controller' => 'meh\\batiInterimBundle\\Controller\\ArtisanController\\MissionController::pageMissionAction',  '_route' => 'page_mission_artisan',);
            }

            // update_etat_mission
            if (0 === strpos($pathinfo, '/maj_etat_mission') && preg_match('#^/maj_etat_mission/(?P<idMission>[^/]++)/(?P<btn>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'update_etat_mission')), array (  '_controller' => 'meh\\batiInterimBundle\\Controller\\ArtisanController\\MissionController::updateEtatMissionAction',));
            }

        }

        if (0 === strpos($pathinfo, '/artisan_')) {
            // page__artisan_par_corps_metier
            if ($pathinfo === '/artisan_par_corps_metier') {
                return array (  '_controller' => 'meh\\batiInterimBundle\\Controller\\EntrepreneurChefChantierController\\ArtisanController::pageArtisanParCorpsMetierAction',  '_route' => 'page__artisan_par_corps_metier',);
            }

            // page__artisan_abs_present
            if ($pathinfo === '/artisan_absent_présent') {
                return array (  '_controller' => 'meh\\batiInterimBundle\\Controller\\EntrepreneurChefChantierController\\ArtisanController::pageArtisanAbsPresentAction',  '_route' => 'page__artisan_abs_present',);
            }

        }

        // page__conges_dun_artisan
        if ($pathinfo === '/conges_dun_artisan') {
            return array (  '_controller' => 'meh\\batiInterimBundle\\Controller\\EntrepreneurChefChantierController\\ArtisanController::pageCongerDunArtisanAction',  '_route' => 'page__conges_dun_artisan',);
        }

        if (0 === strpos($pathinfo, '/nouve')) {
            // page_new_chantier
            if ($pathinfo === '/nouveau_chantier') {
                return array (  '_controller' => 'meh\\batiInterimBundle\\Controller\\EntrepreneurChefChantierController\\ChantierController::pageNewChantierAction',  '_route' => 'page_new_chantier',);
            }

            // page_new_mission
            if ($pathinfo === '/nouvelle_mission') {
                return array (  '_controller' => 'meh\\batiInterimBundle\\Controller\\EntrepreneurChefChantierController\\ChantierController::pageNewMissionAction',  '_route' => 'page_new_mission',);
            }

        }

        // page_gestion_chantier
        if ($pathinfo === '/gestion_chantier') {
            return array (  '_controller' => 'meh\\batiInterimBundle\\Controller\\EntrepreneurChefChantierController\\ChantierController::pageGestionChantierAction',  '_route' => 'page_gestion_chantier',);
        }

        // page_mission_dun_chantier
        if (0 === strpos($pathinfo, '/mission_chantier') && preg_match('#^/mission_chantier/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
            return $this->mergeDefaults(array_replace($matches, array('_route' => 'page_mission_dun_chantier')), array (  '_controller' => 'meh\\batiInterimBundle\\Controller\\EntrepreneurChefChantierController\\ChantierController::pageMissionDunChantierAction',));
        }

        if (0 === strpos($pathinfo, '/affect')) {
            if (0 === strpos($pathinfo, '/affecter_')) {
                if (0 === strpos($pathinfo, '/affecter_mission')) {
                    // page_affecter_mission_chantier
                    if ($pathinfo === '/affecter_mission_chantier') {
                        return array (  '_controller' => 'meh\\batiInterimBundle\\Controller\\EntrepreneurChefChantierController\\AffecterController::pageAffecterMissionChantierAction',  '_route' => 'page_affecter_mission_chantier',);
                    }

                    // page_affecter_artisan_mission
                    if (preg_match('#^/affecter_mission/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'page_affecter_artisan_mission')), array (  '_controller' => 'meh\\batiInterimBundle\\Controller\\EntrepreneurChefChantierController\\AffecterController::pageAffecterArtisanMissionAction',));
                    }

                }

                // page_affecter_artisan
                if (0 === strpos($pathinfo, '/affecter_artisan') && preg_match('#^/affecter_artisan/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'page_affecter_artisan')), array (  '_controller' => 'meh\\batiInterimBundle\\Controller\\EntrepreneurChefChantierController\\AffecterController::pageSelectionArtisanAffectationAction',));
                }

            }

            // affecter_artisan_mission
            if (0 === strpos($pathinfo, '/affectation_artisan') && preg_match('#^/affectation_artisan/(?P<idMission>[^/]++)/(?P<idArtisan>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'affecter_artisan_mission')), array (  '_controller' => 'meh\\batiInterimBundle\\Controller\\EntrepreneurChefChantierController\\AffecterController::selectionArtisanAction',));
            }

        }

        // page_gestion_affecter
        if ($pathinfo === '/gestion_affecter') {
            return array (  '_controller' => 'meh\\batiInterimBundle\\Controller\\EntrepreneurChefChantierController\\AffecterController::pageGestionAffecterAction',  '_route' => 'page_gestion_affecter',);
        }

        // delete_une_affectation
        if (0 === strpos($pathinfo, '/delete_affectation') && preg_match('#^/delete_affectation/(?P<idMission>[^/]++)/(?P<idArtisan>[^/]++)$#s', $pathinfo, $matches)) {
            return $this->mergeDefaults(array_replace($matches, array('_route' => 'delete_une_affectation')), array (  '_controller' => 'meh\\batiInterimBundle\\Controller\\EntrepreneurChefChantierController\\AffecterController::deleteUneAffectationAction',));
        }

        // homepage
        if (rtrim($pathinfo, '/') === '') {
            if (substr($pathinfo, -1) !== '/') {
                return $this->redirect($pathinfo.'/', 'homepage');
            }

            return array (  '_controller' => 'AppBundle\\Controller\\DefaultController::indexAction',  '_route' => 'homepage',);
        }

        throw 0 < count($allow) ? new MethodNotAllowedException(array_unique($allow)) : new ResourceNotFoundException();
    }
}
